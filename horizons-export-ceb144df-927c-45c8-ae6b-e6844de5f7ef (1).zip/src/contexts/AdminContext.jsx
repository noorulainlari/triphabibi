
import React, { createContext, useContext, useState, useEffect } from 'react';

const AdminContext = createContext();

export const useAdmin = () => {
  const context = useContext(AdminContext);
  if (!context) {
    throw new Error('useAdmin must be used within an AdminProvider');
  }
  return context;
};

export const AdminProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return localStorage.getItem('adminAuthenticated') === 'true';
  });

  const [adminCredentials] = useState({
    username: 'admin',
    password: 'admin123'
  });

  const [promoCodes, setPromoCodes] = useState(() => {
    const saved = localStorage.getItem('abuDhabiPromoCodes');
    return saved ? JSON.parse(saved) : [
      { id: '1', code: 'WELCOME10', discount: 10, type: 'percentage', active: true },
      { id: '2', code: 'LAYOVER20', discount: 20, type: 'percentage', active: true }
    ];
  });

  useEffect(() => {
    localStorage.setItem('abuDhabiPromoCodes', JSON.stringify(promoCodes));
  }, [promoCodes]);


  const login = (username, password) => {
    if (username === adminCredentials.username && password === adminCredentials.password) {
      setIsAuthenticated(true);
      localStorage.setItem('adminAuthenticated', 'true');
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('adminAuthenticated');
  };

  const addPromoCode = (promoCode) => {
    const newPromoCode = {
      ...promoCode,
      id: Date.now().toString(),
      active: true
    };
    setPromoCodes(prev => [...prev, newPromoCode]);
  };

  const updatePromoCode = (id, updatedPromoCode) => {
    setPromoCodes(prev => prev.map(promo => 
      promo.id === id ? { ...promo, ...updatedPromoCode } : promo
    ));
  };

  const deletePromoCode = (id) => {
    setPromoCodes(prev => prev.filter(promo => promo.id !== id));
  };

  const validatePromoCode = (code) => {
    return promoCodes.find(promo => 
      promo.code.toLowerCase() === code.toLowerCase() && promo.active
    );
  };

  const value = {
    isAuthenticated,
    promoCodes,
    login,
    logout,
    addPromoCode,
    updatePromoCode,
    deletePromoCode,
    validatePromoCode,
  };

  return (
    <AdminContext.Provider value={value}>
      {children}
    </AdminContext.Provider>
  );
};
