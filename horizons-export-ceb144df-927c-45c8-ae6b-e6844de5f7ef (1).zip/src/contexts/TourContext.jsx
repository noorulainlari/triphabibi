import React, { createContext, useContext, useState, useEffect } from 'react';

const TourContext = createContext();

export const useTours = () => {
  const context = useContext(TourContext);
  if (!context) {
    throw new Error('useTours must be used within a TourProvider');
  }
  return context;
};

const initialTours = [
  {
    id: '1',
    title: 'Desert Safari Adventure',
    category: 'desert-safari',
    description: 'Experience the thrill of dune bashing, camel riding, and traditional Bedouin culture in the heart of Abu Dhabi desert.',
    duration: '6 hours',
    price: 22000, // Price in INR
    priceType: 'per person',
    images: [
      'Desert safari with dune bashing and camel riding',
      'Traditional Bedouin camp with cultural activities',
      'Sunset over golden sand dunes'
    ],
    highlights: [
      'Dune bashing in 4x4 vehicles',
      'Camel riding experience',
      'Traditional BBQ dinner',
      'Henna painting & falconry',
      'Belly dance performance'
    ],
    included: ['Hotel pickup/drop-off', 'Professional guide', 'All activities', 'Dinner'],
    availability: true,
    featured: true
  },
  {
    id: '2',
    title: 'Abu Dhabi City Tour',
    category: 'city-tour',
    description: 'Discover the magnificent Sheikh Zayed Grand Mosque, Emirates Palace, and the cultural heart of Abu Dhabi.',
    duration: '4 hours',
    price: 15000, // Price in INR
    priceType: 'per person',
    images: [
      'Sheikh Zayed Grand Mosque with stunning architecture',
      'Emirates Palace luxury hotel exterior',
      'Abu Dhabi Corniche waterfront view'
    ],
    highlights: [
      'Sheikh Zayed Grand Mosque',
      'Emirates Palace photo stop',
      'Heritage Village visit',
      'Corniche drive',
      'Dates market experience'
    ],
    included: ['Hotel pickup/drop-off', 'Professional guide', 'Entrance fees', 'Refreshments'],
    availability: true,
    featured: true
  },
  {
    id: '3',
    title: 'Airport Express Tour',
    category: 'airport-pickup',
    description: 'Perfect for layovers! Quick city highlights tour with comfortable airport transfers.',
    duration: '3 hours',
    price: 11000, // Price in INR
    priceType: 'per person',
    images: [
      'Luxury vehicle for airport transfers',
      'Quick city tour highlights',
      'Professional driver and guide'
    ],
    highlights: [
      'Airport pickup/drop-off',
      'Sheikh Zayed Mosque visit',
      'Emirates Palace drive-by',
      'Corniche photo stop',
      'Souvenir shopping'
    ],
    included: ['Airport transfers', 'Professional guide', 'Bottled water', 'WiFi in vehicle'],
    availability: true,
    featured: false
  },
  {
    id: '4',
    title: 'Louvre Abu Dhabi Cultural Tour',
    category: 'cultural',
    description: 'Immerse yourself in art and culture at the stunning Louvre Abu Dhabi museum.',
    duration: '3 hours',
    price: 13500, // Price in INR
    priceType: 'per person',
    images: [
      'Louvre Abu Dhabi museum exterior architecture',
      'Art galleries inside Louvre Abu Dhabi',
      'Cultural artifacts and exhibitions'
    ],
    highlights: [
      'Louvre Abu Dhabi museum',
      'Guided art tour',
      'Cultural district walk',
      'Saadiyat Island visit',
      'Photography opportunities'
    ],
    included: ['Museum tickets', 'Professional guide', 'Transportation', 'Audio guide'],
    availability: true,
    featured: false
  }
];

const categories = [
  { id: 'desert-safari', name: 'Desert Safari', icon: '🏜️' },
  { id: 'city-tour', name: 'City Tours', icon: '🏛️' },
  { id: 'airport-pickup', name: 'Airport Pickup', icon: '✈️' },
  { id: 'cultural', name: 'Cultural Tours', icon: '🎨' },
  { id: 'adventure', name: 'Adventure', icon: '🎢' },
  { id: 'luxury', name: 'Luxury Experience', icon: '💎' }
];

export const TourProvider = ({ children }) => {
  const [tours, setTours] = useState(() => {
    const savedTours = localStorage.getItem('abuDhabiTours');
    return savedTours ? JSON.parse(savedTours) : initialTours;
  });

  const [bookings, setBookings] = useState(() => {
    const savedBookings = localStorage.getItem('abuDhabiBookings');
    return savedBookings ? JSON.parse(savedBookings) : [];
  });

  const [testimonials] = useState([
    {
      id: '1',
      name: 'Sarah Johnson',
      country: 'USA',
      rating: 5,
      comment: 'Absolutely incredible desert safari! The guides were amazing and the experience was unforgettable.',
      tour: 'Desert Safari Adventure'
    },
    {
      id: '2',
      name: 'Mohammed Al-Rashid',
      country: 'UAE',
      rating: 5,
      comment: 'Perfect city tour for visitors. Very professional service and great value for money.',
      tour: 'Abu Dhabi City Tour'
    },
    {
      id: '3',
      name: 'Emma Thompson',
      country: 'UK',
      rating: 5,
      comment: 'The airport pickup tour was perfect for our layover. Highly recommend!',
      tour: 'Airport Express Tour'
    }
  ]);

  useEffect(() => {
    localStorage.setItem('abuDhabiTours', JSON.stringify(tours));
  }, [tours]);

  useEffect(() => {
    localStorage.setItem('abuDhabiBookings', JSON.stringify(bookings));
  }, [bookings]);

  const addTour = (tour) => {
    const newTour = {
      ...tour,
      id: Date.now().toString(),
      availability: true
    };
    setTours(prev => [...prev, newTour]);
  };

  const updateTour = (id, updatedTour) => {
    setTours(prev => prev.map(tour => 
      tour.id === id ? { ...tour, ...updatedTour } : tour
    ));
  };

  const deleteTour = (id) => {
    setTours(prev => prev.filter(tour => tour.id !== id));
  };

  const getTourById = (id) => {
    return tours.find(tour => tour.id === id);
  };

  const getToursByCategory = (category) => {
    return tours.filter(tour => tour.category === category);
  };

  const getFeaturedTours = () => {
    return tours.filter(tour => tour.featured);
  };

  const addBooking = (booking) => {
    const newBooking = {
      ...booking,
      id: Date.now().toString(),
      status: 'pending', // Default status, can be updated after payment
      createdAt: new Date().toISOString()
    };
    setBookings(prev => [...prev, newBooking]);
    return newBooking;
  };

  const updateBookingStatus = (id, status) => {
    setBookings(prev => prev.map(booking => 
      booking.id === id ? { ...booking, status } : booking
    ));
  };

  const value = {
    tours,
    bookings,
    categories,
    testimonials,
    addTour,
    updateTour,
    deleteTour,
    getTourById,
    getToursByCategory,
    getFeaturedTours,
    addBooking,
    updateBookingStatus
  };

  return (
    <TourContext.Provider value={value}>
      {children}
    </TourContext.Provider>
  );
};