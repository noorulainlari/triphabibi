
import React, { createContext, useContext, useState, useEffect } from 'react';

const PaymentGatewayContext = createContext();

export const usePaymentGateways = () => {
  const context = useContext(PaymentGatewayContext);
  if (!context) {
    throw new Error('usePaymentGateways must be used within a PaymentGatewayProvider');
  }
  return context;
};

const initialGatewaySettings = {
  razorpay: {
    id: 'razorpay',
    name: 'Razorpay',
    enabled: true,
    keyId: '',
    keySecret: '',
    logo: '/payment-logos/razorpay.svg',
    fields: [
      { name: 'keyId', label: 'Key ID', type: 'text', placeholder: 'rzp_live_xxxxxxxxxxxxxx' },
      { name: 'keySecret', label: 'Key Secret', type: 'password', placeholder: 'Your Razorpay Key Secret' }
    ]
  },
  stripe: {
    id: 'stripe',
    name: 'Stripe',
    enabled: false,
    publishableKey: '',
    secretKey: '',
    logo: '/payment-logos/stripe.svg',
    fields: [
      { name: 'publishableKey', label: 'Publishable Key', type: 'text', placeholder: 'pk_live_xxxxxxxxxxxxxx' },
      { name: 'secretKey', label: 'Secret Key', type: 'password', placeholder: 'sk_live_xxxxxxxxxxxxxx' }
    ]
  },
  paypal: {
    id: 'paypal',
    name: 'PayPal',
    enabled: false,
    clientId: '',
    clientSecret: '',
    logo: '/payment-logos/paypal.svg',
    fields: [
      { name: 'clientId', label: 'Client ID', type: 'text', placeholder: 'Your PayPal Client ID' },
      { name: 'clientSecret', label: 'Client Secret', type: 'password', placeholder: 'Your PayPal Client Secret' }
    ]
  },
  ccavenue: {
    id: 'ccavenue',
    name: 'CCAvenue',
    enabled: false,
    merchantId: '',
    accessCode: '',
    workingKey: '',
    logo: '/payment-logos/ccavenue.svg',
    fields: [
      { name: 'merchantId', label: 'Merchant ID', type: 'text', placeholder: 'Your CCAvenue Merchant ID' },
      { name: 'accessCode', label: 'Access Code', type: 'text', placeholder: 'Your CCAvenue Access Code' },
      { name: 'workingKey', label: 'Working Key (Encryption Key)', type: 'password', placeholder: 'Your CCAvenue Working Key' }
    ]
  },
  manualBankTransfer: {
    id: 'manualBankTransfer',
    name: 'Manual Bank Transfer',
    enabled: false,
    instructions: 'Please transfer the total amount to the following bank account:\nBank Name: Example Bank\nAccount Name: Abu Dhabi Layover Tours\nAccount Number: 1234567890\nIFSC Code: EXMPL0001234\n\nAfter transfer, please send screenshot to payments@abudhabilayover.com with your Booking ID.',
    logo: '/payment-logos/bank-transfer.svg', 
    fields: [
      { name: 'instructions', label: 'Payment Instructions', type: 'textarea', placeholder: 'Provide bank details and instructions for users.' }
    ]
  },
  payLater: {
    id: 'payLater',
    name: 'Book Now, Pay Later',
    enabled: false,
    description: 'Confirm your booking now and pay upon arrival or as per agreed terms. We will contact you to confirm payment details.',
    logo: '/payment-logos/pay-later.svg',
    fields: [
      { name: 'description', label: 'Description/Terms', type: 'textarea', placeholder: 'Explain the Pay Later terms to the user.' }
    ]
  }
};


export const PaymentGatewayProvider = ({ children }) => {
  const [gatewaySettings, setGatewaySettings] = useState(() => {
    const savedSettings = localStorage.getItem('abuDhabiPaymentGatewaySettings');
    if (savedSettings) {
      const parsedSettings = JSON.parse(savedSettings);
      // Merge with initial settings to ensure new gateways/fields are added
      const mergedSettings = {};
      Object.keys(initialGatewaySettings).forEach(key => {
        mergedSettings[key] = {
          ...initialGatewaySettings[key],
          ...(parsedSettings[key] || {})
        };
      });
      return mergedSettings;
    }
    return initialGatewaySettings;
  });

  useEffect(() => {
    localStorage.setItem('abuDhabiPaymentGatewaySettings', JSON.stringify(gatewaySettings));
  }, [gatewaySettings]);

  const updateGatewayConfig = (gatewayId, newConfig) => {
    setGatewaySettings(prev => ({
      ...prev,
      [gatewayId]: {
        ...prev[gatewayId],
        ...newConfig
      }
    }));
  };

  const toggleGatewayStatus = (gatewayId) => {
    setGatewaySettings(prev => ({
      ...prev,
      [gatewayId]: {
        ...prev[gatewayId],
        enabled: !prev[gatewayId].enabled
      }
    }));
  };
  
  const getActiveGateways = () => {
    return Object.values(gatewaySettings).filter(gateway => gateway.enabled);
  };

  const value = {
    gatewaySettings,
    updateGatewayConfig,
    toggleGatewayStatus,
    getActiveGateways,
    initialGatewaySettings // Expose initial settings for reference if needed
  };

  return (
    <PaymentGatewayContext.Provider value={value}>
      {children}
    </PaymentGatewayContext.Provider>
  );
};
