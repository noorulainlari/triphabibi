import React, { createContext, useContext, useState, useEffect } from 'react';

const TicketContext = createContext();

export const useTickets = () => {
  const context = useContext(TicketContext);
  if (!context) {
    throw new Error('useTickets must be used within a TicketProvider');
  }
  return context;
};

const initialTickets = [
  {
    id: 'tkt-burj-khalifa',
    name: 'Burj Khalifa - At The Top (Levels 124 & 125)',
    location: 'Dubai, UAE',
    shortDescription: "Access the world's tallest building's observation decks.",
    price: { adult: 4500, child: 3500, infant: 0 }, // INR
    status: 'Active', // Active, Hidden, Featured
    images: [{url: 'https://images.unsplash.com/photo-1523964603599-9918a720a0cd?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60', alt: 'Burj Khalifa Observation Deck'}],
    visitDateOptional: false, // If true, user doesn't need to select date/slot
    slotSystem: true, // If true, admin can define slots (e.g., 10:00 AM, 11:00 AM)
    slots: ['10:00 AM - 11:00 AM', '11:00 AM - 12:00 PM', '02:00 PM - 03:00 PM', '07:00 PM - 08:00 PM (Prime Hours)'],
    instantConfirmation: true,
    pdfTicketsUrl: '', // Link to a single PDF with multiple tickets (placeholder)
    totalTicketsInPdf: 0, // e.g., 100
    usedTicketPages: 0, // e.g., 4 (meaning pages 1-4 are used)
    autoTicketSend: true, // If true, system tries to send from PDF; if false, admin sends manually
    featured: true,
  },
  {
    id: 'tkt-louvre-abu-dhabi',
    name: 'Louvre Abu Dhabi General Admission',
    location: 'Abu Dhabi, UAE',
    shortDescription: 'Explore masterpieces of art and civilization at this iconic museum.',
    price: { adult: 1800, child: 0, infant: 0 }, // Children might be free or different price
    status: 'Active',
    images: [{url: 'https://images.unsplash.com/photo-1595872018818-97555653a011?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60', alt: 'Louvre Abu Dhabi Interior'}],
    visitDateOptional: false,
    slotSystem: false,
    slots: [],
    instantConfirmation: false, // Example: manual confirmation
    pdfTicketsUrl: '',
    totalTicketsInPdf: 0,
    usedTicketPages: 0,
    autoTicketSend: false,
    featured: false,
  },
];

export const TicketProvider = ({ children }) => {
  const [tickets, setTickets] = useState(() => {
    const savedTickets = localStorage.getItem('abuDhabiTickets');
    return savedTickets ? JSON.parse(savedTickets) : initialTickets;
  });
  
  const [ticketBookings, setTicketBookings] = useState(() => {
    const savedBookings = localStorage.getItem('abuDhabiTicketBookings');
    return savedBookings ? JSON.parse(savedBookings) : [];
  });


  useEffect(() => {
    localStorage.setItem('abuDhabiTickets', JSON.stringify(tickets));
  }, [tickets]);

  useEffect(() => {
    localStorage.setItem('abuDhabiTicketBookings', JSON.stringify(ticketBookings));
  }, [ticketBookings]);

  const addTicketOption = (ticketData) => {
    const newTicket = {
      ...ticketData,
      id: `tkt-${Date.now()}`,
    };
    setTickets(prev => [...prev, newTicket]);
  };

  const updateTicketOption = (id, updatedTicketData) => {
    setTickets(prev => prev.map(t => (t.id === id ? { ...t, ...updatedTicketData } : t)));
  };

  const deleteTicketOption = (id) => {
    setTickets(prev => prev.filter(t => t.id !== id));
  };

  const getTicketOptionById = (id) => {
    return tickets.find(t => t.id === id);
  };
  
  const getFeaturedTickets = () => {
    return tickets.filter(t => t.featured);
  };

  const addTicketBooking = (bookingData) => {
    const newBooking = {
        ...bookingData,
        bookingId: `TKTBOOK-${Date.now()}`,
        status: 'pending', // Default status, can be updated after payment
        createdAt: new Date().toISOString()
    };
    setTicketBookings(prev => [...prev, newBooking]);
    return newBooking; // Return the full booking object with ID
  };

  const updateTicketBookingStatus = (bookingId, status) => {
    setTicketBookings(prev => prev.map(b => 
      b.bookingId === bookingId ? { ...b, status } : b
    ));
  };


  const value = {
    tickets,
    ticketBookings,
    addTicketOption,
    updateTicketOption,
    deleteTicketOption,
    getTicketOptionById,
    getFeaturedTickets,
    addTicketBooking,
    updateTicketBookingStatus,
  };

  return (
    <TicketContext.Provider value={value}>
      {children}
    </TicketContext.Provider>
  );
};
