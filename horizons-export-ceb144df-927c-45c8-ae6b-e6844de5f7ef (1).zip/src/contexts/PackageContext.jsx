import React, { createContext, useContext, useState, useEffect } from 'react';

const PackageContext = createContext();

export const usePackages = () => {
  const context = useContext(PackageContext);
  if (!context) {
    throw new Error('usePackages must be used within a PackageProvider');
  }
  return context;
};

const initialPackages = [
  {
    id: 'pkg-dubai-4n5d',
    name: '4 Nights / 5 Days Dubai Extravaganza',
    shortDescription: 'Experience the best of Dubai: iconic landmarks, desert adventures, and luxury shopping.',
    description: 'An immersive journey through Dubai, covering all major attractions from Burj Khalifa to thrilling desert safaris. Includes accommodation, guided tours, and select meals.',
    duration: '5 Days / 4 Nights',
    price: { adult: 45000, child: 30000, infant: 5000 }, // INR
    status: 'Active', // Active, Hidden, Featured
    images: [{url: 'https://images.unsplash.com/photo-1518684079-3c830dcef090?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60', alt: 'Dubai Skyline'}],
    itinerary: [
      { day: 1, title: 'Arrival & Dhow Cruise Dinner', description: 'Arrive at Dubai International Airport, transfer to hotel. Evening Dhow Cruise with dinner.' },
      { day: 2, title: 'Dubai City Tour & Burj Khalifa', description: 'Half-day city tour: Dubai Museum, Jumeirah Mosque, Burj Al Arab (photo stop). Afternoon visit to Burj Khalifa "At The Top".' },
      { day: 3, title: 'Desert Safari Adventure', description: 'Morning free for leisure/shopping. Afternoon Desert Safari with dune bashing, camel ride, BBQ dinner, and cultural performances.' },
      { day: 4, title: 'Abu Dhabi City Tour (Optional)', description: 'Optional full-day tour to Abu Dhabi: Sheikh Zayed Grand Mosque, Emirates Palace, Qasr Al Watan. Or, day free in Dubai.' },
      { day: 5, title: 'Departure', description: 'Breakfast at hotel, check-out. Transfer to Dubai International Airport for departure.' },
    ],
    inclusions: ['4 nights hotel accommodation (4-star)', 'Daily breakfast', 'Airport transfers (shared)', 'Dhow Cruise Dinner', 'Dubai City Tour', 'Burj Khalifa Tickets (124th floor)', 'Desert Safari with BBQ Dinner'],
    exclusions: ['Flights', 'Visa fees', 'Optional Abu Dhabi Tour', 'Personal expenses', 'Lunches and dinners not mentioned'],
    hotelOptions: ['Hilton Garden Inn', 'Novotel Al Barsha'],
    transportOptions: ['Shared Coach', 'Private Car (optional upgrade)'],
    bookingType: 'direct', // 'direct' or 'enquiry'
    downloadableItineraryUrl: '', // Placeholder for PDF link
    featured: true,
  },
  // Add more packages if needed
];

export const PackageProvider = ({ children }) => {
  const [packages, setPackages] = useState(() => {
    const savedPackages = localStorage.getItem('abuDhabiPackages');
    return savedPackages ? JSON.parse(savedPackages) : initialPackages;
  });

  useEffect(() => {
    localStorage.setItem('abuDhabiPackages', JSON.stringify(packages));
  }, [packages]);

  const addPackage = (pkg) => {
    const newPackage = {
      ...pkg,
      id: `pkg-${Date.now()}`,
    };
    setPackages(prev => [...prev, newPackage]);
  };

  const updatePackage = (id, updatedPkg) => {
    setPackages(prev => prev.map(p => (p.id === id ? { ...p, ...updatedPkg } : p)));
  };

  const deletePackage = (id) => {
    setPackages(prev => prev.filter(p => p.id !== id));
  };

  const getPackageById = (id) => {
    return packages.find(p => p.id === id);
  };
  
  const getFeaturedPackages = () => {
    return packages.filter(p => p.featured);
  };


  const value = {
    packages,
    addPackage,
    updatePackage,
    deletePackage,
    getPackageById,
    getFeaturedPackages,
  };

  return (
    <PackageContext.Provider value={value}>
      {children}
    </PackageContext.Provider>
  );
};
