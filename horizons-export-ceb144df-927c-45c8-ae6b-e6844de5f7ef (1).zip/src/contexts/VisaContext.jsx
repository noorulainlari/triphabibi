import React, { createContext, useContext, useState, useEffect } from 'react';

const VisaContext = createContext();

export const useVisa = () => {
  const context = useContext(VisaContext);
  if (!context) {
    throw new Error('useVisa must be used within a VisaProvider');
  }
  return context;
};

const initialVisaOptions = [
  {
    id: 'uae-30d-single',
    countryCode: 'AE',
    countryName: 'United Arab Emirates',
    visaType: '30 Days Single Entry',
    processingTime: '3-5 working days',
    price: 8500, // INR
    description: 'Ideal for short trips, tourism, or visiting family in the UAE. Valid for 30 days from entry.',
    documentsRequired: ['Passport copy (min 6 months validity)', 'Passport size photograph (white background)', 'Confirmed return ticket (optional)', 'Hotel booking (optional)'],
    flagIconUrl: 'https://flagcdn.com/ae.svg',
    featured: true,
  },
  {
    id: 'uae-90d-single',
    countryCode: 'AE',
    countryName: 'United Arab Emirates',
    visaType: '90 Days Single Entry',
    processingTime: '3-5 working days',
    price: 18000, // INR
    description: 'Perfect for longer stays, extended tourism, or business visits. Allows a single entry for up to 90 days.',
    documentsRequired: ['Passport copy (min 6 months validity)', 'Passport size photograph (white background)', 'Confirmed return ticket', 'Hotel booking / Proof of accommodation'],
    flagIconUrl: 'https://flagcdn.com/ae.svg',
    featured: false,
  },
  {
    id: 'th-evoa',
    countryCode: 'TH',
    countryName: 'Thailand',
    visaType: 'E-Visa on Arrival (EVOA)',
    processingTime: '24-72 hours',
    price: 6000, // INR
    description: 'Convenient E-Visa on Arrival for eligible nationalities. Streamlines your entry process into Thailand.',
    documentsRequired: ['Passport copy (min 6 months validity)', 'Passport size photograph', 'Confirmed return ticket within 15 days', 'Proof of accommodation', 'Proof of funds (min 10,000 THB)'],
    flagIconUrl: 'https://flagcdn.com/th.svg',
    featured: true,
  },
    {
    id: 'sg-30d-multiple',
    countryCode: 'SG',
    countryName: 'Singapore',
    visaType: '30 Days Multiple Entry',
    processingTime: '5-7 working days',
    price: 3500, // INR
    description: 'Explore Singapore with the flexibility of multiple entries over a 30-day period.',
    documentsRequired: ['Passport copy (min 6 months validity)', 'Passport size photograph', 'Completed application form', 'Confirmed flight itinerary', 'Hotel booking'],
    flagIconUrl: 'https://flagcdn.com/sg.svg',
    featured: false,
  }
];

export const VisaProvider = ({ children }) => {
  const [visaOptions, setVisaOptions] = useState(() => {
    const savedVisaOptions = localStorage.getItem('abuDhabiVisaOptions');
    return savedVisaOptions ? JSON.parse(savedVisaOptions) : initialVisaOptions;
  });

  const [visaApplications, setVisaApplications] = useState(() => {
    const savedApplications = localStorage.getItem('abuDhabiVisaApplications');
    return savedApplications ? JSON.parse(savedApplications) : [];
  });

  useEffect(() => {
    localStorage.setItem('abuDhabiVisaOptions', JSON.stringify(visaOptions));
  }, [visaOptions]);

  useEffect(() => {
    localStorage.setItem('abuDhabiVisaApplications', JSON.stringify(visaApplications));
  }, [visaApplications]);

  const addVisaOption = (visaData) => {
    const newVisaOption = {
      ...visaData,
      id: `${visaData.countryCode.toLowerCase()}-${Date.now()}`, // More unique ID
      flagIconUrl: `https://flagcdn.com/${visaData.countryCode.toLowerCase()}.svg`
    };
    setVisaOptions(prev => [...prev, newVisaOption]);
  };

  const updateVisaOption = (id, updatedVisaData) => {
    setVisaOptions(prev => prev.map(visa => 
      visa.id === id ? { ...visa, ...updatedVisaData, flagIconUrl: `https://flagcdn.com/${updatedVisaData.countryCode.toLowerCase()}.svg` } : visa
    ));
  };

  const deleteVisaOption = (id) => {
    setVisaOptions(prev => prev.filter(visa => visa.id !== id));
  };

  const getVisaOptionById = (id) => {
    return visaOptions.find(visa => visa.id === id);
  };
  
  const getVisaOptionsByCountryCode = (countryCode) => {
    return visaOptions.filter(visa => visa.countryCode.toLowerCase() === countryCode.toLowerCase());
  };

  const getFeaturedVisaOptions = () => {
    return visaOptions.filter(visa => visa.featured);
  };

  const getAllCountriesWithVisas = () => {
    const countries = visaOptions.reduce((acc, visa) => {
      if (!acc.find(c => c.countryCode === visa.countryCode)) {
        acc.push({ 
          countryCode: visa.countryCode, 
          countryName: visa.countryName, 
          flagIconUrl: visa.flagIconUrl 
        });
      }
      return acc;
    }, []);
    return countries.sort((a, b) => a.countryName.localeCompare(b.countryName));
  };


  const addVisaApplication = (applicationData) => {
    const newApplication = {
      ...applicationData,
      applicationId: `VISA-${Date.now()}`,
      status: 'submitted', // Default status
      submittedAt: new Date().toISOString()
    };
    setVisaApplications(prev => [...prev, newApplication]);
    return newApplication;
  };
  
  const updateVisaApplicationStatus = (applicationId, status) => {
    setVisaApplications(prev => prev.map(app => 
      app.applicationId === applicationId ? { ...app, status } : app
    ));
  };


  const value = {
    visaOptions,
    visaApplications,
    addVisaOption,
    updateVisaOption,
    deleteVisaOption,
    getVisaOptionById,
    getVisaOptionsByCountryCode,
    getFeaturedVisaOptions,
    getAllCountriesWithVisas,
    addVisaApplication,
    updateVisaApplicationStatus,
  };

  return (
    <VisaContext.Provider value={value}>
      {children}
    </VisaContext.Provider>
  );
};