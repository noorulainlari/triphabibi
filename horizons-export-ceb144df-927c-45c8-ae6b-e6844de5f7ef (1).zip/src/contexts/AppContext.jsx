import React, { createContext, useContext, useState, useEffect } from 'react';

const AppContext = createContext();

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};

const initialUiTexts = {
  bookNowButton: 'Book Now',
  viewDetailsButton: 'View Details',
  enquireNowButton: 'Enquire Now',
  proceedToPaymentButton: 'Proceed to Payment',
  // Add more as needed
};

const initialAppSettings = {
  pickupLocationOptional: false,
  // Module toggles
  toursModuleEnabled: true,
  packagesModuleEnabled: true,
  ticketsModuleEnabled: true,
  visasModuleEnabled: true,
  blogModuleEnabled: true,
};

export const AppProvider = ({ children }) => {
  const [uiTexts, setUiTexts] = useState(() => {
    const savedUiTexts = localStorage.getItem('appUiTexts');
    return savedUiTexts ? JSON.parse(savedUiTexts) : initialUiTexts;
  });

  const [appSettings, setAppSettings] = useState(() => {
    const savedAppSettings = localStorage.getItem('appSettings');
    return savedAppSettings ? JSON.parse(savedAppSettings) : initialAppSettings;
  });

  useEffect(() => {
    localStorage.setItem('appUiTexts', JSON.stringify(uiTexts));
  }, [uiTexts]);

  useEffect(() => {
    localStorage.setItem('appSettings', JSON.stringify(appSettings));
  }, [appSettings]);

  const updateUiText = (key, value) => {
    setUiTexts(prev => ({ ...prev, [key]: value }));
  };
  
  const updateAppSetting = (key, value) => {
    setAppSettings(prev => ({ ...prev, [key]: value }));
  };


  const value = {
    uiTexts,
    appSettings,
    updateUiText,
    updateAppSetting,
    initialUiTexts, // For resetting or reference
    initialAppSettings,
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
};