import React, { createContext, useContext, useState, useEffect } from 'react';

const SliderContext = createContext();

export const useSliders = () => {
  const context = useContext(SliderContext);
  if (!context) {
    throw new Error('useSliders must be used within a SliderProvider');
  }
  return context;
};

const initialSlides = [
  {
    id: 'slide1',
    imageUrl: 'https://images.unsplash.com/photo-1580465446361-8aae73d93347?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    altText: 'Majestic Sheikh Zayed Grand Mosque',
    title: 'Explore Iconic Landmarks',
    description: 'Discover the breathtaking beauty of Abu Dhabi\'s architectural marvels.',
    buttonText: 'View City Tours',
    buttonLink: '/tours/city-tour',
    enabled: true,
    order: 1,
  },
  {
    id: 'slide2',
    imageUrl: 'https://images.unsplash.com/photo-1602002869034-e02991be0d38?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    altText: 'Thrilling Desert Safari Adventure',
    title: 'Unforgettable Desert Safaris',
    description: 'Experience the thrill of dune bashing and traditional Bedouin culture.',
    buttonText: 'Book Desert Safari',
    buttonLink: '/tours/desert-safari',
    enabled: true,
    order: 2,
  },
  {
    id: 'slide3',
    imageUrl: 'https://images.unsplash.com/photo-1512401490453-15e090170697?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    altText: 'Family fun at Ferrari World',
    title: 'Exciting Attraction Tickets',
    description: 'Get your tickets for Abu Dhabi\'s top theme parks and attractions.',
    buttonText: 'Browse Tickets',
    buttonLink: '/tickets',
    enabled: true,
    order: 3,
  }
];

export const SliderProvider = ({ children }) => {
  const [slides, setSlides] = useState(() => {
    const savedSlides = localStorage.getItem('homePageSliders');
    return savedSlides ? JSON.parse(savedSlides) : initialSlides;
  });

  useEffect(() => {
    localStorage.setItem('homePageSliders', JSON.stringify(slides));
  }, [slides]);

  const addSlide = (slideData) => {
    const newSlide = {
      ...slideData,
      id: `slide-${Date.now()}`,
      order: slides.length + 1, // Basic ordering
    };
    setSlides(prev => [...prev, newSlide]);
  };

  const updateSlide = (id, updatedSlideData) => {
    setSlides(prev => prev.map(s => (s.id === id ? { ...s, ...updatedSlideData } : s)));
  };

  const deleteSlide = (id) => {
    setSlides(prev => prev.filter(s => s.id !== id));
  };
  
  const updateSlideOrder = (reorderedSlides) => {
    setSlides(reorderedSlides.map((slide, index) => ({ ...slide, order: index + 1 })));
  };


  const getActiveSlides = () => {
    return slides.filter(slide => slide.enabled).sort((a, b) => a.order - b.order);
  };

  const value = {
    slides,
    addSlide,
    updateSlide,
    deleteSlide,
    updateSlideOrder,
    getActiveSlides,
  };

  return (
    <SliderContext.Provider value={value}>
      {children}
    </SliderContext.Provider>
  );
};
