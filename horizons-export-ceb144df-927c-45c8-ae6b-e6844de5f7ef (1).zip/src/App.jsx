import React from 'react';
import { HelmetProvider } from 'react-helmet-async';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import HomePage from '@/pages/HomePage';
import ToursPage from '@/pages/ToursPage';
import TourDetailPage from '@/pages/TourDetailPage';
import BookingPage from '@/pages/BookingPage';
import AdminPage from '@/pages/AdminPage';
import ContactPage from '@/pages/ContactPage';
import BlogPage from '@/pages/BlogPage';
import VisaPage from '@/pages/VisaPage';
import ApplyVisaPage from '@/pages/ApplyVisaPage';
import PackagesPage from '@/pages/PackagesPage';
import PackageDetailPage from '@/pages/PackageDetailPage';
import TicketsPage from '@/pages/TicketsPage';
import TicketBookingPage from '@/pages/TicketBookingPage';

import { AppProvider } from '@/contexts/AppContext';
import { TourProvider } from '@/contexts/TourContext';
import { AdminProvider } from '@/contexts/AdminContext';
import { VisaProvider } from '@/contexts/VisaContext';
import { PaymentGatewayProvider } from '@/contexts/PaymentGatewayContext';
import { PackageProvider } from '@/contexts/PackageContext';
import { TicketProvider } from '@/contexts/TicketContext';
import { SliderProvider } from '@/contexts/SliderContext';


function App() {
  return (
    <HelmetProvider>
      <AppProvider>
        <AdminProvider>
          <TourProvider>
            <VisaProvider>
              <PackageProvider>
                <TicketProvider>
                  <SliderProvider>
                    <PaymentGatewayProvider>
                      <Router>
                        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
                          <Routes>
                            <Route path="/" element={<HomePage />} />
                            <Route path="/tours" element={<ToursPage />} />
                            <Route path="/tours/:category" element={<ToursPage />} />
                            <Route path="/tour/:id" element={<TourDetailPage />} />
                            <Route path="/booking/:id" element={<BookingPage />} />
                            
                            <Route path="/packages" element={<PackagesPage />} />
                            <Route path="/package/:id" element={<PackageDetailPage />} />
                            {/* Booking for packages might need a different flow or just enquiry */}
                            
                            <Route path="/tickets" element={<TicketsPage />} />
                            <Route path="/ticket/book/:id" element={<TicketBookingPage />} />

                            <Route path="/admin" element={<AdminPage />} />
                            <Route path="/contact" element={<ContactPage />} />
                            <Route path="/blog" element={<BlogPage />} />
                            <Route path="/visas" element={<VisaPage />} />
                            <Route path="/apply-visa/:countryCode" element={<ApplyVisaPage />} />
                          </Routes>
                          <Toaster />
                        </div>
                      </Router>
                    </PaymentGatewayProvider>
                  </SliderProvider>
                </TicketProvider>
              </PackageProvider>
            </VisaProvider>
          </TourProvider>
        </AdminProvider>
      </AppProvider>
    </HelmetProvider>
  );
}

export default App;