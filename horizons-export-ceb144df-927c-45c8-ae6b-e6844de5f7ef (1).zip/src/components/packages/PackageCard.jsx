import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CalendarDays, Users, Star, Briefcase } from 'lucide-react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/contexts/AppContext';

const PackageCard = ({ pkg, index = 0 }) => {
  const { uiTexts } = useAppContext();
  const adultPrice = pkg.price?.adult;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ y: -5 }}
      className="h-full"
    >
      <Card className="h-full flex flex-col overflow-hidden group hover:shadow-xl transition-all duration-300 border-0 bg-white/80 backdrop-blur-sm">
        <div className="relative h-48 overflow-hidden">
          <img-replace
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
            alt={`${pkg.name || 'Tour Package Image'} - ${pkg.shortDescription || 'Exciting package'}`}
            src={pkg.images && pkg.images.length > 0 && pkg.images[0].url ? pkg.images[0].url : "https://images.unsplash.com/photo-1500930287589-c09b090c9060"} 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
          
          {(pkg.status === 'Featured' || pkg.featured) && (
            <div className="absolute top-4 left-4">
              <span className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
                ⭐ Featured
              </span>
            </div>
          )}

          {adultPrice && (
            <div className="absolute top-4 right-4">
                <div className="bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2">
                <span className="text-lg font-bold text-blue-600">₹{adultPrice.toLocaleString('en-IN')}</span>
                <span className="text-xs text-gray-600 block">per adult</span>
                </div>
            </div>
          )}
          
          <div className="absolute bottom-4 left-4">
            <span className="bg-blue-600/90 text-white px-3 py-1 rounded-full text-xs font-medium flex items-center">
              <Briefcase className="h-3 w-3 mr-1" /> Package
            </span>
          </div>
        </div>

        <CardContent className="p-6 flex-grow">
          <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
            {pkg.name}
          </h3>
          
          <p className="text-gray-600 text-sm mb-4 line-clamp-2">
            {pkg.shortDescription}
          </p>

          <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
            <div className="flex items-center space-x-1">
              <CalendarDays className="h-4 w-4" />
              <span>{pkg.duration}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span>{pkg.rating || 'Popular'}</span>
            </div>
          </div>
        </CardContent>

        <CardFooter className="p-6 pt-0 mt-auto">
          <div className="flex space-x-2 w-full">
            <Button 
              asChild 
              className="flex-1 bg-gradient-to-r from-blue-600 to-sky-600 hover:from-blue-700 hover:to-sky-700"
            >
              <Link to={`/package/${pkg.id}`}>
                {uiTexts.viewDetailsButton || "View Details"}
              </Link>
            </Button>
            {pkg.bookingType === 'direct' ? (
                <Button 
                    asChild 
                    variant="outline" 
                    className="flex-1 border-blue-600 text-blue-600 hover:bg-blue-50"
                    onClick={() => alert("🚧 Package booking not implemented yet. You can request this feature! 🚀")}
                >
                    {/* <Link to={`/book-package/${pkg.id}`}> */}
                    <span>{uiTexts.bookNowButton || "Book Now"}</span>
                    {/* </Link> */}
                </Button>
            ) : (
                <Button 
                    asChild 
                    variant="outline" 
                    className="flex-1 border-blue-600 text-blue-600 hover:bg-blue-50"
                    onClick={() => alert("🚧 Package enquiry not implemented yet. You can request this feature! 🚀")}
                >
                     {/* <Link to={`/enquire-package/${pkg.id}`}> */}
                    <span>{uiTexts.enquireNowButton || "Enquire Now"}</span>
                    {/* </Link> */}
                </Button>
            )}
          </div>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default PackageCard;