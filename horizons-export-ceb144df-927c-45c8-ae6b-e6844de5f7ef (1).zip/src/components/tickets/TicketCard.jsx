import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Ticket, MapPin, Star, FileBadge as CheckBadgeIcon } from 'lucide-react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/contexts/AppContext';

const TicketCard = ({ ticket, index = 0 }) => {
  const { uiTexts } = useAppContext();
  const adultPrice = ticket.price?.adult;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ y: -5 }}
      className="h-full"
    >
      <Card className="h-full flex flex-col overflow-hidden group hover:shadow-xl transition-all duration-300 border-0 bg-white/80 backdrop-blur-sm">
        <div className="relative h-48 overflow-hidden">
          <img-replace
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
            alt={`${ticket.name || 'Attraction Ticket Image'} - ${ticket.shortDescription || 'Exciting attraction'}`}
            src={ticket.images && ticket.images.length > 0 && ticket.images[0].url ? ticket.images[0].url : "https://images.unsplash.com/photo-1540450942234-c39800909901"} 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
          
          {(ticket.status === 'Featured' || ticket.featured) && (
            <div className="absolute top-4 left-4">
              <span className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
                ⭐ Featured
              </span>
            </div>
          )}

          {adultPrice && (
            <div className="absolute top-4 right-4">
                <div className="bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2">
                <span className="text-lg font-bold text-green-600">₹{adultPrice.toLocaleString('en-IN')}</span>
                <span className="text-xs text-gray-600 block">per adult</span>
                </div>
            </div>
          )}
          
          <div className="absolute bottom-4 left-4">
            <span className="bg-green-600/90 text-white px-3 py-1 rounded-full text-xs font-medium flex items-center">
              <Ticket className="h-3 w-3 mr-1" /> Ticket
            </span>
          </div>
        </div>

        <CardContent className="p-6 flex-grow">
          <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-green-600 transition-colors">
            {ticket.name}
          </h3>
          
          <p className="text-gray-600 text-sm mb-4 line-clamp-2">
            {ticket.shortDescription}
          </p>

          <div className="flex items-center text-sm text-gray-500 mb-2">
            <MapPin className="h-4 w-4 mr-1" />
            <span>{ticket.location}</span>
          </div>
          {ticket.instantConfirmation && (
            <div className="flex items-center text-sm text-green-600 font-medium">
                <CheckBadgeIcon className="h-4 w-4 mr-1 fill-green-500 text-white"/>
                <span>Instant Confirmation</span>
            </div>
          )}
        </CardContent>

        <CardFooter className="p-6 pt-0 mt-auto">
            <Button 
              asChild 
              className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
            >
              <Link to={`/ticket/book/${ticket.id}`}>
                {uiTexts.bookNowButton || "Book Ticket"}
              </Link>
            </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default TicketCard;