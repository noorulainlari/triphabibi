import React from 'react';
import { CreditCard, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAdmin } from '@/contexts/AdminContext';
import { useToast } from '@/components/ui/use-toast';

const BookingForm = ({ bookingData, setBookingData, promoDiscount, setPromoDiscount, onSubmit, isProcessing }) => {
  const { validatePromoCode } = useAdmin();
  const { toast } = useToast();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setBookingData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePromoCodeApply = () => {
    if (!bookingData.promoCode.trim()) {
      toast({ title: "Please enter a promo code", variant: "destructive" });
      return;
    }
    const promo = validatePromoCode(bookingData.promoCode);
    if (promo) {
      setPromoDiscount(promo);
      toast({ title: "Promo code applied!", description: `${promo.discount}% discount applied.` });
    } else {
      setPromoDiscount(null);
      toast({ title: "Invalid promo code", variant: "destructive" });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-2xl">Book Your Tour</CardTitle>
        <p className="text-gray-600">Fill in your details to secure your spot</p>
      </CardHeader>
      <CardContent>
        <form onSubmit={(e) => { e.preventDefault(); onSubmit(); }} className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold mb-4">Personal Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">First Name *</Label>
                <Input id="firstName" name="firstName" value={bookingData.firstName} onChange={handleInputChange} required />
              </div>
              <div>
                <Label htmlFor="lastName">Last Name *</Label>
                <Input id="lastName" name="lastName" value={bookingData.lastName} onChange={handleInputChange} required />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input id="email" name="email" type="email" value={bookingData.email} onChange={handleInputChange} required />
              </div>
              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <Input id="phone" name="phone" type="tel" value={bookingData.phone} onChange={handleInputChange} required />
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Tour Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="date">Preferred Date *</Label>
                <Input id="date" name="date" type="date" value={bookingData.date} onChange={handleInputChange} min={new Date().toISOString().split('T')[0]} required />
              </div>
              <div>
                <Label htmlFor="adults">Adults</Label>
                <select id="adults" name="adults" value={bookingData.adults} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-600">
                  {[1,2,3,4,5,6,7,8].map(num => <option key={num} value={num}>{num}</option>)}
                </select>
              </div>
              <div>
                <Label htmlFor="children">Children (2-12 yrs)</Label>
                <select id="children" name="children" value={bookingData.children} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-600">
                  {[0,1,2,3,4,5,6].map(num => <option key={num} value={num}>{num}</option>)}
                </select>
              </div>
              <div>
                <Label htmlFor="infants">Infants (Under 2 yrs)</Label>
                <select id="infants" name="infants" value={bookingData.infants} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-600">
                  {[0,1,2,3,4].map(num => <option key={num} value={num}>{num}</option>)}
                </select>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Promo Code</h3>
            <div className="flex gap-2">
              <Input name="promoCode" placeholder="Enter promo code" value={bookingData.promoCode} onChange={handleInputChange} className="flex-1" />
              <Button type="button" variant="outline" onClick={handlePromoCodeApply}>Apply</Button>
            </div>
            {promoDiscount && (
              <div className="mt-2 p-3 bg-green-50 border border-green-200 rounded-md">
                <div className="flex items-center space-x-2 text-green-700">
                  <Check className="h-4 w-4" />
                  <span>Promo code applied: {promoDiscount.discount}% off</span>
                </div>
              </div>
            )}
          </div>

          <div>
            <Label htmlFor="specialRequests">Special Requests</Label>
            <textarea id="specialRequests" name="specialRequests" value={bookingData.specialRequests} onChange={handleInputChange} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-600" placeholder="Any special requirements or requests..." />
          </div>

          <Button type="submit" className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-lg py-6" disabled={isProcessing}>
            {isProcessing ? (
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Processing...</span>
              </div>
            ) : (
              <><CreditCard className="mr-2 h-5 w-5" /> Proceed to Payment</>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default BookingForm;