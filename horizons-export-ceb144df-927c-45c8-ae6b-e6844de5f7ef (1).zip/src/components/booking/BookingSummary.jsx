import React from 'react';
import { Calendar, Users, Shield, Tag, Baby } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const BookingSummary = ({ tour, bookingData, totalPrice, promoDiscount }) => {
  const basePrice = tour.price * (parseInt(bookingData.adults) + parseInt(bookingData.children) * 0.7);
  const savings = promoDiscount ? (basePrice - totalPrice) : 0;
  
  return (
    <div className="sticky top-24 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Booking Summary</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex space-x-4">
            <img  
              className="w-20 h-20 object-cover rounded-lg"
              alt={tour.title}
             src="https://images.unsplash.com/photo-1632178151697-fd971baa906f" />
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900">{tour.title}</h3>
              <p className="text-sm text-gray-600">{tour.duration}</p>
              <div className="flex items-center space-x-1 mt-1">
                <Calendar className="h-4 w-4 text-gray-400" />
                <span className="text-sm text-gray-600">{bookingData.date || 'Select date'}</span>
              </div>
            </div>
          </div>

          <div className="border-t pt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="flex items-center"><Users className="h-4 w-4 mr-1 text-gray-500"/>Adults ({bookingData.adults})</span>
              <span>₹{(tour.price * parseInt(bookingData.adults)).toLocaleString('en-IN')}</span>
            </div>
            {parseInt(bookingData.children) > 0 && (
              <div className="flex justify-between text-sm">
                <span className="flex items-center"><Users className="h-4 w-4 mr-1 text-gray-500"/>Children ({bookingData.children})</span>
                <span>₹{(tour.price * parseInt(bookingData.children) * 0.7).toLocaleString('en-IN')}</span>
              </div>
            )}
            {parseInt(bookingData.infants) > 0 && (
              <div className="flex justify-between text-sm">
                 <span className="flex items-center"><Baby className="h-4 w-4 mr-1 text-gray-500"/>Infants ({bookingData.infants})</span>
                <span>Free</span>
              </div>
            )}
            {savings > 0 && (
              <div className="flex justify-between text-sm text-green-600">
                <span className="flex items-center"><Tag className="h-4 w-4 mr-1"/>Discount ({promoDiscount.discount}%)</span>
                <span>-₹{savings.toLocaleString('en-IN')}</span>
              </div>
            )}
            <div className="border-t pt-2 flex justify-between font-semibold">
              <span>Total</span>
              <span className="text-purple-600">₹{totalPrice.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-3 text-sm text-gray-600">
            <Shield className="h-5 w-5 text-green-500" />
            <div>
              <p className="font-medium">Secure Booking</p>
              <p>Your information is protected with SSL encryption</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Cancellation Policy</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-gray-600 space-y-2">
          <p>• Free cancellation up to 24 hours before the tour</p>
          <p>• 50% refund for cancellations within 24 hours</p>
          <p>• No refund for no-shows</p>
          <p>• Weather-related cancellations are fully refundable</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default BookingSummary;