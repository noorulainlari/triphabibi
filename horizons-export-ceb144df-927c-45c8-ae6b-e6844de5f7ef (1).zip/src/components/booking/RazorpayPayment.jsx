import React, { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const RazorpayPayment = ({ amount, bookingData, onSuccess, onError, tourTitle }) => {
  const { toast } = useToast();

  useEffect(() => {
    const script = document.getElementById('razorpay-checkout-js');
    if (!script) {
      const newScript = document.createElement('script');
      newScript.id = 'razorpay-checkout-js';
      newScript.src = 'https://checkout.razorpay.com/v1/checkout.js';
      newScript.async = true;
      document.body.appendChild(newScript);
    }
  }, []);

  const handlePayment = () => {
    // IMPORTANT: Replace 'YOUR_RAZORPAY_KEY_ID' with your actual Razorpay Key ID
    // This key should ideally be fetched from environment variables in a real application
    const razorpayKeyId = 'YOUR_RAZORPAY_KEY_ID'; 

    if (razorpayKeyId === 'YOUR_RAZORPAY_KEY_ID') {
        toast({
            title: "Razorpay Not Configured",
            description: "Please replace 'YOUR_RAZORPAY_KEY_ID' in RazorpayPayment.jsx with your actual Razorpay Key ID to enable payments.",
            variant: "destructive",
            duration: 10000,
        });
        // Simulate payment success for demo purposes if key is not set
        // In a real app, you would not do this.
        console.warn("Razorpay Key ID not set. Simulating payment success for demo.");
        onSuccess({ razorpay_payment_id: `simulated_${Date.now()}` });
        return;
    }


    const options = {
      key: razorpayKeyId,
      amount: Math.round(amount * 100), // Amount in paise (ensure it's an integer)
      currency: 'INR',
      name: 'Abu Dhabi Layover Tours',
      description: `Booking for ${tourTitle}`,
      image: '/vite.svg', 
      handler: function (response) {
        onSuccess(response);
        // Here you would typically send a confirmation email/SMS via a backend service
        toast({
          title: "Payment Successful!",
          description: "Confirmation details will be sent (placeholder for email/SMS)."
        });
      },
      prefill: {
        name: `${bookingData.firstName} ${bookingData.lastName}`,
        email: bookingData.email,
        contact: bookingData.phone,
      },
      notes: {
        tour_id: bookingData.tourId || tourTitle, // Ensure tourId is passed
        adults: bookingData.adults,
        children: bookingData.children,
        infants: bookingData.infants,
      },
      theme: {
        color: '#6B46C1', 
      },
      modal: {
        ondismiss: function() {
          onError({ code: 'PAYMENT_CANCELLED', description: 'Payment was cancelled by user.' });
        }
      }
    };

    if (window.Razorpay) {
      const rzp = new window.Razorpay(options);
      rzp.on('payment.failed', function (response) {
        onError({
            code: response.error.code,
            description: response.error.description,
            source: response.error.source,
            step: response.error.step,
            reason: response.error.reason,
            metadata: response.error.metadata || {}
        });
      });
      rzp.open();
    } else {
      onError({ code: 'RAZORPAY_SDK_NOT_LOADED', description: 'Razorpay SDK failed to load. Please check your internet connection or script inclusion.' });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-2xl">Confirm Payment</CardTitle>
        <p className="text-gray-600">Final step to secure your amazing tour!</p>
      </CardHeader>
      <CardContent className="space-y-6 text-center">
        <div className="text-4xl font-bold text-purple-600">
          ₹{amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>
        <p className="text-gray-700">
          You are about to book the <strong>{tourTitle}</strong> for {bookingData.adults} adult(s)
          {bookingData.children > 0 && `, ${bookingData.children} child(ren)`}
          {bookingData.infants > 0 && `, ${bookingData.infants} infant(s)`}.
        </p>
        <p className="text-sm text-gray-500">
          Click the button below to proceed with Razorpay.
        </p>
        <Button
          onClick={handlePayment}
          className="w-full max-w-xs mx-auto bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-lg py-6"
        >
          Pay with Razorpay
        </Button>
         <p className="text-xs text-gray-500 mt-4">
          Ensure you have replaced 'YOUR_RAZORPAY_KEY_ID' in the code with your actual key for live payments.
        </p>
      </CardContent>
    </Card>
  );
};

export default RazorpayPayment;