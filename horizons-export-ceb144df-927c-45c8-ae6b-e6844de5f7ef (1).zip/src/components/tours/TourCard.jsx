import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Clock, Users, Star } from 'lucide-react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/contexts/AppContext';

const TourCard = ({ tour, index = 0 }) => {
  const { uiTexts } = useAppContext();
  
  const adultPrice = tour.pricing?.adult || tour.price; // Fallback to old price structure
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ y: -5 }}
      className="h-full"
    >
      <Card className="h-full flex flex-col overflow-hidden group hover:shadow-xl transition-all duration-300 border-0 bg-white/80 backdrop-blur-sm">
        <div className="relative h-48 overflow-hidden">
          <img  
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
            alt={`${tour.title || 'Tour Image'} - ${tour.description || 'Exciting tour'}`}
           src={tour.images && tour.images.length > 0 && tour.images[0].url ? tour.images[0].url : "https://images.unsplash.com/photo-1632178151697-fd971baa906f"} />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
          
          {tour.status === 'Featured' && (
            <div className="absolute top-4 left-4">
              <span className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
                ⭐ Featured
              </span>
            </div>
          )}

          <div className="absolute top-4 right-4">
            <div className="bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2">
              <span className="text-lg font-bold text-purple-600">₹{adultPrice?.toLocaleString('en-IN')}</span>
              <span className="text-xs text-gray-600 block">
                {tour.priceType || (tour.pricing ? 'per adult' : 'per person')}
              </span>
            </div>
          </div>

          <div className="absolute bottom-4 left-4">
            <span className="bg-purple-600/90 text-white px-3 py-1 rounded-full text-xs font-medium">
              {tour.category?.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase()) || 'General'}
            </span>
          </div>
        </div>

        <CardContent className="p-6 flex-grow">
          <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-purple-600 transition-colors">
            {tour.title}
          </h3>
          
          <p className="text-gray-600 text-sm mb-4 line-clamp-2">
            {tour.shortDescription || tour.description}
          </p>

          <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
            <div className="flex items-center space-x-1">
              <Clock className="h-4 w-4" />
              <span>{tour.duration}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Users className="h-4 w-4" />
              <span>Group Tour</span>
            </div>
            <div className="flex items-center space-x-1">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span>{tour.rating || '4.9'}</span>
            </div>
          </div>

          {tour.highlights && tour.highlights.length > 0 && (
            <div className="space-y-1">
              {tour.highlights.slice(0, 2).map((highlight, idx) => (
                <div key={idx} className="flex items-center space-x-2 text-sm text-gray-600">
                  <div className="w-1.5 h-1.5 bg-purple-600 rounded-full" />
                  <span>{highlight}</span>
                </div>
              ))}
            </div>
          )}
        </CardContent>

        <CardFooter className="p-6 pt-0 space-y-3 mt-auto">
          <div className="flex space-x-2 w-full">
            <Button 
              asChild 
              className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              <Link to={`/tour/${tour.id}`}>
                {uiTexts.viewDetailsButton || "View Details"}
              </Link>
            </Button>
            <Button 
              asChild 
              variant="outline" 
              className="flex-1 border-purple-600 text-purple-600 hover:bg-purple-50"
            >
              <Link to={`/booking/${tour.id}`}>
                {uiTexts.bookNowButton || "Book Now"}
              </Link>
            </Button>
          </div>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default TourCard;