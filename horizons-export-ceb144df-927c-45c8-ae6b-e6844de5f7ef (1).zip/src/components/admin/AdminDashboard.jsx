import React from 'react';
import { LogOut, ShieldCheck, Home, Settings, BarChart2, ShoppingBag, Briefcase, Ticket as TicketIcon, Plane } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import AdminStats from '@/components/admin/AdminStats';
import ManageTours from '@/components/admin/ManageTours';
import ManageBookings from '@/components/admin/ManageBookings';
import ManagePromoCodes from '@/components/admin/ManagePromoCodes';
import ManageVisas from '@/components/admin/ManageVisas'; 
import AdminSettings from '@/components/admin/AdminSettings';
import ManagePackages from '@/components/admin/ManagePackages';
import ManageTickets from '@/components/admin/ManageTickets';
import ManageSliders from '@/components/admin/ManageSliders';

const AdminDashboard = ({ onLogout }) => {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-gradient-to-r from-purple-700 to-blue-700 text-white shadow-lg">
        <div className="container mx-auto px-4 py-5">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
               <ShieldCheck className="h-8 w-8" />
               <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            </div>
            <Button variant="outline" onClick={onLogout} className="bg-white/20 hover:bg-white/30 text-white border-white/50">
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>
      <div className="container mx-auto px-4 py-8">
        <AdminStats />
        <Tabs defaultValue="dashboard" className="space-y-6 mt-10">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-1 bg-white p-1.5 rounded-lg shadow-md">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center justify-center py-2.5"><Home className="h-4 w-4 mr-1.5"/>Dashboard</TabsTrigger>
            <TabsTrigger value="tours" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center justify-center py-2.5"><ShoppingBag className="h-4 w-4 mr-1.5"/>Tours</TabsTrigger>
            <TabsTrigger value="packages" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center justify-center py-2.5"><Briefcase className="h-4 w-4 mr-1.5"/>Packages</TabsTrigger>
            <TabsTrigger value="tickets" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center justify-center py-2.5"><TicketIcon className="h-4 w-4 mr-1.5"/>Tickets</TabsTrigger>
            <TabsTrigger value="bookings" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center justify-center py-2.5"><BarChart2 className="h-4 w-4 mr-1.5"/>Bookings</TabsTrigger>
            <TabsTrigger value="visas" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center justify-center py-2.5"><Plane className="h-4 w-4 mr-1.5"/>Visas</TabsTrigger>
            <TabsTrigger value="promos" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center justify-center py-2.5">Promos</TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center justify-center py-2.5"><Settings className="h-4 w-4 mr-1.5"/>Settings</TabsTrigger>
          </TabsList>
          <TabsContent value="dashboard">
            <ManageSliders />
          </TabsContent>
          <TabsContent value="tours"><ManageTours /></TabsContent>
          <TabsContent value="packages"><ManagePackages /></TabsContent>
          <TabsContent value="tickets"><ManageTickets /></TabsContent>
          <TabsContent value="bookings"><ManageBookings /></TabsContent>
          <TabsContent value="visas"><ManageVisas /></TabsContent>
          <TabsContent value="promos"><ManagePromoCodes /></TabsContent>
          <TabsContent value="settings"><AdminSettings /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;