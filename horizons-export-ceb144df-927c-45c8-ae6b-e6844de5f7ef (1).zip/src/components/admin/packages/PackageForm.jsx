import React, { useState } from 'react';
import { Plus, Edit, Trash2, Briefcase, Image as ImageIcon, FileText, DollarSign, Users, Bed, Car, CalendarDays, CheckCircle, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { DialogFooter } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/components/ui/use-toast';

const PackageForm = ({ initialData, onSubmit, onCancel, formType }) => {
  const { toast } = useToast();
  const [packageData, setPackageData] = useState(initialData || {
    name: '',
    shortDescription: '',
    description: '',
    duration: '', 
    price: { adult: '', child: '', infant: '' },
    status: 'Active', 
    images: [], 
    itinerary: [{ day: 1, title: '', description: '' }],
    inclusions: [''],
    exclusions: [''],
    hotelOptions: [''],
    transportOptions: [''],
    bookingType: 'direct', 
    downloadableItineraryUrl: '',
    featured: false,
  });

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
     if (name.startsWith("price.")) {
      const field = name.split(".")[1];
      setPackageData(prev => ({ ...prev, price: { ...prev.price, [field]: value } }));
    } else if (type === 'checkbox') {
      setPackageData(prev => ({ ...prev, [name]: checked }));
    }
    else {
      setPackageData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleArrayItemChange = (arrayName, index, field, value) => {
    const updatedArray = [...packageData[arrayName]];
    if (typeof updatedArray[index] === 'object') {
        updatedArray[index] = { ...updatedArray[index], [field]: value };
    } else {
        updatedArray[index] = value;
    }
    setPackageData(prev => ({ ...prev, [arrayName]: updatedArray }));
  };

  const addArrayItem = (arrayName, itemStructure = '') => {
    if (arrayName === 'itinerary') {
      itemStructure = { day: packageData.itinerary.length + 1, title: '', description: '' };
    }
    setPackageData(prev => ({ ...prev, [arrayName]: [...prev[arrayName], itemStructure] }));
  };

  const removeArrayItem = (arrayName, index) => {
    if (packageData[arrayName].length > 1) {
      const updatedArray = packageData[arrayName].filter((_, i) => i !== index);
      setPackageData(prev => ({ ...prev, [arrayName]: updatedArray }));
    } else if (packageData[arrayName].length === 1 && arrayName !== 'images') {
       setPackageData(prev => ({ ...prev, [arrayName]: arrayName === 'itinerary' ? [{ day: 1, title: '', description: '' }] : [''] }));
    }
  };
  
  const handleImageUpload = (event) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setPackageData(prev => ({ ...prev, images: [...prev.images, { url: reader.result, alt: file.name }] }));
        toast({ title: "Image Added (Simulated)", description: `${file.name} added. Save package to persist.`, variant: "default" });
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = (index) => {
    setPackageData(prev => ({ ...prev, images: prev.images.filter((_, i) => i !== index) }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const processedData = {
      ...packageData,
      price: {
        adult: parseFloat(packageData.price.adult) || 0,
        child: parseFloat(packageData.price.child) || 0,
        infant: parseFloat(packageData.price.infant) || 0,
      },
      inclusions: packageData.inclusions.filter(item => item.trim()),
      exclusions: packageData.exclusions.filter(item => item.trim()),
      hotelOptions: packageData.hotelOptions.filter(item => item.trim()),
      transportOptions: packageData.transportOptions.filter(item => item.trim()),
    };
    onSubmit(processedData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div><Label htmlFor={`${formType}-pkg-name`} className="flex items-center"><Briefcase className="h-4 w-4 mr-2"/>Package Name*</Label><Input id={`${formType}-pkg-name`} name="name" value={packageData.name} onChange={handleInputChange} required /></div>
        <div><Label htmlFor={`${formType}-pkg-duration`} className="flex items-center"><CalendarDays className="h-4 w-4 mr-2"/>Duration* (e.g., 5 Days / 4 Nights)</Label><Input id={`${formType}-pkg-duration`} name="duration" value={packageData.duration} onChange={handleInputChange} required /></div>
      </div>
      <div><Label htmlFor={`${formType}-pkg-shortDescription`}>Short Description (for cards)</Label><Textarea id={`${formType}-pkg-shortDescription`} name="shortDescription" value={packageData.shortDescription} onChange={handleInputChange} rows={2} /></div>
      <div><Label htmlFor={`${formType}-pkg-description`}>Full Description*</Label><Textarea id={`${formType}-pkg-description`} name="description" value={packageData.description} onChange={handleInputChange} rows={4} required /></div>

      <Card className="bg-gray-50 p-4">
        <CardHeader className="p-2"><CardTitle className="text-lg flex items-center"><DollarSign className="h-5 w-5 mr-2 text-green-600"/>Pricing (INR)*</CardTitle></CardHeader>
        <CardContent className="p-2 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div><Label htmlFor={`${formType}-pkg-price.adult`}>Adult</Label><Input id={`${formType}-pkg-price.adult`} name="price.adult" type="number" step="0.01" value={packageData.price.adult} onChange={handleInputChange} required /></div>
          <div><Label htmlFor={`${formType}-pkg-price.child`}>Child</Label><Input id={`${formType}-pkg-price.child`} name="price.child" type="number" step="0.01" value={packageData.price.child} onChange={handleInputChange} /></div>
          <div><Label htmlFor={`${formType}-pkg-price.infant`}>Infant</Label><Input id={`${formType}-pkg-price.infant`} name="price.infant" type="number" step="0.01" value={packageData.price.infant} onChange={handleInputChange} /></div>
        </CardContent>
      </Card>

      <div>
        <Label className="flex items-center"><FileText className="h-4 w-4 mr-2"/>Day-wise Itinerary*</Label>
        {packageData.itinerary.map((item, index) => (
          <Card key={index} className="mb-3 p-4 border rounded-md bg-white">
            <Label>Day {item.day}</Label>
            <Input value={item.title} onChange={(e) => handleArrayItemChange('itinerary', index, 'title', e.target.value)} placeholder="Day Title (e.g., Arrival & City Tour)" className="mb-2"/>
            <Textarea value={item.description} onChange={(e) => handleArrayItemChange('itinerary', index, 'description', e.target.value)} placeholder="Day Description..." rows={2}/>
            {packageData.itinerary.length > 1 && <Button type="button" variant="ghost" size="sm" onClick={() => removeArrayItem('itinerary', index)} className="mt-2 text-red-500 float-right"><Trash2 className="h-4 w-4"/></Button>}
          </Card>
        ))}
        <Button type="button" variant="outline" onClick={() => addArrayItem('itinerary')}>Add Day</Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
            <Label className="flex items-center"><CheckCircle className="h-4 w-4 mr-2 text-green-500"/>Inclusions</Label>
            {packageData.inclusions.map((item, index) => (<div key={index} className="flex gap-2 mb-1"><Input value={item} onChange={(e) => handleArrayItemChange('inclusions', index, null, e.target.value)} /><Button type="button" variant="ghost" size="icon" onClick={() => removeArrayItem('inclusions', index)} className="text-red-500 shrink-0"><Trash2 className="h-4 w-4"/></Button></div>))}
            <Button type="button" variant="outline" size="sm" onClick={() => addArrayItem('inclusions')}>Add Inclusion</Button>
        </div>
        <div>
            <Label className="flex items-center"><XCircle className="h-4 w-4 mr-2 text-red-500"/>Exclusions</Label>
            {packageData.exclusions.map((item, index) => (<div key={index} className="flex gap-2 mb-1"><Input value={item} onChange={(e) => handleArrayItemChange('exclusions', index, null, e.target.value)} /><Button type="button" variant="ghost" size="icon" onClick={() => removeArrayItem('exclusions', index)} className="text-red-500 shrink-0"><Trash2 className="h-4 w-4"/></Button></div>))}
            <Button type="button" variant="outline" size="sm" onClick={() => addArrayItem('exclusions')}>Add Exclusion</Button>
        </div>
        <div>
            <Label className="flex items-center"><Bed className="h-4 w-4 mr-2"/>Hotel Options (optional)</Label>
            {packageData.hotelOptions.map((item, index) => (<div key={index} className="flex gap-2 mb-1"><Input value={item} onChange={(e) => handleArrayItemChange('hotelOptions', index, null, e.target.value)} placeholder="e.g., 4-Star Hotel Name"/> <Button type="button" variant="ghost" size="icon" onClick={() => removeArrayItem('hotelOptions', index)} className="text-red-500 shrink-0"><Trash2 className="h-4 w-4"/></Button></div>))}
            <Button type="button" variant="outline" size="sm" onClick={() => addArrayItem('hotelOptions')}>Add Hotel Option</Button>
        </div>
        <div>
            <Label className="flex items-center"><Car className="h-4 w-4 mr-2"/>Transport Options (optional)</Label>
            {packageData.transportOptions.map((item, index) => (<div key={index} className="flex gap-2 mb-1"><Input value={item} onChange={(e) => handleArrayItemChange('transportOptions', index, null, e.target.value)} placeholder="e.g., Shared Coach, Private SUV"/> <Button type="button" variant="ghost" size="icon" onClick={() => removeArrayItem('transportOptions', index)} className="text-red-500 shrink-0"><Trash2 className="h-4 w-4"/></Button></div>))}
            <Button type="button" variant="outline" size="sm" onClick={() => addArrayItem('transportOptions')}>Add Transport Option</Button>
        </div>
      </div>

      <div>
        <Label className="flex items-center"><ImageIcon className="h-4 w-4 mr-2"/>Images</Label>
        <Input type="file" id={`${formType}-pkg-image-upload`} onChange={handleImageUpload} accept="image/*" className="mb-2"/>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">
            {packageData.images.map((img, idx) => (<div key={idx} className="relative group aspect-video"><img-replace src={img.url} alt={img.alt || `Package Image ${idx+1}`} className="rounded-md object-cover w-full h-full"/><Button type="button" variant="destructive" size="icon" onClick={() => removeImage(idx)} className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 className="h-3 w-3" /></Button></div>))}
        </div>
        <p className="text-xs text-gray-500 mt-1">Images are simulated. Actual upload requires backend.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        <div>
          <Label htmlFor={`${formType}-pkg-status`}>Status*</Label>
          <select id={`${formType}-pkg-status`} name="status" value={packageData.status} onChange={handleInputChange} className="w-full px-3 py-2 border border-input rounded-md">
            <option value="Active">Active</option>
            <option value="Hidden">Hidden</option>
            <option value="Featured">Featured</option>
          </select>
        </div>
        <div>
          <Label htmlFor={`${formType}-pkg-bookingType`}>Booking Type*</Label>
          <select id={`${formType}-pkg-bookingType`} name="bookingType" value={packageData.bookingType} onChange={handleInputChange} className="w-full px-3 py-2 border border-input rounded-md">
            <option value="direct">Direct Booking</option>
            <option value="enquiry">Enquiry Only</option>
          </select>
        </div>
      </div>
      <div>
          <Label htmlFor={`${formType}-pkg-downloadableItineraryUrl`}>Downloadable PDF Itinerary URL (optional)</Label>
          <Input id={`${formType}-pkg-downloadableItineraryUrl`} name="downloadableItineraryUrl" value={packageData.downloadableItineraryUrl} onChange={handleInputChange} placeholder="https://example.com/itinerary.pdf"/>
      </div>
       <div className="flex items-center space-x-2">
          <Switch id={`${formType}-pkg-featured`} name="featured" checked={packageData.featured} onCheckedChange={(checked) => handleInputChange({target: {name: "featured", checked, type:"checkbox"}})} />
          <Label htmlFor={`${formType}-pkg-featured`}>Mark as Featured Package</Label>
        </div>
      
      <DialogFooter className="pt-6">
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
        <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white">
            {formType === 'add' ? <><Plus className="h-4 w-4 mr-2"/>Add Package</> : <><Edit className="h-4 w-4 mr-2"/>Update Package</>}
        </Button>
      </DialogFooter>
    </form>
  );
};

export default PackageForm;