import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Users, TrendingUp } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { useTours } from '@/contexts/TourContext';

const AdminStats = () => {
  const { tours, bookings } = useTours();

  const totalRevenue = bookings.reduce((sum, booking) => sum + (booking.totalAmount || 0), 0);

  const stats = [
    {
      title: 'Total Bookings',
      value: bookings.length,
      icon: Calendar,
      color: 'bg-blue-500'
    },
    {
      title: 'Total Revenue (INR)',
      value: `₹${totalRevenue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      icon: () => <span className="font-bold text-xl">₹</span>, // Custom icon for INR
      color: 'bg-green-500'
    },
    {
      title: 'Active Tours',
      value: tours.length,
      icon: Users,
      color: 'bg-purple-500'
    },
    {
      title: 'Pending Bookings',
      value: bookings.filter(b => b.status === 'pending').length,
      icon: TrendingUp,
      color: 'bg-orange-500'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-full ${stat.color} flex items-center justify-center w-12 h-12`}>
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
};

export default AdminStats;