import React, { useState } from 'react';
import { Plus, Edit, Trash2, Globe, FileText, AlarmClock as ClockIcon, CircleDot as TagIcon, Star, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { useVisa } from '@/contexts/VisaContext';
import { useToast } from '@/components/ui/use-toast';

const VisaOptionForm = ({ initialData, onSubmit, onCancel, formType }) => {
  const { toast } = useToast();
  const [visaData, setVisaData] = useState(initialData || {
    countryCode: '', 
    countryName: '', 
    visaType: '', 
    processingTime: '', 
    price: '', 
    description: '',
    documentsRequired: [''],
    featured: false,
  });

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setVisaData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleArrayChange = (arrayName, index, value) => {
    const updatedArray = [...visaData[arrayName]];
    updatedArray[index] = value;
    setVisaData(prev => ({ ...prev, [arrayName]: updatedArray }));
  };

  const addArrayItem = (arrayName) => {
    setVisaData(prev => ({ ...prev, [arrayName]: [...prev[arrayName], ''] }));
  };

  const removeArrayItem = (arrayName, index) => {
    if (visaData[arrayName].length > 1) {
      const updatedArray = visaData[arrayName].filter((_, i) => i !== index);
      setVisaData(prev => ({ ...prev, [arrayName]: updatedArray }));
    } else if (visaData[arrayName].length === 1) {
      setVisaData(prev => ({ ...prev, [arrayName]: [''] })); 
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!visaData.countryCode || visaData.countryCode.length !== 2 || !/^[A-Z]+$/.test(visaData.countryCode)) {
      toast({ title: "Invalid Country Code", description: "Country code must be 2 uppercase letters (e.g., AE for UAE).", variant: "destructive"});
      return;
    }
    if (isNaN(parseFloat(visaData.price)) || parseFloat(visaData.price) <= 0) {
        toast({ title: "Invalid Price", description: "Price must be a positive number.", variant: "destructive"});
        return;
    }
    const processedData = {
      ...visaData,
      price: parseFloat(visaData.price),
      documentsRequired: visaData.documentsRequired.filter(doc => doc.trim()),
      countryCode: visaData.countryCode.toUpperCase(),
    };
    onSubmit(processedData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor={`${formType}-countryCode`} className="flex items-center mb-1"><Globe className="h-4 w-4 mr-2 text-purple-600"/>Country Code*</Label>
          <Input id={`${formType}-countryCode`} name="countryCode" value={visaData.countryCode} onChange={handleInputChange} maxLength={2} placeholder="E.g., AE (2 uppercase letters)" required 
                 className="border-gray-300 focus:border-purple-500 focus:ring-purple-500"/>
          <p className="text-xs text-gray-500 mt-1">Standard 2-letter ISO country code (e.g., AE for UAE, TH for Thailand).</p>
        </div>
        <div>
          <Label htmlFor={`${formType}-countryName`} className="flex items-center mb-1"><Globe className="h-4 w-4 mr-2 text-purple-600"/>Country Name*</Label>
          <Input id={`${formType}-countryName`} name="countryName" value={visaData.countryName} onChange={handleInputChange} placeholder="E.g., United Arab Emirates" required 
                 className="border-gray-300 focus:border-purple-500 focus:ring-purple-500"/>
        </div>
      </div>
      
      <div>
        <Label htmlFor={`${formType}-visaType`} className="flex items-center mb-1"><FileText className="h-4 w-4 mr-2 text-purple-600"/>Visa Type / Name*</Label>
        <Input id={`${formType}-visaType`} name="visaType" value={visaData.visaType} onChange={handleInputChange} placeholder="E.g., 30 Days Single Entry Tourist Visa" required 
               className="border-gray-300 focus:border-purple-500 focus:ring-purple-500"/>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor={`${formType}-processingTime`} className="flex items-center mb-1"><ClockIcon className="h-4 w-4 mr-2 text-purple-600"/>Processing Time*</Label>
          <Input id={`${formType}-processingTime`} name="processingTime" value={visaData.processingTime} onChange={handleInputChange} placeholder="E.g., 3-5 working days" required 
                 className="border-gray-300 focus:border-purple-500 focus:ring-purple-500"/>
        </div>
        <div>
          <Label htmlFor={`${formType}-price`} className="flex items-center mb-1"><TagIcon className="h-4 w-4 mr-2 text-purple-600"/>Price (INR)*</Label>
          <Input id={`${formType}-price`} name="price" type="number" step="0.01" value={visaData.price} onChange={handleInputChange} placeholder="E.g., 8500" required 
                 className="border-gray-300 focus:border-purple-500 focus:ring-purple-500"/>
        </div>
      </div>
      
      <div>
        <Label htmlFor={`${formType}-description`} className="flex items-center mb-1">Description*</Label>
        <Textarea id={`${formType}-description`} name="description" value={visaData.description} onChange={handleInputChange} placeholder="Brief description of the visa, its validity, purpose etc." required rows={4}
                  className="border-gray-300 focus:border-purple-500 focus:ring-purple-500"/>
      </div>
      
      <div>
        <Label className="flex items-center mb-2">Documents Required*</Label>
        {visaData.documentsRequired.map((doc, index) => (
          <div key={index} className="flex items-center gap-2 mb-2">
            <Input value={doc} onChange={(e) => handleArrayChange('documentsRequired', index, e.target.value)} placeholder={`E.g., Passport copy (Page ${index + 1})`} 
                   className="border-gray-300 focus:border-purple-500 focus:ring-purple-500"/>
            <Button type="button" variant="ghost" size="icon" onClick={() => removeArrayItem('documentsRequired', index)} className="text-red-500 hover:bg-red-100">
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        ))}
        <Button type="button" variant="outline" onClick={() => addArrayItem('documentsRequired')} className="text-purple-600 border-purple-600 hover:bg-purple-50">
          <Plus className="h-4 w-4 mr-2" />Add Document Requirement
        </Button>
      </div>
      
      <div className="flex items-center space-x-3 pt-2">
        <input type="checkbox" id={`${formType}-featured`} name="featured" checked={visaData.featured} onChange={handleInputChange} className="h-5 w-5 text-purple-600 border-gray-300 rounded focus:ring-purple-500"/>
        <Label htmlFor={`${formType}-featured`} className="flex items-center text-sm font-medium text-gray-700">
          <Star className="h-4 w-4 mr-2 text-yellow-500"/>Mark as Featured Visa
        </Label>
      </div>
      
      <DialogFooter className="pt-6">
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
        <Button type="submit" className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white">
          {formType === 'add' ? 'Add Visa Option' : 'Save Changes'}
        </Button>
      </DialogFooter>
    </form>
  );
};


const ManageVisaApplications = () => {
  const { visaApplications, updateVisaApplicationStatus } = useVisa();
  const { toast } = useToast();

  const handleStatusChange = (applicationId, newStatus) => {
    updateVisaApplicationStatus(applicationId, newStatus);
    toast({ title: "Application Status Updated", description: `Application ${applicationId.slice(0,10)}... status changed to ${newStatus}.`});
  };

  if (visaApplications.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <FileText className="mx-auto h-12 w-12 text-gray-400 mb-4" />
        <p className="text-lg font-medium">No visa applications yet.</p>
        <p className="text-sm">When users apply for visas, their applications will appear here.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 mt-8">
      <h3 className="text-2xl font-semibold text-gray-800 flex items-center">
        <FileText className="h-6 w-6 mr-3 text-purple-600" />
        Visa Applications
      </h3>
      {visaApplications.map((app) => (
        <Card key={app.applicationId} className="bg-white shadow-md hover:shadow-lg transition-shadow">
          <CardHeader>
            <div className="flex flex-col sm:flex-row justify-between items-start">
              <div>
                <CardTitle className="text-lg text-purple-700">{app.fullName} ({app.nationality})</CardTitle>
                <CardDescription>Applied for: {app.visaOptionName} ({app.countryApplyingFor})</CardDescription>
              </div>
              <span className={`mt-2 sm:mt-0 inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                app.status === 'submitted' ? 'bg-yellow-100 text-yellow-800 ring-1 ring-yellow-300' :
                app.status === 'processing' ? 'bg-blue-100 text-blue-800 ring-1 ring-blue-300' :
                app.status === 'approved' ? 'bg-green-100 text-green-800 ring-1 ring-green-300' :
                app.status === 'rejected' ? 'bg-red-100 text-red-800 ring-1 ring-red-300' :
                'bg-gray-100 text-gray-800 ring-1 ring-gray-300'
              }`}>
                {app.status.charAt(0).toUpperCase() + app.status.slice(1)}
              </span>
            </div>
          </CardHeader>
          <CardContent className="text-sm space-y-1">
            <p><strong>Email:</strong> {app.email} | <strong>Phone:</strong> {app.phone}</p>
            <p><strong>Applied on:</strong> {new Date(app.submittedAt).toLocaleDateString()}</p>
            <p><strong>Application ID:</strong> <span className="font-mono text-xs">{app.applicationId}</span></p>
             {app.paymentId && <p><strong>Payment ID:</strong> <span className="font-mono text-xs">{app.paymentId}</span></p>}
          </CardContent>
          <CardFooter className="flex items-center justify-between bg-gray-50 p-4">
            <Label htmlFor={`status-${app.applicationId}`} className="text-sm">Update Status:</Label>
            <select 
              id={`status-${app.applicationId}`}
              value={app.status} 
              onChange={(e) => handleStatusChange(app.applicationId, e.target.value)}
              className="px-3 py-1.5 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 shadow-sm"
            >
              <option value="submitted">Submitted</option>
              <option value="processing">Processing</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
              <option value="document_required">Document Required</option>
            </select>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
};


const ManageVisas = () => {
  const { visaOptions, addVisaOption, updateVisaOption, deleteVisaOption } = useVisa();
  const { toast } = useToast();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingVisaOption, setEditingVisaOption] = useState(null);
  const [isDeleteConfirmationOpen, setIsDeleteConfirmationOpen] = useState(false);
  const [visaToDelete, setVisaToDelete] = useState(null);


  const handleAddVisaOption = (visaData) => {
    addVisaOption(visaData);
    setIsFormOpen(false);
    toast({ title: "Visa Option Added Successfully!", description: `${visaData.visaType} for ${visaData.countryName} is now available.`, variant: "default" });
  };

  const handleUpdateVisaOption = (visaData) => {
    updateVisaOption(editingVisaOption.id, visaData);
    setEditingVisaOption(null);
    setIsFormOpen(false);
    toast({ title: "Visa Option Updated!", description: "Changes to the visa option have been saved.", variant: "default" });
  };

  const confirmDeleteVisaOption = () => {
    if(visaToDelete) {
      deleteVisaOption(visaToDelete.id);
      toast({ title: "Visa Option Deleted", description: `${visaToDelete.visaType} for ${visaToDelete.countryName} has been removed.`, variant: "default" });
      setVisaToDelete(null);
      setIsDeleteConfirmationOpen(false);
    }
  };
  
  const openDeleteConfirmation = (visaOption) => {
    setVisaToDelete(visaOption);
    setIsDeleteConfirmationOpen(true);
  };


  const openEditForm = (visaOption) => {
    setEditingVisaOption(visaOption);
    setIsFormOpen(true);
  };

  const openAddForm = () => {
    setEditingVisaOption(null);
    setIsFormOpen(true);
  };
  
  const closeForm = () => {
    setIsFormOpen(false);
    setEditingVisaOption(null);
  };
  
  return (
    <Card className="shadow-2xl border-0 rounded-xl overflow-hidden">
      <CardHeader className="bg-gradient-to-br from-purple-600 via-indigo-600 to-blue-600 text-white p-6">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center space-x-3">
            <Globe className="h-8 w-8" />
            <CardTitle className="text-3xl font-bold">Manage Visa Options</CardTitle>
          </div>
          <Dialog open={isFormOpen} onOpenChange={(isOpen) => { if (!isOpen) closeForm(); else setIsFormOpen(true); }}>
            <DialogTrigger asChild>
              <Button className="bg-white text-purple-700 hover:bg-purple-50 shadow-md font-semibold py-3 px-6 w-full sm:w-auto" onClick={openAddForm}>
                <Plus className="h-5 w-5 mr-2" /> Add New Visa Option
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[95vh] overflow-y-auto p-0 bg-gray-50 rounded-lg shadow-xl">
              <DialogHeader className="bg-gray-100 p-6 border-b">
                <DialogTitle className="text-2xl font-semibold text-gray-800 flex items-center">
                    {editingVisaOption ? <Edit className="h-6 w-6 mr-3 text-purple-600"/> : <Plus className="h-6 w-6 mr-3 text-purple-600"/>}
                    {editingVisaOption ? 'Edit Visa Option Details' : 'Create New Visa Option'}
                </DialogTitle>
                <DialogDescription>
                    {editingVisaOption ? 'Update the details for this visa option.' : 'Fill in the form below to add a new visa option to your website.'}
                </DialogDescription>
              </DialogHeader>
              <div className="p-6">
                <VisaOptionForm 
                  initialData={editingVisaOption} 
                  onSubmit={editingVisaOption ? handleUpdateVisaOption : handleAddVisaOption}
                  onCancel={closeForm}
                  formType={editingVisaOption ? 'edit' : 'add'}
                />
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent className="p-6 bg-gray-50">
        {visaOptions.length === 0 ? (
           <div className="text-center py-12 text-gray-500">
             <Globe className="mx-auto h-16 w-16 text-gray-300 mb-6" />
             <h3 className="text-2xl font-semibold text-gray-700 mb-3">No Visa Options Yet</h3>
             <p className="text-md mb-6">Start by adding your first visa option. Click the "Add New Visa Option" button above.</p>
             <Button className="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-6" onClick={openAddForm}>
                <Plus className="h-5 w-5 mr-2" /> Add Your First Visa
              </Button>
           </div>
        ) : (
          <div className="space-y-6">
            {visaOptions.map((visa) => (
              <Card key={visa.id} className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 border-l-4 border-purple-500 bg-white rounded-lg">
                <CardHeader className="p-5">
                  <div className="flex flex-col sm:flex-row justify-between items-start gap-3">
                    <div className="flex items-center space-x-4">
                      <img src={visa.flagIconUrl} alt={`${visa.countryName} flag`} className="w-10 h-auto rounded-md shadow-md border border-gray-200"/>
                      <div>
                        <CardTitle className="text-xl font-semibold text-purple-800">{visa.visaType}</CardTitle>
                        <CardDescription className="text-sm text-gray-600">{visa.countryName} ({visa.countryCode})</CardDescription>
                      </div>
                    </div>
                    <div className="flex space-x-2 mt-3 sm:mt-0 self-start sm:self-center">
                      <Button variant="outline" size="sm" onClick={() => openEditForm(visa)} className="text-blue-600 border-blue-600 hover:bg-blue-50 px-3 py-1">
                        <Edit className="h-4 w-4 mr-1.5" />Edit
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => openDeleteConfirmation(visa)} className="text-red-600 border-red-600 hover:bg-red-50 px-3 py-1">
                        <Trash2 className="h-4 w-4 mr-1.5" />Delete
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-5 text-sm text-gray-700 space-y-2">
                    <p><span className="font-medium text-gray-800">Description:</span> {visa.description}</p>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-1 pt-2">
                        <p className="flex items-center"><ClockIcon className="h-4 w-4 mr-1.5 text-purple-500"/><strong>Processing:</strong> {visa.processingTime}</p>
                        <p className="flex items-center"><TagIcon className="h-4 w-4 mr-1.5 text-purple-500"/><strong>Price:</strong> ₹{visa.price.toLocaleString('en-IN')}</p>
                    </div>
                    <div>
                        <p className="font-medium text-gray-800 mt-2 mb-1">Documents Needed:</p>
                        <ul className="list-disc list-inside ml-4 text-xs space-y-0.5">
                            {visa.documentsRequired.map((doc, i) => <li key={i}>{doc}</li>)}
                        </ul>
                    </div>
                </CardContent>
                <CardFooter className="bg-gray-50 p-3">
                  {visa.featured ? (
                    <span className="text-xs font-semibold text-green-600 flex items-center"><Star className="h-4 w-4 mr-1.5 fill-current text-yellow-500"/>Featured on Site</span>
                  ) : (
                     <span className="text-xs text-gray-500 flex items-center"><EyeOff className="h-4 w-4 mr-1.5"/>Not Featured</span>
                  )}
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
        <ManageVisaApplications />
      </CardContent>
       <Dialog open={isDeleteConfirmationOpen} onOpenChange={setIsDeleteConfirmationOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold text-red-600">Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you absolutely sure you want to delete the visa option: <br/>
              <strong>{visaToDelete?.visaType}</strong> for <strong>{visaToDelete?.countryName}</strong>? 
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteConfirmationOpen(false)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmDeleteVisaOption}>Yes, Delete Visa Option</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default ManageVisas;