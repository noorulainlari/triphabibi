import React, { useState } from 'react';
import { Download, CreditCard, Settings2, Eye, EyeOff, Save, AlertTriangle, Palette, Info, Globe, Edit3, ShieldQuestion, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useTours } from '@/contexts/TourContext';
import { useVisa } from '@/contexts/VisaContext';
import { usePackages } from '@/contexts/PackageContext';
import { useTickets } from '@/contexts/TicketContext';
import { useAdmin } from '@/contexts/AdminContext';
import { usePaymentGateways } from '@/contexts/PaymentGatewayContext';
import { useAppContext } from '@/contexts/AppContext';
import { useToast } from '@/components/ui/use-toast';

const ManagePaymentGateways = () => {
  const { gatewaySettings, updateGatewayConfig, toggleGatewayStatus, initialGatewaySettings } = usePaymentGateways();
  const { toast } = useToast();
  const [currentSettings, setCurrentSettings] = useState(gatewaySettings);

  const handleInputChange = (gatewayId, fieldName, value) => {
    setCurrentSettings(prev => ({
      ...prev,
      [gatewayId]: {
        ...prev[gatewayId],
        [fieldName]: value
      }
    }));
  };

  const handleToggleStatus = (gatewayId) => {
    const newEnabledStatus = !currentSettings[gatewayId].enabled;
    toggleGatewayStatus(gatewayId); 
    setCurrentSettings(prev => ({
        ...prev,
        [gatewayId]: {
            ...prev[gatewayId],
            enabled: newEnabledStatus
        }
    }));
    toast({
      title: `Gateway ${newEnabledStatus ? 'Enabled' : 'Disabled'}`,
      description: `${initialGatewaySettings[gatewayId].name} has been ${newEnabledStatus ? 'enabled' : 'disabled'}.`,
    });
  };

  const handleSaveChanges = (gatewayId) => {
    updateGatewayConfig(gatewayId, currentSettings[gatewayId]);
    toast({
      title: "Settings Saved",
      description: `Configuration for ${initialGatewaySettings[gatewayId].name} has been updated.`,
    });
  };
  
  const getGatewayLogo = (gatewayId) => {
    const logoPath = initialGatewaySettings[gatewayId]?.logo;
    if (logoPath) {
        return <img-replace src={logoPath} alt={`${initialGatewaySettings[gatewayId].name} logo`} className="h-8 w-auto mr-3 object-contain"/>
    }
    return <CreditCard className="h-8 w-auto mr-3 text-gray-400" />;
  };


  return (
    <Card className="shadow-xl border-0 rounded-xl mt-8">
      <CardHeader className="bg-gradient-to-r from-teal-500 to-cyan-600 text-white p-6">
        <div className="flex items-center space-x-3">
          <CreditCard className="h-8 w-8" />
          <CardTitle className="text-3xl font-bold">Payment Gateway Management</CardTitle>
        </div>
        <CardDescription className="text-teal-100">
          Configure API keys, manage gateway status, and set up manual payment options.
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-8">
          {Object.values(initialGatewaySettings).map((gatewayMeta) => {
            const gatewayId = gatewayMeta.id;
            const config = currentSettings[gatewayId] || gatewayMeta; 
            return (
              <Card key={gatewayId} className={`overflow-hidden shadow-lg rounded-lg border ${config.enabled ? 'border-green-500' : 'border-gray-300'}`}>
                <CardHeader className={`p-5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 ${config.enabled ? 'bg-green-50' : 'bg-gray-50'}`}>
                  <div className="flex items-center">
                    {getGatewayLogo(gatewayId)}
                    <h3 className="text-xl font-semibold text-gray-800">{gatewayMeta.name}</h3>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Label htmlFor={`enable-${gatewayId}`} className="text-sm font-medium text-gray-700">
                      {config.enabled ? 'Enabled' : 'Disabled'}
                    </Label>
                    <Switch
                      id={`enable-${gatewayId}`}
                      checked={config.enabled}
                      onCheckedChange={() => handleToggleStatus(gatewayId)}
                      className="data-[state=checked]:bg-green-600 data-[state=unchecked]:bg-gray-300"
                    />
                  </div>
                </CardHeader>
                {config.enabled && (
                  <CardContent className="p-6 space-y-4">
                    {gatewayMeta.fields.map(field => (
                      <div key={field.name}>
                        <Label htmlFor={`${gatewayId}-${field.name}`} className="block text-sm font-medium text-gray-700 mb-1">
                          {field.label}
                        </Label>
                        {field.type === 'textarea' ? (
                          <Textarea
                            id={`${gatewayId}-${field.name}`}
                            value={config[field.name] || ''}
                            onChange={(e) => handleInputChange(gatewayId, field.name, e.target.value)}
                            placeholder={field.placeholder}
                            rows={gatewayId === 'manualBankTransfer' ? 5 : 3}
                            className="border-gray-300 focus:ring-cyan-500 focus:border-cyan-500"
                          />
                        ) : (
                          <Input
                            id={`${gatewayId}-${field.name}`}
                            type={field.type}
                            value={config[field.name] || ''}
                            onChange={(e) => handleInputChange(gatewayId, field.name, e.target.value)}
                            placeholder={field.placeholder}
                            className="border-gray-300 focus:ring-cyan-500 focus:border-cyan-500"
                          />
                        )}
                      </div>
                    ))}
                    <div className="flex justify-end pt-2">
                      <Button onClick={() => handleSaveChanges(gatewayId)} className="bg-gradient-to-r from-teal-500 to-cyan-600 hover:from-teal-600 hover:to-cyan-700 text-white">
                        <Save className="h-4 w-4 mr-2" /> Save {gatewayMeta.name} Settings
                      </Button>
                    </div>
                  </CardContent>
                )}
                {!config.enabled && (
                    <CardContent className="p-6 text-center text-gray-500">
                        <EyeOff className="h-10 w-10 mx-auto mb-2 text-gray-400"/>
                        <p>{gatewayMeta.name} is currently disabled. Enable it to configure settings.</p>
                    </CardContent>
                )}
              </Card>
            );
          })}
        </div>
        <div className="mt-8 p-4 bg-yellow-50 border-l-4 border-yellow-400 rounded-md">
            <div className="flex">
                <div className="flex-shrink-0">
                    <AlertTriangle className="h-5 w-5 text-yellow-400" aria-hidden="true" />
                </div>
                <div className="ml-3">
                    <p className="text-sm text-yellow-700">
                        <strong>Important:</strong> Ensure API keys and secrets are correct and correspond to your payment gateway's live/production environment for real transactions. Test thoroughly in sandbox/test mode before going live. Incorrect keys will lead to payment failures.
                    </p>
                </div>
            </div>
        </div>
      </CardContent>
    </Card>
  );
};

const ManageUiTexts = () => {
  const { uiTexts, updateUiText, initialUiTexts } = useAppContext();
  const { toast } = useToast();
  const [currentUiTexts, setCurrentUiTexts] = useState(uiTexts);

  const handleTextChange = (key, value) => {
    setCurrentUiTexts(prev => ({ ...prev, [key]: value }));
  };

  const handleSaveTexts = () => {
    Object.keys(currentUiTexts).forEach(key => {
      updateUiText(key, currentUiTexts[key]);
    });
    toast({ title: "UI Texts Updated", description: "Button labels and other UI texts have been saved." });
  };
  
  const getLabelForKey = (key) => {
    return key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
  }

  return (
    <Card className="shadow-xl border-0 rounded-xl mt-8">
      <CardHeader className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white p-6">
        <div className="flex items-center space-x-3">
          <Palette className="h-8 w-8" />
          <CardTitle className="text-3xl font-bold">Customize UI Texts</CardTitle>
        </div>
        <CardDescription className="text-indigo-100">
          Change labels for buttons and other common UI elements across the site.
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        {Object.keys(initialUiTexts).map(key => (
          <div key={key}>
            <Label htmlFor={`uiText-${key}`} className="block text-sm font-medium text-gray-700 mb-1">
              {getLabelForKey(key)} (Default: "{initialUiTexts[key]}")
            </Label>
            <Input
              id={`uiText-${key}`}
              value={currentUiTexts[key]}
              onChange={(e) => handleTextChange(key, e.target.value)}
              placeholder={initialUiTexts[key]}
              className="border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>
        ))}
        <div className="flex justify-end pt-4">
          <Button onClick={handleSaveTexts} className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white">
            <Save className="h-4 w-4 mr-2" /> Save UI Texts
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}


const ModuleManagement = () => {
  const { appSettings, updateAppSetting } = useAppContext();
  const { toast } = useToast();

  const modules = [
    { key: 'toursModuleEnabled', label: 'Single-Day Tours Module', icon: <FileText className="h-5 w-5 mr-2"/> },
    { key: 'packagesModuleEnabled', label: 'Multi-Day Packages Module', icon: <FileText className="h-5 w-5 mr-2"/> },
    { key: 'ticketsModuleEnabled', label: 'Attraction Tickets Module', icon: <FileText className="h-5 w-5 mr-2"/> },
    { key: 'visasModuleEnabled', label: 'Visa Applications Module', icon: <FileText className="h-5 w-5 mr-2"/> },
    { key: 'blogModuleEnabled', label: 'Blog Module', icon: <Edit3 className="h-5 w-5 mr-2"/> },
  ];

  const handleToggleModule = (key, value) => {
    updateAppSetting(key, value);
    toast({
      title: `Module ${value ? 'Enabled' : 'Disabled'}`,
      description: `${modules.find(m => m.key === key)?.label || key} is now ${value ? 'active' : 'inactive'}.`,
    });
  };

  return (
    <Card className="shadow-xl border-0 rounded-xl mt-8">
      <CardHeader className="bg-gradient-to-r from-orange-500 to-red-600 text-white p-6">
        <div className="flex items-center space-x-3">
          <Settings2 className="h-8 w-8" />
          <CardTitle className="text-3xl font-bold">Module Management</CardTitle>
        </div>
        <CardDescription className="text-orange-100">
          Enable or disable major sections of your website.
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6 space-y-4">
        {modules.map(module => (
          <div key={module.key} className="flex items-center justify-between p-4 border rounded-lg bg-white shadow-sm">
            <div className="flex items-center">
              {module.icon}
              <Label htmlFor={module.key} className="text-md font-medium text-gray-800">{module.label}</Label>
            </div>
            <Switch
              id={module.key}
              checked={appSettings[module.key]}
              onCheckedChange={(checked) => handleToggleModule(module.key, checked)}
              className="data-[state=checked]:bg-orange-500 data-[state=unchecked]:bg-gray-300"
            />
          </div>
        ))}
         <div className="mt-6 p-4 bg-blue-50 border-l-4 border-blue-400 rounded-md">
            <div className="flex">
                <div className="flex-shrink-0">
                    <Info className="h-5 w-5 text-blue-500" aria-hidden="true" />
                </div>
                <div className="ml-3">
                    <p className="text-sm text-blue-700">
                       Disabling a module will hide its corresponding pages and links from the public website. Content is preserved and can be re-enabled anytime.
                    </p>
                </div>
            </div>
        </div>
      </CardContent>
    </Card>
  );
};


const AdminSettings = () => {
  const { tours, bookings } = useTours();
  const { visaOptions, visaApplications } = useVisa();
  const { packages } = usePackages();
  const { tickets } = useTickets();
  const { promoCodes } = useAdmin();
  const { toast } = useToast();

  const handleExport = (data, filename) => {
    if (!data || data.length === 0) {
      toast({ title: "No Data to Export", description: `There is no data available for ${filename}.`, variant: "destructive" });
      return;
    }
    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(JSON.stringify(data, null, 2))}`;
    const link = document.createElement("a");
    link.href = jsonString;
    link.download = filename;
    link.click();
    toast({ title: "Data Exported", description: `${filename} has been downloaded.` });
  };

  return (
    <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 gap-2 bg-gray-200 p-1 rounded-lg shadow-inner">
            <TabsTrigger value="general" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white data-[state=inactive]:bg-white">General</TabsTrigger>
            <TabsTrigger value="payment" className="data-[state=active]:bg-teal-600 data-[state=active]:text-white data-[state=inactive]:bg-white">Payments</TabsTrigger>
            <TabsTrigger value="uiTexts" className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white data-[state=inactive]:bg-white">UI Texts</TabsTrigger>
            <TabsTrigger value="modules" className="data-[state=active]:bg-orange-600 data-[state=active]:text-white data-[state=inactive]:bg-white">Modules</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
            <Card className="shadow-xl border-0 rounded-xl">
              <CardHeader className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-6">
                <div className="flex items-center space-x-3">
                    <Settings2 className="h-8 w-8" />
                    <CardTitle className="text-3xl font-bold">General Site Settings</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-8">
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-gray-700">Export Data (JSON)</h3>
                    <CardDescription className="mb-3">Download your site data. Note: This exports data from browser localStorage.</CardDescription>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                      <Button variant="outline" onClick={() => handleExport(bookings, 'bookings.json')} className="border-purple-500 text-purple-600 hover:bg-purple-50">
                        <Download className="h-4 w-4 mr-2" /> Export Bookings
                      </Button>
                      <Button variant="outline" onClick={() => handleExport(tours, 'tours.json')} className="border-purple-500 text-purple-600 hover:bg-purple-50">
                        <Download className="h-4 w-4 mr-2" /> Export Tours
                      </Button>
                       <Button variant="outline" onClick={() => handleExport(promoCodes, 'promocodes.json')} className="border-purple-500 text-purple-600 hover:bg-purple-50">
                        <Download className="h-4 w-4 mr-2" /> Export Promo Codes
                      </Button>
                      <Button variant="outline" onClick={() => handleExport(visaOptions, 'visaOptions.json')} className="border-purple-500 text-purple-600 hover:bg-purple-50">
                        <Download className="h-4 w-4 mr-2" /> Export Visa Options
                      </Button>
                       <Button variant="outline" onClick={() => handleExport(visaApplications, 'visaApplications.json')} className="border-purple-500 text-purple-600 hover:bg-purple-50">
                        <Download className="h-4 w-4 mr-2" /> Export Visa Apps
                      </Button>
                       <Button variant="outline" onClick={() => handleExport(packages, 'packages.json')} className="border-purple-500 text-purple-600 hover:bg-purple-50">
                        <Download className="h-4 w-4 mr-2" /> Export Packages
                      </Button>
                       <Button variant="outline" onClick={() => handleExport(tickets, 'tickets.json')} className="border-purple-500 text-purple-600 hover:bg-purple-50">
                        <Download className="h-4 w-4 mr-2" /> Export Tickets
                      </Button>
                    </div>
                     <p className="text-xs text-gray-500 mt-3">For true data persistence and robust export options, a backend database (like Supabase) is recommended.</p>
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-gray-700">System Information</h3>
                     <CardDescription className="mb-3">Overview of your current site data.</CardDescription>
                    <div className="bg-gradient-to-br from-gray-50 to-slate-100 p-6 rounded-lg shadow-inner space-y-3 border border-gray-200">
                      <p className="flex justify-between"><strong>Total Tours:</strong> <span className="font-semibold text-purple-700">{tours.length}</span></p>
                      <p className="flex justify-between"><strong>Total Bookings:</strong> <span className="font-semibold text-purple-700">{bookings.length}</span></p>
                       <p className="flex justify-between"><strong>Total Packages:</strong> <span className="font-semibold text-purple-700">{packages.length}</span></p>
                       <p className="flex justify-between"><strong>Total Tickets:</strong> <span className="font-semibold text-purple-700">{tickets.length}</span></p>
                      <p className="flex justify-between"><strong>Visa Options:</strong> <span className="font-semibold text-purple-700">{visaOptions.length}</span></p>
                      <p className="flex justify-between"><strong>Visa Applications:</strong> <span className="font-semibold text-purple-700">{visaApplications.length}</span></p>
                      <p className="flex justify-between"><strong>Active Promo Codes:</strong> <span className="font-semibold text-purple-700">{promoCodes.filter(p => p.active).length}</span></p>
                      <p className="flex justify-between"><strong>Last Synced (localStorage):</strong> <span className="font-semibold text-purple-700">{new Date().toLocaleString()}</span></p>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-gray-700">Security (Placeholders)</h3>
                    <CardDescription className="mb-3">These features require backend implementation.</CardDescription>
                    <div className="space-y-3">
                        <Button variant="outline" disabled className="w-full justify-start"><ShieldQuestion className="h-4 w-4 mr-2"/>Setup 2-Factor Authentication (2FA)</Button>
                        <Button variant="outline" disabled className="w-full justify-start"><Eye className="h-4 w-4 mr-2"/>View Admin Activity Logs</Button>
                         <Button variant="outline" disabled className="w-full justify-start"><Globe className="h-4 w-4 mr-2"/>Configure Google reCAPTCHA</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
        </TabsContent>

        <TabsContent value="payment">
            <ManagePaymentGateways />
        </TabsContent>
         <TabsContent value="uiTexts">
            <ManageUiTexts />
        </TabsContent>
        <TabsContent value="modules">
            <ModuleManagement />
        </TabsContent>
    </Tabs>
  );
};

export default AdminSettings;