import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useTours } from '@/contexts/TourContext';
import { useToast } from '@/components/ui/use-toast';

const ManageBookings = () => {
  const { bookings, updateBookingStatus } = useTours();
  const { toast } = useToast();

  const handleUpdateStatus = (id, status) => {
    updateBookingStatus(id, status);
    toast({
      title: `Booking ${status}`,
      description: `Booking ID ${id.slice(0,6)}... has been marked as ${status}.`
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Manage Bookings</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {bookings.length === 0 ? (
            <p className="text-center text-gray-500 py-8">No bookings yet</p>
          ) : (
            bookings.map((booking) => (
              <div key={booking.id} className="p-4 border rounded-lg">
                <div className="flex flex-col sm:flex-row justify-between items-start mb-2">
                  <div>
                    <h3 className="font-semibold text-gray-900">{booking.firstName} {booking.lastName}</h3>
                    <p className="text-sm text-gray-600">{booking.tourTitle}</p>
                    <p className="text-sm text-gray-600">
                      {booking.date} • {booking.adults} adults, {booking.children} children, {booking.infants || 0} infants
                    </p>
                    {booking.paymentId && <p className="text-xs text-gray-500">Payment ID: {booking.paymentId}</p>}
                  </div>
                  <div className="text-left sm:text-right mt-2 sm:mt-0">
                    <p className="font-semibold">₹{booking.totalAmount?.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || '0.00'}</p>
                    <span className={`inline-block px-2 py-1 rounded-full text-xs ${
                      booking.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                      booking.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {booking.status || 'pending'}
                    </span>
                  </div>
                </div>
                {booking.status !== 'confirmed' && booking.status !== 'cancelled' && (
                  <div className="flex space-x-2 mt-3">
                    <Button size="sm" variant="outline" onClick={() => handleUpdateStatus(booking.id, 'confirmed')}>Confirm</Button>
                    <Button size="sm" variant="outline" onClick={() => handleUpdateStatus(booking.id, 'cancelled')}>Cancel</Button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ManageBookings;