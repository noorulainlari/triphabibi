import React, { useState } from 'react';
import { Plus, Edit, Trash2, Briefcase, Image as ImageIcon, FileText, DollarSign, Users, Bed, Car, CalendarDays, CheckCircle, XCircle, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import PackageForm from '@/components/admin/packages/PackageForm'; 
import { usePackages } from '@/contexts/PackageContext';
import { useToast } from '@/components/ui/use-toast';

const ManagePackages = () => {
  const { packages, addPackage, updatePackage, deletePackage } = usePackages();
  const { toast } = useToast();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingPackage, setEditingPackage] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const handleAddPackage = (pkgData) => {
    addPackage(pkgData);
    setIsFormOpen(false);
    toast({ title: "Package Added", description: `${pkgData.name} has been added.`, variant: "default" });
  };

  const handleUpdatePackage = (pkgData) => {
    updatePackage(editingPackage.id, pkgData);
    setEditingPackage(null);
    setIsFormOpen(false);
    toast({ title: "Package Updated", description: `Changes to ${pkgData.name} have been saved.`, variant: "default" });
  };

  const handleDeletePackage = (id, name) => {
    if (window.confirm(`Are you sure you want to delete the package: "${name}"? This action cannot be undone.`)) {
      deletePackage(id);
      toast({ title: "Package Deleted", description: `"${name}" has been removed.`, variant: "default" });
    }
  };

  const openEditForm = (pkg) => {
    setEditingPackage(pkg);
    setIsFormOpen(true);
  };

  const openAddForm = () => {
    setEditingPackage(null);
    setIsFormOpen(true);
  };
  
  const closeForm = () => {
    setIsFormOpen(false);
    setEditingPackage(null);
  };

  const filteredPackages = packages.filter(pkg => 
    pkg.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Card className="shadow-2xl border-0 rounded-xl overflow-hidden">
      <CardHeader className="bg-gradient-to-br from-blue-600 via-sky-600 to-cyan-500 text-white p-6">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center space-x-3">
            <Briefcase className="h-8 w-8" />
            <CardTitle className="text-3xl font-bold">Manage Tour Packages</CardTitle>
          </div>
          <Dialog open={isFormOpen} onOpenChange={(isOpen) => { if (!isOpen) closeForm(); else setIsFormOpen(true); }}>
            <DialogTrigger asChild>
              <Button className="bg-white text-blue-700 hover:bg-blue-50 shadow-md font-semibold py-3 px-6 w-full sm:w-auto" onClick={openAddForm}>
                <Plus className="h-5 w-5 mr-2" /> Add New Package
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[95vh] overflow-y-auto p-0 bg-gray-50 rounded-lg shadow-xl">
              <DialogHeader className="bg-gray-100 p-6 border-b">
                <DialogTitle className="text-2xl font-semibold text-gray-800 flex items-center">
                  {editingPackage ? <Edit className="h-6 w-6 mr-3 text-blue-600"/> : <Plus className="h-6 w-6 mr-3 text-blue-600"/>}
                  {editingPackage ? 'Edit Package Details' : 'Create New Package'}
                </DialogTitle>
                <DialogDescription>
                  {editingPackage ? 'Update the details for this package.' : 'Fill in the form to add a new tour package.'}
                </DialogDescription>
              </DialogHeader>
              <div className="p-6">
                <PackageForm 
                  initialData={editingPackage} 
                  onSubmit={editingPackage ? handleUpdatePackage : handleAddPackage}
                  onCancel={closeForm}
                  formType={editingPackage ? 'edit' : 'add'}
                />
              </div>
            </DialogContent>
          </Dialog>
        </div>
        <div className="mt-4">
            <Input 
              placeholder="Search packages by name..." 
              value={searchTerm} 
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-white/20 placeholder-blue-200 text-white border-blue-400 focus:bg-white focus:text-gray-900"
            />
        </div>
      </CardHeader>
      <CardContent className="p-6 bg-gray-50">
        {filteredPackages.length === 0 ? (
           <div className="text-center py-12 text-gray-500">
             <Briefcase className="mx-auto h-16 w-16 text-gray-300 mb-6" />
             <h3 className="text-2xl font-semibold text-gray-700 mb-3">No Packages Found</h3>
             <p className="text-md mb-6">
                {searchTerm ? "Try adjusting your search term." : "Start by adding your first tour package."}
             </p>
             <Button className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6" onClick={openAddForm}>
                <Plus className="h-5 w-5 mr-2" /> Add Your First Package
              </Button>
           </div>
        ) : (
          <div className="space-y-6">
            {filteredPackages.map((pkg) => (
              <Card key={pkg.id} className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 border-l-4 border-blue-500 bg-white rounded-lg">
                <CardHeader className="p-5">
                  <div className="flex flex-col sm:flex-row justify-between items-start gap-3">
                     <div className="flex items-center space-x-4">
                       {pkg.images && pkg.images.length > 0 ? 
                        <img-replace src={pkg.images[0].url} alt={pkg.images[0].alt || pkg.name} className="w-20 h-20 object-cover rounded-md shadow-md border border-gray-200"/>
                        : <div className="w-20 h-20 bg-gray-200 rounded-md flex items-center justify-center"><ImageIcon className="w-10 h-10 text-gray-400"/></div>
                       }
                        <div>
                            <CardTitle className="text-xl font-semibold text-blue-800">{pkg.name}</CardTitle>
                            <CardDescription className="text-sm text-gray-600">
                            {pkg.duration} • Adult: ₹{pkg.price?.adult?.toLocaleString('en-IN')}
                            </CardDescription>
                        </div>
                    </div>
                    <div className="flex space-x-2 mt-3 sm:mt-0 self-start sm:self-center">
                      <Button variant="outline" size="sm" onClick={() => openEditForm(pkg)} className="text-indigo-600 border-indigo-600 hover:bg-indigo-50 px-3 py-1">
                        <Edit className="h-4 w-4 mr-1.5" />Edit
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleDeletePackage(pkg.id, pkg.name)} className="text-red-600 border-red-600 hover:bg-red-50 px-3 py-1">
                        <Trash2 className="h-4 w-4 mr-1.5" />Delete
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                 <CardContent className="p-5 text-sm text-gray-700 space-y-2">
                    <p><span className="font-medium text-gray-800">Short Desc:</span> {pkg.shortDescription || pkg.description.substring(0,100) + "..."}</p>
                </CardContent>
                <CardFooter className="bg-gray-100 p-3 flex justify-between items-center">
                   <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                        pkg.status === 'Active' ? 'bg-green-100 text-green-700 ring-1 ring-green-300' :
                        pkg.status === 'Hidden' ? 'bg-gray-100 text-gray-600 ring-1 ring-gray-300' :
                        pkg.status === 'Featured' || pkg.featured ? 'bg-yellow-100 text-yellow-700 ring-1 ring-yellow-300 flex items-center' : ''
                    }`}>
                        { (pkg.status === 'Featured' || pkg.featured) && <Star className="h-3 w-3 mr-1 fill-current text-yellow-500"/>}
                        {pkg.status === 'Featured' || pkg.featured ? 'Featured' : pkg.status}
                    </span>
                    <span className="text-xs text-gray-500">Booking: {pkg.bookingType === 'direct' ? 'Direct' : 'Enquiry'}</span>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ManagePackages;