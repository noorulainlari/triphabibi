import React, { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useAdmin } from '@/contexts/AdminContext';
import { useToast } from '@/components/ui/use-toast';

const ManagePromoCodes = () => {
  const { promoCodes, addPromoCode, deletePromoCode } = useAdmin();
  const { toast } = useToast();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [newPromoCode, setNewPromoCode] = useState({ code: '', discount: '', type: 'percentage' });

  const handleAddPromoCode = (e) => {
    e.preventDefault();
    addPromoCode({
      ...newPromoCode,
      discount: parseFloat(newPromoCode.discount)
    });
    setNewPromoCode({ code: '', discount: '', type: 'percentage' });
    setIsFormOpen(false);
    toast({ title: "Promo code added", description: "New promo code is now active." });
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Promo Codes</CardTitle>
          <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
            <DialogTrigger asChild>
              <Button className="bg-purple-600 hover:bg-purple-700" onClick={() => setIsFormOpen(true)}>
                <Plus className="h-4 w-4 mr-2" /> Add Promo Code
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Promo Code</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddPromoCode} className="space-y-4">
                <div>
                  <Label htmlFor="code">Promo Code</Label>
                  <Input id="code" value={newPromoCode.code} onChange={(e) => setNewPromoCode(prev => ({ ...prev, code: e.target.value.toUpperCase() }))} placeholder="SUMMER20" required />
                </div>
                <div>
                  <Label htmlFor="discount">Discount</Label>
                  <Input id="discount" type="number" value={newPromoCode.discount} onChange={(e) => setNewPromoCode(prev => ({ ...prev, discount: e.target.value }))} placeholder="20" required />
                </div>
                <div>
                  <Label htmlFor="type">Type</Label>
                  <select id="type" value={newPromoCode.type} onChange={(e) => setNewPromoCode(prev => ({ ...prev, type: e.target.value }))} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-600">
                    <option value="percentage">Percentage</option>
                    <option value="fixed">Fixed Amount</option>
                  </select>
                </div>
                <div className="flex justify-end space-x-2">
                   <Button type="button" variant="outline" onClick={() => setIsFormOpen(false)}>Cancel</Button>
                  <Button type="submit" className="bg-purple-600 hover:bg-purple-700">Add Promo Code</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {promoCodes.map((promo) => (
            <div key={promo.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-semibold text-gray-900">{promo.code}</h3>
                <p className="text-sm text-gray-600">{promo.discount}{promo.type === 'percentage' ? '%' : '$'} off</p>
              </div>
              <div className="flex items-center space-x-2">
                <span className={`px-2 py-1 rounded-full text-xs ${promo.active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                  {promo.active ? 'Active' : 'Inactive'}
                </span>
                <Button variant="outline" size="sm" onClick={() => deletePromoCode(promo.id)}><Trash2 className="h-4 w-4" /></Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default ManagePromoCodes;