import React, { useState } from 'react';
import { Plus, Edit, Trash2, Upload, FileText, CheckSquare, Users, DollarSign, Percent, Image as ImageIcon, Star, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { useTours } from '@/contexts/TourContext';
import { useToast } from '@/components/ui/use-toast';
import { useAppContext } from '@/contexts/AppContext';

const TourForm = ({ initialData, onSubmit, onCancel, formType }) => {
  const { categories } = useTours();
  const { appSettings } = useAppContext();
  const { toast } = useToast();

  const [tourData, setTourData] = useState(initialData || {
    title: '',
    category: categories[0]?.id || '',
    shortDescription: '',
    description: '',
    itinerary: '',
    duration: '',
    pricing: { adult: '', child: '', infant: '' },
    priceType: 'per person', // Retained for backward compatibility / simple pricing
    highlights: [''],
    inclusions: [''],
    exclusions: [''],
    images: [], // Array of { url: string, alt: string }
    status: 'Active', // Active, Hidden, Featured
    pickupOptional: appSettings.pickupLocationOptional, 
    availabilityCalendarEnabled: false, 
  });

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (name.startsWith("pricing.")) {
      const field = name.split(".")[1];
      setTourData(prev => ({ ...prev, pricing: { ...prev.pricing, [field]: value } }));
    } else if (name === "pickupOptional" || name === "availabilityCalendarEnabled") {
      setTourData(prev => ({ ...prev, [name]: checked }));
    } else {
      setTourData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
    }
  };

  const handleArrayChange = (arrayName, index, value) => {
    const updatedArray = [...tourData[arrayName]];
    updatedArray[index] = value;
    setTourData(prev => ({ ...prev, [arrayName]: updatedArray }));
  };

  const addArrayItem = (arrayName) => {
    setTourData(prev => ({ ...prev, [arrayName]: [...prev[arrayName], ''] }));
  };

  const removeArrayItem = (arrayName, index) => {
    if (tourData[arrayName].length > 1) {
      const updatedArray = tourData[arrayName].filter((_, i) => i !== index);
      setTourData(prev => ({ ...prev, [arrayName]: updatedArray }));
    } else if (tourData[arrayName].length === 1 && arrayName !== 'images') {
       setTourData(prev => ({ ...prev, [arrayName]: [''] }));
    }
  };
  
  const handleImageUpload = (event) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      // This is a placeholder for actual upload. In a real app, upload to server/S3 and get URL.
      const reader = new FileReader();
      reader.onloadend = () => {
        setTourData(prev => ({ ...prev, images: [...prev.images, { url: reader.result, alt: file.name }] }));
        toast({ title: "Image Added (Simulated)", description: `${file.name} added. Save tour to persist.`, variant: "default" });
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = (index) => {
    setTourData(prev => ({ ...prev, images: prev.images.filter((_, i) => i !== index) }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const processedData = {
      ...tourData,
      pricing: {
        adult: parseFloat(tourData.pricing.adult) || 0,
        child: parseFloat(tourData.pricing.child) || 0,
        infant: parseFloat(tourData.pricing.infant) || 0,
      },
      highlights: tourData.highlights.filter(h => h.trim()),
      inclusions: tourData.inclusions.filter(i => i.trim()),
      exclusions: tourData.exclusions.filter(ex => ex.trim()),
    };
    onSubmit(processedData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor={`${formType}-title`} className="flex items-center"><FileText className="h-4 w-4 mr-2 text-purple-600"/>Tour Title*</Label>
          <Input id={`${formType}-title`} name="title" value={tourData.title} onChange={handleInputChange} required />
        </div>
        <div>
          <Label htmlFor={`${formType}-category`} className="flex items-center"><CheckSquare className="h-4 w-4 mr-2 text-purple-600"/>Category*</Label>
          <select id={`${formType}-category`} name="category" value={tourData.category} onChange={handleInputChange} className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-purple-600" required>
            {categories.map(cat => <option key={cat.id} value={cat.id}>{cat.name}</option>)}
          </select>
        </div>
      </div>
      
      <div>
        <Label htmlFor={`${formType}-shortDescription`} className="flex items-center">Short Description (for cards)</Label>
        <Textarea id={`${formType}-shortDescription`} name="shortDescription" value={tourData.shortDescription} onChange={handleInputChange} rows={2} />
      </div>
      <div>
        <Label htmlFor={`${formType}-description`} className="flex items-center">Full Description*</Label>
        <Textarea id={`${formType}-description`} name="description" value={tourData.description} onChange={handleInputChange} required rows={4}/>
      </div>
       <div>
        <Label htmlFor={`${formType}-itinerary`} className="flex items-center">Itinerary (optional, supports markdown)</Label>
        <Textarea id={`${formType}-itinerary`} name="itinerary" value={tourData.itinerary} onChange={handleInputChange} rows={5} placeholder="Day 1: Arrival and City Tour..." />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <Label htmlFor={`${formType}-duration`} className="flex items-center">Duration*</Label>
          <Input id={`${formType}-duration`} name="duration" value={tourData.duration} onChange={handleInputChange} placeholder="e.g., 4 hours, 2 Days / 1 Night" required />
        </div>
        <div>
          <Label htmlFor={`${formType}-status`} className="flex items-center">Status*</Label>
          <select id={`${formType}-status`} name="status" value={tourData.status} onChange={handleInputChange} className="w-full px-3 py-2 border border-input rounded-md">
            <option value="Active">Active (Visible)</option>
            <option value="Hidden">Hidden (Not Visible)</option>
            <option value="Featured">Featured (Highlighted)</option>
          </select>
        </div>
         <div>
          <Label htmlFor={`${formType}-priceType`} className="flex items-center">Price Type</Label>
          <select id={`${formType}-priceType`} name="priceType" value={tourData.priceType} onChange={handleInputChange} className="w-full px-3 py-2 border border-input rounded-md">
            <option value="per person">Per Person</option>
            <option value="per group">Per Group</option>
          </select>
        </div>
      </div>

      <Card className="bg-gray-50 p-4">
        <CardHeader className="p-2"><CardTitle className="text-lg flex items-center"><DollarSign className="h-5 w-5 mr-2 text-green-600"/>Pricing (INR)*</CardTitle></CardHeader>
        <CardContent className="p-2 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="pricing.adult" className="flex items-center"><Users className="h-4 w-4 mr-1 text-gray-600"/>Adult (12-99 yrs)</Label>
            <Input id="pricing.adult" name="pricing.adult" type="number" step="0.01" value={tourData.pricing.adult} onChange={handleInputChange} placeholder="e.g., 15000" required />
          </div>
          <div>
            <Label htmlFor="pricing.child" className="flex items-center"><Users className="h-4 w-4 mr-1 text-gray-600" style={{transform: 'scale(0.8)'}}/>Child (2-11 yrs)</Label>
            <Input id="pricing.child" name="pricing.child" type="number" step="0.01" value={tourData.pricing.child} onChange={handleInputChange} placeholder="e.g., 7500" />
          </div>
          <div>
            <Label htmlFor="pricing.infant" className="flex items-center"><Percent className="h-4 w-4 mr-1 text-gray-600"/>Infant (0-2 yrs)</Label>
            <Input id="pricing.infant" name="pricing.infant" type="number" step="0.01" value={tourData.pricing.infant} onChange={handleInputChange} placeholder="e.g., 0 (Free)" />
          </div>
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <Label className="flex items-center">Highlights</Label>
          {tourData.highlights.map((highlight, index) => (
            <div key={index} className="flex gap-2 mb-2">
              <Input value={highlight} onChange={(e) => handleArrayChange('highlights', index, e.target.value)} placeholder="Tour highlight" />
              <Button type="button" variant="ghost" size="icon" onClick={() => removeArrayItem('highlights', index)} className="text-red-500"><Trash2 className="h-4 w-4" /></Button>
            </div>
          ))}
          <Button type="button" variant="outline" onClick={() => addArrayItem('highlights')}><Plus className="h-4 w-4 mr-2" />Add Highlight</Button>
        </div>
        <div>
          <Label className="flex items-center">Inclusions</Label>
          {tourData.inclusions.map((item, index) => (
            <div key={index} className="flex gap-2 mb-2">
              <Input value={item} onChange={(e) => handleArrayChange('inclusions', index, e.target.value)} placeholder="What's included" />
              <Button type="button" variant="ghost" size="icon" onClick={() => removeArrayItem('inclusions', index)} className="text-red-500"><Trash2 className="h-4 w-4" /></Button>
            </div>
          ))}
          <Button type="button" variant="outline" onClick={() => addArrayItem('inclusions')}><Plus className="h-4 w-4 mr-2" />Add Inclusion</Button>
        </div>
        <div>
          <Label className="flex items-center">Exclusions</Label>
          {tourData.exclusions.map((item, index) => (
            <div key={index} className="flex gap-2 mb-2">
              <Input value={item} onChange={(e) => handleArrayChange('exclusions', index, e.target.value)} placeholder="What's not included" />
              <Button type="button" variant="ghost" size="icon" onClick={() => removeArrayItem('exclusions', index)} className="text-red-500"><Trash2 className="h-4 w-4" /></Button>
            </div>
          ))}
          <Button type="button" variant="outline" onClick={() => addArrayItem('exclusions')}><Plus className="h-4 w-4 mr-2" />Add Exclusion</Button>
        </div>
      </div>
      
      <div>
        <Label className="flex items-center"><ImageIcon className="h-4 w-4 mr-2 text-purple-600"/>Images</Label>
        <Input type="file" id={`${formType}-image-upload`} onChange={handleImageUpload} accept="image/*" className="mb-2" />
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mt-2">
          {tourData.images.map((image, index) => (
            <div key={index} className="relative group aspect-video">
              <img-replace src={image.url} alt={image.alt || `Tour Image ${index + 1}`} className="rounded-md object-cover w-full h-full" />
              <Button type="button" variant="destructive" size="icon" onClick={() => removeImage(index)} className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 className="h-3 w-3" /></Button>
            </div>
          ))}
        </div>
        <p className="text-xs text-gray-500 mt-1">Images are simulated. Actual upload requires backend.</p>
      </div>

      <div className="space-y-3 pt-4 border-t">
        <div className="flex items-center space-x-2">
          <Switch id="pickupOptional" name="pickupOptional" checked={tourData.pickupOptional} onCheckedChange={(checked) => handleInputChange({target: {name: "pickupOptional", checked, type:"checkbox"}})} />
          <Label htmlFor="pickupOptional">Pickup Location Field is Optional</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Switch id="availabilityCalendarEnabled" name="availabilityCalendarEnabled" checked={tourData.availabilityCalendarEnabled} onCheckedChange={(checked) => handleInputChange({target: {name: "availabilityCalendarEnabled", checked, type:"checkbox"}})} />
          <Label htmlFor="availabilityCalendarEnabled">Enable Date-Specific Availability (Advanced - Placeholder)</Label>
        </div>
        {tourData.availabilityCalendarEnabled && <p className="text-xs text-orange-600">Date-specific availability management requires backend logic and is currently a placeholder.</p>}
      </div>
      
      <DialogFooter className="pt-6">
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
        <Button type="submit" className="bg-purple-600 hover:bg-purple-700 text-white">
          {formType === 'add' ? <><Plus className="h-4 w-4 mr-2"/>Add Tour</> : <><Edit className="h-4 w-4 mr-2"/>Update Tour</>}
        </Button>
      </DialogFooter>
    </form>
  );
};

const ManageTours = () => {
  const { tours, addTour, updateTour, deleteTour, categories } = useTours();
  const { toast } = useToast();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingTour, setEditingTour] = useState(null);
  const [filterCategory, setFilterCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const handleAddTour = (tourData) => {
    addTour(tourData);
    setIsFormOpen(false);
    toast({ title: "Tour added successfully", description: `${tourData.title} is now available.`, variant: "default" });
  };

  const handleUpdateTour = (tourData) => {
    updateTour(editingTour.id, tourData);
    setEditingTour(null);
    setIsFormOpen(false);
    toast({ title: "Tour updated successfully", description: `Changes to ${tourData.title} have been saved.`, variant: "default" });
  };

  const handleDeleteTour = (id, title) => {
    if (window.confirm(`Are you sure you want to delete the tour: "${title}"? This action cannot be undone.`)) {
      deleteTour(id);
      toast({ title: "Tour Deleted", description: `"${title}" has been removed.`, variant: "default" });
    }
  };

  const openEditForm = (tour) => {
    setEditingTour(tour);
    setIsFormOpen(true);
  };

  const openAddForm = () => {
    setEditingTour(null); 
    setIsFormOpen(true);
  };
  
  const closeForm = () => {
    setIsFormOpen(false);
    setEditingTour(null);
  };

  const filteredTours = tours.filter(tour => {
    const categoryMatch = filterCategory === 'all' || tour.category === filterCategory;
    const searchTermMatch = !searchTerm || tour.title.toLowerCase().includes(searchTerm.toLowerCase());
    return categoryMatch && searchTermMatch;
  });
  
  return (
    <Card className="shadow-2xl border-0 rounded-xl overflow-hidden">
      <CardHeader className="bg-gradient-to-br from-purple-600 via-indigo-600 to-blue-600 text-white p-6">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="flex items-center space-x-3">
                <ImageIcon className="h-8 w-8" />
                <CardTitle className="text-3xl font-bold">Manage Tours</CardTitle>
            </div>
            <Dialog open={isFormOpen} onOpenChange={(isOpen) => { if (!isOpen) closeForm(); else setIsFormOpen(true); }}>
            <DialogTrigger asChild>
                <Button className="bg-white text-purple-700 hover:bg-purple-50 shadow-md font-semibold py-3 px-6 w-full sm:w-auto" onClick={openAddForm}>
                <Plus className="h-5 w-5 mr-2" /> Add New Tour
                </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[95vh] overflow-y-auto p-0 bg-gray-50 rounded-lg shadow-xl">
                <DialogHeader className="bg-gray-100 p-6 border-b">
                    <DialogTitle className="text-2xl font-semibold text-gray-800 flex items-center">
                        {editingTour ? <Edit className="h-6 w-6 mr-3 text-purple-600"/> : <Plus className="h-6 w-6 mr-3 text-purple-600"/>}
                        {editingTour ? 'Edit Tour Details' : 'Create New Tour'}
                    </DialogTitle>
                    <DialogDescription>
                        {editingTour ? 'Update the details for this tour.' : 'Fill in the form below to add a new tour to your website.'}
                    </DialogDescription>
                </DialogHeader>
                <div className="p-6">
                <TourForm 
                    initialData={editingTour} 
                    onSubmit={editingTour ? handleUpdateTour : handleAddTour}
                    onCancel={closeForm}
                    formType={editingTour ? 'edit' : 'add'}
                />
                </div>
            </DialogContent>
            </Dialog>
        </div>
         <div className="mt-4 flex flex-col sm:flex-row gap-4">
            <Input 
              placeholder="Search tours by title..." 
              value={searchTerm} 
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-white/20 placeholder-purple-200 text-white border-purple-400 focus:bg-white focus:text-gray-900"
            />
            <select 
              value={filterCategory} 
              onChange={(e) => setFilterCategory(e.target.value)}
              className="bg-white/20 text-white border-purple-400 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-white sm:w-auto w-full"
            >
              <option value="all" className="text-gray-900">All Categories</option>
              {categories.map(cat => <option key={cat.id} value={cat.id} className="text-gray-900">{cat.name}</option>)}
            </select>
        </div>
      </CardHeader>
      <CardContent className="p-6 bg-gray-50">
        {filteredTours.length === 0 ? (
           <div className="text-center py-12 text-gray-500">
             <ImageIcon className="mx-auto h-16 w-16 text-gray-300 mb-6" />
             <h3 className="text-2xl font-semibold text-gray-700 mb-3">No Tours Found</h3>
             <p className="text-md mb-6">
                {searchTerm || filterCategory !== 'all' ? "Try adjusting your search or filters." : "Start by adding your first tour."}
             </p>
             <Button className="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-6" onClick={openAddForm}>
                <Plus className="h-5 w-5 mr-2" /> Add Your First Tour
              </Button>
           </div>
        ) : (
          <div className="space-y-6">
            {filteredTours.map((tour) => (
              <Card key={tour.id} className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 border-l-4 border-purple-500 bg-white rounded-lg">
                <CardHeader className="p-5">
                  <div className="flex flex-col sm:flex-row justify-between items-start gap-3">
                    <div className="flex items-center space-x-4">
                       {tour.images && tour.images.length > 0 ? 
                        <img-replace src={tour.images[0].url} alt={tour.images[0].alt || tour.title} className="w-20 h-20 object-cover rounded-md shadow-md border border-gray-200"/>
                        : <div className="w-20 h-20 bg-gray-200 rounded-md flex items-center justify-center"><ImageIcon className="w-10 h-10 text-gray-400"/></div>
                       }
                      <div>
                        <CardTitle className="text-xl font-semibold text-purple-800">{tour.title}</CardTitle>
                        <CardDescription className="text-sm text-gray-600">
                          {categories.find(c => c.id === tour.category)?.name || tour.category} • {tour.duration} • ₹{tour.pricing?.adult?.toLocaleString('en-IN') || tour.price?.toLocaleString('en-IN')}
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex space-x-2 mt-3 sm:mt-0 self-start sm:self-center">
                      <Button variant="outline" size="sm" onClick={() => openEditForm(tour)} className="text-blue-600 border-blue-600 hover:bg-blue-50 px-3 py-1">
                        <Edit className="h-4 w-4 mr-1.5" />Edit
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleDeleteTour(tour.id, tour.title)} className="text-red-600 border-red-600 hover:bg-red-50 px-3 py-1">
                        <Trash2 className="h-4 w-4 mr-1.5" />Delete
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-5 text-sm text-gray-700 space-y-2">
                    <p><span className="font-medium text-gray-800">Short Desc:</span> {tour.shortDescription || tour.description.substring(0,100) + "..."}</p>
                </CardContent>
                <CardFooter className="bg-gray-100 p-3 flex justify-between items-center">
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                        tour.status === 'Active' ? 'bg-green-100 text-green-700 ring-1 ring-green-300' :
                        tour.status === 'Hidden' ? 'bg-gray-100 text-gray-600 ring-1 ring-gray-300' :
                        tour.status === 'Featured' ? 'bg-yellow-100 text-yellow-700 ring-1 ring-yellow-300 flex items-center' : ''
                    }`}>
                        {tour.status === 'Featured' && <Star className="h-3 w-3 mr-1 fill-current text-yellow-500"/>}
                        {tour.status}
                    </span>
                    <span className="text-xs text-gray-500">Adult: ₹{tour.pricing?.adult?.toLocaleString('en-IN')}, Child: ₹{tour.pricing?.child?.toLocaleString('en-IN')}</span>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ManageTours;