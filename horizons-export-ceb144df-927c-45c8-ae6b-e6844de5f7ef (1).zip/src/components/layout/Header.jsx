import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Menu, X, MapPin, Phone, Mail, Globe, Briefcase, Ticket } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/contexts/AppContext';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  const { uiTexts, appSettings } = useAppContext();

  const navigation = [
    { name: 'Home', href: '/' },
    ...(appSettings.toursModuleEnabled ? [{ name: 'Tours', href: '/tours' }] : []),
    ...(appSettings.packagesModuleEnabled ? [{ name: 'Packages', href: '/packages', icon: <Briefcase className="h-4 w-4 mr-1 md:hidden lg:inline-block" /> }] : []),
    ...(appSettings.ticketsModuleEnabled ? [{ name: 'Tickets', href: '/tickets', icon: <Ticket className="h-4 w-4 mr-1 md:hidden lg:inline-block" /> }] : []),
    ...(appSettings.visasModuleEnabled ? [{ name: 'Apply for Visa', href: '/visas', icon: <Globe className="h-4 w-4 mr-1 md:hidden lg:inline-block" /> }] : []),
    { name: 'Contact', href: '/contact' },
    ...(appSettings.blogModuleEnabled ? [{ name: 'Blog', href: '/blog' }] : []),
  ];

  const isActive = (path) => {
    if (path === '/') return location.pathname === path;
    return location.pathname.startsWith(path);
  }


  return (
    <header className="relative z-50">
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white py-2 px-4">
        <div className="container mx-auto flex flex-wrap justify-between items-center text-sm">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Phone className="h-3 w-3" />
              <span>+971 50 123 4567</span>
            </div>
            <div className="flex items-center space-x-1">
              <Mail className="h-3 w-3" />
              <span>info@abudhabilayover.com</span>
            </div>
          </div>
          <div className="flex items-center space-x-1">
            <MapPin className="h-3 w-3" />
            <span>Abu Dhabi, UAE</span>
          </div>
        </div>
      </div>

      <nav className="bg-white/95 backdrop-blur-md shadow-lg sticky top-0 z-40">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">ADL</span>
              </div>
              <div>
                <h1 className="text-xl font-bold gradient-text">Abu Dhabi Layover</h1>
                <p className="text-xs text-gray-600">Tours & Visa Services</p>
              </div>
            </Link>

            <div className="hidden md:flex items-center space-x-1 lg:space-x-3">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`relative px-1 lg:px-2 py-2 text-xs lg:text-sm font-medium transition-colors flex items-center ${
                    isActive(item.href)
                      ? 'text-purple-600'
                      : 'text-gray-700 hover:text-purple-600'
                  }`}
                >
                  {item.icon && <span className="mr-1 lg:mr-1.5">{item.icon}</span>}
                  {item.name}
                  {isActive(item.href) && (
                    <motion.div
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-600 to-blue-600"
                      layoutId="activeTab"
                      transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                    />
                  )}
                </Link>
              ))}
              { appSettings.toursModuleEnabled &&
                <Button asChild size="sm" className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-xs lg:text-sm">
                  <Link to="/tours">{uiTexts.bookNowButton || "Book Now"}</Link>
                </Button>
              }
            </div>

            <button
              className="md:hidden p-2"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden border-t border-gray-200 py-4"
            >
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`block px-4 py-3 text-base font-medium flex items-center ${
                    isActive(item.href)
                      ? 'text-purple-600 bg-purple-50'
                      : 'text-gray-700 hover:text-purple-600 hover:bg-gray-50'
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                   {item.icon && <span className="mr-2">{item.icon}</span>}
                  {item.name}
                </Link>
              ))}
              {appSettings.toursModuleEnabled && 
                <div className="px-4 py-3">
                    <Button asChild className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                    <Link to="/tours">{uiTexts.bookNowButton || "Book Now"}</Link>
                    </Button>
                </div>
              }
            </motion.div>
          )}
        </div>
      </nav>
    </header>
  );
};

export default Header;