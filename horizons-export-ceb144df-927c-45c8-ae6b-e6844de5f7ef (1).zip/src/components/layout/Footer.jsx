import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Phone, Mail, Facebook, Instagram, Twitter, Youtube, MessageCircle, ShoppingBag, Ticket, Plane, Building } from 'lucide-react';
import { useAppContext } from '@/contexts/AppContext';

const Footer = () => {
  const { appSettings } = useAppContext();

  return (
    <>
    <footer className="bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">ADL</span>
              </div>
              <div>
                <span className="text-xl font-bold">Abu Dhabi Layover</span>
                <p className="text-sm text-gray-400">Premium Tours & Services</p>
              </div>
            </div>
            <p className="text-gray-300 text-sm">
              Experience the best of Abu Dhabi with our premium layover tours, packages, tickets, and visa services. 
              Professional guides, luxury vehicles, and unforgettable memories.
            </p>
            <div className="flex space-x-4">
              <Facebook className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer transition-colors" />
              <Instagram className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer transition-colors" />
              <Twitter className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer transition-colors" />
              <Youtube className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer transition-colors" />
            </div>
          </div>

          <div className="space-y-4">
            <span className="text-lg font-semibold">Quick Links</span>
            <div className="space-y-2">
              <Link to="/" className="block text-gray-300 hover:text-white transition-colors">Home</Link>
              {appSettings.toursModuleEnabled && <Link to="/tours" className="block text-gray-300 hover:text-white transition-colors">All Tours</Link>}
              {appSettings.packagesModuleEnabled && <Link to="/packages" className="block text-gray-300 hover:text-white transition-colors">Tour Packages</Link>}
              {appSettings.ticketsModuleEnabled && <Link to="/tickets" className="block text-gray-300 hover:text-white transition-colors">Attraction Tickets</Link>}
              {appSettings.visasModuleEnabled && <Link to="/visas" className="block text-gray-300 hover:text-white transition-colors">Visa Services</Link>}
              <Link to="/contact" className="block text-gray-300 hover:text-white transition-colors">Contact Us</Link>
              {appSettings.blogModuleEnabled && <Link to="/blog" className="block text-gray-300 hover:text-white transition-colors">Blog</Link>}
            </div>
          </div>

          <div className="space-y-4">
            <span className="text-lg font-semibold">Our Services</span>
            <div className="space-y-2">
              {appSettings.toursModuleEnabled && <span className="flex items-center text-gray-300"><ShoppingBag className="h-4 w-4 mr-2 text-purple-400"/> Single-Day Tours</span>}
              {appSettings.packagesModuleEnabled && <span className="flex items-center text-gray-300"><Building className="h-4 w-4 mr-2 text-purple-400"/> Multi-Day Packages</span>}
              {appSettings.ticketsModuleEnabled && <span className="flex items-center text-gray-300"><Ticket className="h-4 w-4 mr-2 text-purple-400"/> Attraction Tickets</span>}
              {appSettings.visasModuleEnabled && <span className="flex items-center text-gray-300"><Plane className="h-4 w-4 mr-2 text-purple-400"/> Visa Assistance</span>}
              <span className="flex items-center text-gray-300"><Phone className="h-4 w-4 mr-2 text-purple-400"/> Airport Transfers</span>
            </div>
          </div>

          <div className="space-y-4">
            <span className="text-lg font-semibold">Contact Info</span>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-purple-400" />
                <span className="text-gray-300 text-sm">Abu Dhabi, United Arab Emirates</span>
              </div>
              <a href="tel:+971501234567" className="flex items-center space-x-3 group">
                <Phone className="h-5 w-5 text-purple-400 group-hover:text-white transition-colors" />
                <span className="text-gray-300 text-sm group-hover:text-white transition-colors">+971 50 123 4567</span>
              </a>
              <a href="mailto:info@abudhabilayover.com" className="flex items-center space-x-3 group">
                <Mail className="h-5 w-5 text-purple-400 group-hover:text-white transition-colors" />
                <span className="text-gray-300 text-sm group-hover:text-white transition-colors">info@abudhabilayover.com</span>
              </a>
            </div>
            <div className="bg-gradient-to-r from-purple-600/20 to-blue-600/20 p-4 rounded-lg">
              <span className="text-sm font-medium">24/7 Customer Support</span>
              <p className="text-xs text-gray-400 mt-1">Available for all your tour needs</p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © {new Date().getFullYear()} Abu Dhabi Layover. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <span className="text-gray-400 text-sm hover:text-white cursor-pointer transition-colors">Privacy Policy</span>
            <span className="text-gray-400 text-sm hover:text-white cursor-pointer transition-colors">Terms of Service</span>
            <span className="text-gray-400 text-sm hover:text-white cursor-pointer transition-colors">Cancellation Policy</span>
          </div>
        </div>
      </div>
    </footer>
    
    {/* Floating WhatsApp Button Placeholder */}
    <div className="fixed bottom-6 right-6 z-50">
      <a 
        href="https://wa.me/971501234567" 
        target="_blank" 
        rel="noopener noreferrer"
        className="bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg flex items-center justify-center transition-transform hover:scale-110"
        aria-label="Chat on WhatsApp"
      >
        <MessageCircle className="h-7 w-7" />
      </a>
    </div>
    </>
  );
};

export default Footer;
