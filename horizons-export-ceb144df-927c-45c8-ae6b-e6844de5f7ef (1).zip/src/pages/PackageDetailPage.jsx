import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CalendarDays, Users, MapPin, CheckCircle, XCircle, Download, Briefcase, Bed, Car, Star } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { usePackages } from '@/contexts/PackageContext';
import { useAppContext } from '@/contexts/AppContext';
import { useToast } from "@/components/ui/use-toast";


const PackageDetailPage = () => {
  const { id } = useParams();
  const { getPackageById } = usePackages();
  const { uiTexts, appSettings } = useAppContext();
  const { toast } = useToast();
  const pkg = getPackageById(id);

  if (!appSettings.packagesModuleEnabled) {
    return (
      <>
        <Header />
        <div className="container mx-auto px-4 py-20 text-center">
          <Briefcase className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <h1 className="text-3xl font-bold text-gray-700 mb-2">Package Not Available</h1>
          <p className="text-gray-600">This feature is currently disabled or the package does not exist.</p>
          <Button asChild className="mt-6">
            <Link to="/">Go to Homepage</Link>
          </Button>
        </div>
        <Footer />
      </>
    );
  }

  if (!pkg || pkg.status === 'Hidden') {
    return (
      <>
        <Header />
        <div className="container mx-auto px-4 py-20 text-center">
          <Briefcase className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <h1 className="text-3xl font-bold text-gray-700 mb-2">Package Not Found</h1>
          <p className="text-gray-600">The tour package you are looking for does not exist or is currently unavailable.</p>
          <Button asChild className="mt-6">
            <Link to="/packages">View All Packages</Link>
          </Button>
        </div>
        <Footer />
      </>
    );
  }
  
  const handleBookingAction = () => {
    toast({
      title: "🚧 Feature In Progress",
      description: "Package booking/enquiry isn't fully implemented yet. You can request this feature! 🚀",
      duration: 5000,
    });
  };


  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          {/* Header Section */}
          <section className="mb-12">
            <div className="relative rounded-xl overflow-hidden shadow-2xl h-[300px] md:h-[450px]">
              <img-replace 
                src={pkg.images && pkg.images.length > 0 ? pkg.images[0].url : "https://images.unsplash.com/photo-1500930287589-c09b090c9060"} 
                alt={pkg.images && pkg.images.length > 0 && pkg.images[0].alt ? pkg.images[0].alt : pkg.name} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-8">
                <motion.h1 
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.2, duration: 0.5 }}
                  className="text-3xl md:text-5xl font-extrabold text-white mb-3"
                >
                  {pkg.name}
                </motion.h1>
                <motion.p 
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.4, duration: 0.5 }}
                  className="text-lg text-blue-200 flex items-center"
                >
                  <CalendarDays className="h-5 w-5 mr-2" /> {pkg.duration}
                </motion.p>
              </div>
            </div>
          </section>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-10">
              <Card className="shadow-lg border-0 rounded-lg">
                <CardHeader>
                  <CardTitle className="text-2xl font-semibold text-gray-800">Package Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 leading-relaxed">{pkg.description}</p>
                  <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                    {pkg.hotelOptions && pkg.hotelOptions.length > 0 && (
                        <div className="flex items-start">
                            <Bed className="h-5 w-5 mr-3 mt-1 text-blue-600 flex-shrink-0"/>
                            <div>
                                <span className="font-semibold text-gray-700">Hotel Options:</span>
                                <ul className="list-disc list-inside ml-1 text-gray-600">
                                    {pkg.hotelOptions.map((opt, i) => <li key={i}>{opt}</li>)}
                                </ul>
                            </div>
                        </div>
                    )}
                    {pkg.transportOptions && pkg.transportOptions.length > 0 && (
                        <div className="flex items-start">
                            <Car className="h-5 w-5 mr-3 mt-1 text-blue-600 flex-shrink-0"/>
                             <div>
                                <span className="font-semibold text-gray-700">Transport:</span>
                                <ul className="list-disc list-inside ml-1 text-gray-600">
                                    {pkg.transportOptions.map((opt, i) => <li key={i}>{opt}</li>)}
                                </ul>
                            </div>
                        </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {pkg.itinerary && pkg.itinerary.length > 0 && (
                <Card className="shadow-lg border-0 rounded-lg">
                  <CardHeader>
                    <CardTitle className="text-2xl font-semibold text-gray-800">Day-wise Itinerary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Accordion type="single" collapsible className="w-full">
                      {pkg.itinerary.map((day, index) => (
                        <AccordionItem value={`item-${index}`} key={index}>
                          <AccordionTrigger className="text-lg font-medium hover:text-blue-600 data-[state=open]:text-blue-700">
                            Day {day.day}: {day.title}
                          </AccordionTrigger>
                          <AccordionContent className="text-gray-600 leading-relaxed pt-2 pb-4 px-1">
                            {day.description}
                          </AccordionContent>
                        </AccordionItem>
                      ))}
                    </Accordion>
                  </CardContent>
                </Card>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {pkg.inclusions && pkg.inclusions.length > 0 && (
                  <Card className="shadow-lg border-0 rounded-lg">
                    <CardHeader>
                      <CardTitle className="text-xl font-semibold text-gray-800 flex items-center"><CheckCircle className="h-6 w-6 mr-2 text-green-500"/>What's Included</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2 text-gray-700">
                        {pkg.inclusions.map((item, index) => (
                          <li key={index} className="flex items-start">
                            <CheckCircle className="h-4 w-4 mr-2 mt-1 text-green-500 flex-shrink-0"/> {item}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                )}
                {pkg.exclusions && pkg.exclusions.length > 0 && (
                  <Card className="shadow-lg border-0 rounded-lg">
                    <CardHeader>
                      <CardTitle className="text-xl font-semibold text-gray-800 flex items-center"><XCircle className="h-6 w-6 mr-2 text-red-500"/>What's Not Included</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2 text-gray-700">
                        {pkg.exclusions.map((item, index) => (
                          <li key={index} className="flex items-start">
                            <XCircle className="h-4 w-4 mr-2 mt-1 text-red-500 flex-shrink-0"/> {item}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                )}
              </div>
              
              {pkg.images && pkg.images.length > 1 && (
                <Card className="shadow-lg border-0 rounded-lg">
                    <CardHeader>
                        <CardTitle className="text-2xl font-semibold text-gray-800">Gallery</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                            {pkg.images.slice(1).map((image, index) => (
                                <motion.div 
                                    key={index} 
                                    className="aspect-video rounded-lg overflow-hidden shadow-md cursor-pointer group"
                                    whileHover={{ scale: 1.05 }}
                                    onClick={() => alert("Image preview not implemented yet.")}
                                >
                                    <img-replace 
                                        src={image.url} 
                                        alt={image.alt || `${pkg.name} - Image ${index + 2}`} 
                                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                                    />
                                </motion.div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
              )}

            </div>

            {/* Sidebar / Booking Card */}
            <aside className="lg:col-span-1 space-y-8">
              <Card className="shadow-xl border-0 rounded-lg sticky top-24">
                <CardHeader className="bg-gradient-to-br from-blue-600 to-sky-500 text-white p-6 rounded-t-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-3xl font-bold">₹{pkg.price?.adult?.toLocaleString('en-IN')}</span>
                    <span className="text-sm text-blue-100">per adult</span>
                  </div>
                  {pkg.price?.child && <p className="text-sm text-blue-100 mt-1">Child: ₹{pkg.price.child.toLocaleString('en-IN')}</p>}
                  {pkg.price?.infant !== undefined && <p className="text-sm text-blue-100">Infant: ₹{pkg.price.infant.toLocaleString('en-IN')}</p>}
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  <Button 
                    size="lg" 
                    className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-lg py-3.5"
                    onClick={handleBookingAction}
                  >
                    {pkg.bookingType === 'direct' ? (uiTexts.bookNowButton || "Book This Package") : (uiTexts.enquireNowButton || "Enquire Now")}
                  </Button>
                  
                  {pkg.downloadableItineraryUrl && (
                    <Button 
                        variant="outline" 
                        asChild 
                        className="w-full border-blue-500 text-blue-600 hover:bg-blue-50"
                    >
                        <a href={pkg.downloadableItineraryUrl} target="_blank" rel="noopener noreferrer">
                            <Download className="h-4 w-4 mr-2" /> Download PDF Itinerary
                        </a>
                    </Button>
                  )}
                  
                  <div className="text-sm text-gray-600 space-y-2">
                    <p className="flex items-center"><Star className="h-4 w-4 mr-2 text-yellow-500"/> Typically highly rated by travelers.</p>
                    <p className="flex items-center"><Users className="h-4 w-4 mr-2 text-blue-500"/> Ideal for couples, families, and groups.</p>
                  </div>
                </CardContent>
              </Card>
            </aside>
          </div>
        </motion.div>
      </main>
      <Footer />
    </div>
  );
};

export default PackageDetailPage;