import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Globe, Search, ArrowRight, Tag, Clock } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useVisa } from '@/contexts/VisaContext';

const VisaPage = () => {
  const { visaOptions, getAllCountriesWithVisas } = useVisa();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('all');

  const countries = useMemo(() => {
    const all = getAllCountriesWithVisas();
    return [{ countryCode: 'all', countryName: 'All Countries', flagIconUrl: '' }, ...all];
  }, [getAllCountriesWithVisas]);

  const filteredVisaOptions = useMemo(() => {
    let filtered = visaOptions;

    if (selectedCountry !== 'all') {
      filtered = filtered.filter(visa => visa.countryCode === selectedCountry);
    }

    if (searchTerm) {
      filtered = filtered.filter(visa =>
        visa.countryName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        visa.visaType.toLowerCase().includes(searchTerm.toLowerCase()) ||
        visa.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    return filtered.sort((a,b) => (a.featured === b.featured)? 0 : a.featured? -1 : 1);
  }, [visaOptions, selectedCountry, searchTerm]);

  const MotionCard = motion(Card);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <section className="relative py-20 md:py-32 bg-gradient-to-br from-purple-700 via-blue-600 to-sky-500 text-white overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <img  alt="Abstract global travel patterns" class="w-full h-full object-cover" src="https://images.unsplash.com/photo-1691967256684-0ddecdc115d8" />
          </div>
          <div className="relative z-10 container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <Globe className="mx-auto h-20 w-20 mb-6 text-sky-300" />
              <h1 className="text-4xl md:text-6xl font-extrabold mb-6 tracking-tight">
                Online Visa Application
              </h1>
              <p className="text-xl md:text-2xl text-purple-100 max-w-3xl mx-auto leading-relaxed">
                Apply for your visa hassle-free. Explore destinations and get your travel documents sorted with ease.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-12 bg-white border-b sticky top-16 z-30 shadow-sm">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row gap-6 items-center justify-between">
              <div className="relative flex-grow w-full md:w-auto md:max-w-lg">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="Search by country or visa type (e.g., UAE, 30 Days Tourist)"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-12 py-3 text-base rounded-lg border-gray-300 focus:ring-purple-500 focus:border-purple-500"
                />
              </div>
              <div className="flex flex-wrap gap-3">
                {countries.map((country) => (
                  <Button
                    key={country.countryCode}
                    variant={selectedCountry === country.countryCode ? 'default' : 'outline'}
                    onClick={() => setSelectedCountry(country.countryCode)}
                    className={`px-4 py-2 rounded-lg transition-all duration-200 ${
                      selectedCountry === country.countryCode 
                        ? 'bg-purple-600 hover:bg-purple-700 text-white shadow-md' 
                        : 'text-gray-700 hover:bg-gray-100 hover:border-gray-400'
                    }`}
                  >
                    {country.flagIconUrl && country.countryCode !== 'all' && <img src={country.flagIconUrl} alt={`${country.countryName} flag`} className="w-5 h-auto mr-2 rounded-sm"/>}
                    {country.countryName}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gradient-to-br from-gray-50 to-blue-50">
          <div className="container mx-auto px-4">
            {filteredVisaOptions.length === 0 ? (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center py-16"
              >
                <Globe className="h-24 w-24 text-gray-300 mx-auto mb-8" />
                <h3 className="text-3xl font-semibold text-gray-800 mb-4">No Visa Options Found</h3>
                <p className="text-gray-600 mb-8 max-w-md mx-auto">
                  We couldn't find any visa options matching your search. Try adjusting your filters or check back later.
                </p>
                <Button
                  onClick={() => {
                    setSearchTerm('');
                    setSelectedCountry('all');
                  }}
                  className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-lg text-lg"
                >
                  Clear Filters & View All
                </Button>
              </motion.div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredVisaOptions.map((visa, index) => (
                  <MotionCard
                    key={visa.id}
                    initial={{ opacity: 0, y: 50 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="flex flex-col rounded-xl shadow-lg overflow-hidden border-0 hover:shadow-2xl transition-shadow duration-300 bg-white"
                  >
                    <CardHeader className="p-0 relative">
                      <div className="h-48 bg-gray-200 flex items-center justify-center overflow-hidden">
                        <img  src={visa.flagIconUrl} alt={`${visa.countryName} visa`} class="w-full h-full object-cover country-hero-image" src="https://images.unsplash.com/photo-1696495896987-e8938aa4fafc" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                      </div>
                      {visa.featured && (
                        <span className="absolute top-4 left-4 bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-semibold shadow-md">
                          ⭐ Popular Choice
                        </span>
                      )}
                      <div className="absolute bottom-4 left-4 flex items-center space-x-2">
                        <img src={visa.flagIconUrl} alt={`${visa.countryName} flag`} className="w-8 h-auto rounded-sm border-2 border-white shadow-lg"/>
                        <CardTitle className="text-xl font-bold text-white drop-shadow-lg">{visa.countryName}</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent className="p-6 flex-grow">
                      <h3 className="text-lg font-semibold text-purple-700 mb-2">{visa.visaType}</h3>
                      <p className="text-gray-600 text-sm mb-4 line-clamp-3">{visa.description}</p>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center text-gray-700">
                          <Clock className="h-4 w-4 mr-2 text-purple-500" />
                          Processing Time: <span className="font-medium ml-1">{visa.processingTime}</span>
                        </div>
                        <div className="flex items-center text-gray-700">
                          <Tag className="h-4 w-4 mr-2 text-purple-500" />
                          Price: <span className="font-medium ml-1">₹{visa.price.toLocaleString('en-IN')}</span>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="p-6 bg-gray-50 border-t">
                      <Button asChild className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white py-3 text-base rounded-lg shadow-md hover:shadow-lg transition-shadow">
                        <Link to={`/apply-visa/${visa.countryCode}?visaType=${encodeURIComponent(visa.id)}`}>
                          Apply Now <ArrowRight className="h-5 w-5 ml-2" />
                        </Link>
                      </Button>
                    </CardFooter>
                  </MotionCard>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default VisaPage;