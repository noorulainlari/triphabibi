import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Ticket as TicketIconLucide, Search, Filter, ArrowRight, MapPin } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import TicketCard from '@/components/tickets/TicketCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { useTickets } from '@/contexts/TicketContext';
import { useAppContext } from '@/contexts/AppContext';

const TicketsPage = () => {
  const { tickets } = useTickets();
  const { uiTexts, appSettings } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterLocation, setFilterLocation] = useState('');

  const uniqueLocations = [...new Set(tickets.map(t => t.location))].sort();

  const filteredTickets = tickets.filter(ticket => {
    const nameMatch = ticket.name.toLowerCase().includes(searchTerm.toLowerCase());
    const locationMatch = filterLocation ? ticket.location === filterLocation : true;
    return nameMatch && locationMatch && ticket.status !== 'Hidden';
  });

  if (!appSettings.ticketsModuleEnabled) {
    return (
      <>
        <Header />
        <div className="container mx-auto px-4 py-20 text-center">
          <TicketIconLucide className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <h1 className="text-3xl font-bold text-gray-700 mb-2">Attraction Tickets Not Available</h1>
          <p className="text-gray-600">This feature is currently disabled. Please check back later or contact us for more information.</p>
          <Button asChild className="mt-6">
            <Link to="/">Go to Homepage</Link>
          </Button>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      <section className="relative py-20 md:py-32 bg-gradient-to-br from-green-600 via-emerald-500 to-teal-400 text-white">
        <div className="absolute inset-0 bg-black/30"></div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <TicketIconLucide className="h-16 w-16 mx-auto mb-6 text-white" />
            <h1 className="text-4xl md:text-6xl font-extrabold mb-4">Attraction Tickets</h1>
            <p className="text-lg md:text-xl text-green-100 max-w-2xl mx-auto">
              Book your entry to top theme parks, museums, and attractions. Instant confirmations available!
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          {/* Filters Section */}
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-12 p-6 bg-white rounded-xl shadow-lg"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
              <div>
                <label htmlFor="search-ticket" className="block text-sm font-medium text-gray-700 mb-1">Search by Name</label>
                <div className="relative">
                  <Input 
                    type="text" 
                    id="search-ticket"
                    placeholder="e.g., Burj Khalifa, Louvre Museum" 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>
              <div>
                <label htmlFor="filter-location" className="block text-sm font-medium text-gray-700 mb-1">Filter by Location</label>
                <select 
                  id="filter-location"
                  value={filterLocation} 
                  onChange={(e) => setFilterLocation(e.target.value)}
                  className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                >
                  <option value="">All Locations</option>
                  {uniqueLocations.map(loc => <option key={loc} value={loc}>{loc}</option>)}
                </select>
              </div>
            </div>
          </motion.div>

          {filteredTickets.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredTickets.map((ticket, index) => (
                <TicketCard key={ticket.id} ticket={ticket} index={index} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Filter className="h-16 w-16 mx-auto text-gray-400 mb-4" />
              <h2 className="text-2xl font-semibold text-gray-700 mb-2">No Tickets Found</h2>
              <p className="text-gray-600 mb-6">Try adjusting your search or filters, or explore all our available tickets.</p>
              <Button onClick={() => { setSearchTerm(''); setFilterLocation(''); }}>
                Clear Filters & View All
              </Button>
            </div>
          )}
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default TicketsPage;