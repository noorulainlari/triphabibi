import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAdmin } from '@/contexts/AdminContext';
import { useToast } from '@/components/ui/use-toast';
import AdminDashboard from '@/components/admin/AdminDashboard';

const AdminLoginPage = ({ onLogin }) => {
  const [loginData, setLoginData] = useState({ username: '', password: '' });
  const { toast } = useToast();

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    if (onLogin(loginData.username, loginData.password)) {
      toast({
        title: "Login successful",
        description: "Welcome to the admin panel"
      });
    } else {
      toast({
        title: "Login failed",
        description: "Invalid username or password",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-lg shadow-xl p-8 w-full max-w-md"
      >
        <div className="text-center mb-8">
          <ShieldCheck className="mx-auto h-16 w-16 text-purple-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Login</h1>
          <p className="text-gray-600">Access the Abu Dhabi Layover control panel.</p>
        </div>
        <form onSubmit={handleLoginSubmit} className="space-y-6">
          <div>
            <Label htmlFor="username">Username</Label>
            <Input
              id="username"
              value={loginData.username}
              onChange={(e) => setLoginData(prev => ({ ...prev, username: e.target.value }))}
              required
              className="text-lg px-4 py-3"
            />
          </div>
          <div>
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={loginData.password}
              onChange={(e) => setLoginData(prev => ({ ...prev, password: e.target.value }))}
              required
              className="text-lg px-4 py-3"
            />
          </div>
          <Button type="submit" className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-lg py-3">
            Secure Login
          </Button>
        </form>
        <div className="mt-8 p-4 bg-purple-50 border border-purple-200 rounded-lg">
          <p className="text-sm text-purple-700 mb-2 font-semibold">Demo Credentials:</p>
          <p className="text-sm text-purple-600"><strong>Username:</strong> admin</p>
          <p className="text-sm text-purple-600"><strong>Password:</strong> admin123</p>
        </div>
      </motion.div>
    </div>
  );
};


const AdminPage = () => {
  const { isAuthenticated, login, logout } = useAdmin();

  if (!isAuthenticated) {
    return <AdminLoginPage onLogin={login} />;
  }

  return <AdminDashboard onLogout={logout} />;
};

export default AdminPage;