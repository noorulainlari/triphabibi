import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useTours } from '@/contexts/TourContext';
import { useToast } from '@/components/ui/use-toast';
import BookingForm from '@/components/booking/BookingForm';
import BookingSummary from '@/components/booking/BookingSummary';
import RazorpayPayment from '@/components/booking/RazorpayPayment';

const BookingPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { getTourById, addBooking } = useTours();
  const { toast } = useToast();
  const tour = getTourById(id);

  const [bookingData, setBookingData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    date: '',
    adults: 1,
    children: 0,
    infants: 0,
    specialRequests: '',
    promoCode: ''
  });

  const [promoDiscount, setPromoDiscount] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPayment, setShowPayment] = useState(false);

  useEffect(() => {
    if (tour) {
      document.title = `Book ${tour.title} - Abu Dhabi Layover`;
    }
  }, [tour]);

  if (!tour) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Tour not found</h2>
          <Button onClick={() => navigate('/tours')}>Back to Tours</Button>
        </div>
      </div>
    );
  }

  const calculateTotal = () => {
    const basePrice = tour.price * (parseInt(bookingData.adults) + parseInt(bookingData.children) * 0.7);
    if (promoDiscount) {
      return basePrice * (1 - promoDiscount.discount / 100);
    }
    return basePrice;
  };
  
  const totalPrice = calculateTotal();

  const handleFormSubmit = async () => {
    setIsProcessing(true);
    try {
      if (!bookingData.firstName || !bookingData.lastName || !bookingData.email || !bookingData.phone || !bookingData.date) {
        toast({
          title: "Please fill in all required fields",
          variant: "destructive"
        });
        setIsProcessing(false);
        return;
      }
      setShowPayment(true);
    } catch (error) {
      toast({
        title: "Form submission failed",
        description: "Please try again or contact support",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePaymentSuccess = (response) => {
    const booking = {
      ...bookingData,
      tourId: tour.id,
      tourTitle: tour.title,
      totalAmount: totalPrice,
      promoCode: promoDiscount ? bookingData.promoCode : null,
      discount: promoDiscount ? promoDiscount.discount : 0,
      paymentId: response.razorpay_payment_id,
      status: 'confirmed'
    };

    const newBooking = addBooking(booking);
    toast({
      title: "Booking Confirmed!",
      description: "Your tour is booked. Check your email for details."
    });
    navigate('/', { 
      state: { 
        message: 'Booking confirmed! Check your email for details.',
        bookingId: newBooking.id 
      }
    });
  };

  const handlePaymentError = (error) => {
    toast({
      title: "Payment Failed",
      description: error.description || "Something went wrong. Please try again.",
      variant: "destructive"
    });
    setShowPayment(false);
  };


  return (
    <div className="min-h-screen">
      <Header />
      
      <div className="bg-gray-50 py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <button onClick={() => navigate(-1)} className="flex items-center space-x-1 hover:text-purple-600">
              <ArrowLeft className="h-4 w-4" />
              <span>Back</span>
            </button>
            <span>/</span>
            <span className="text-gray-900">Book Tour: {tour.title}</span>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {!showPayment ? (
              <BookingForm 
                bookingData={bookingData}
                setBookingData={setBookingData}
                promoDiscount={promoDiscount}
                setPromoDiscount={setPromoDiscount}
                onSubmit={handleFormSubmit}
                isProcessing={isProcessing}
              />
            ) : (
              <RazorpayPayment
                amount={totalPrice}
                bookingData={bookingData}
                onSuccess={handlePaymentSuccess}
                onError={handlePaymentError}
                tourTitle={tour.title}
              />
            )}
          </div>

          <div>
            <BookingSummary 
              tour={tour} 
              bookingData={bookingData} 
              totalPrice={totalPrice} 
              promoDiscount={promoDiscount}
            />
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default BookingPage;