import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Briefcase, Search, Filter, ArrowRight } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import PackageCard from '@/components/packages/PackageCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { usePackages } from '@/contexts/PackageContext';
import { useAppContext } from '@/contexts/AppContext';

const PackagesPage = () => {
  const { packages } = usePackages();
  const { uiTexts, appSettings } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDuration, setFilterDuration] = useState(''); // e.g., "5 Days"
  const [filterPrice, setFilterPrice] = useState(''); // e.g., "0-50000"

  const uniqueDurations = [...new Set(packages.map(p => p.duration.split(' ')[0] + ' ' + p.duration.split(' ')[1]))].sort();


  const filteredPackages = packages.filter(pkg => {
    const nameMatch = pkg.name.toLowerCase().includes(searchTerm.toLowerCase());
    const durationMatch = filterDuration ? pkg.duration.startsWith(filterDuration.split(' ')[0]) : true;
    
    let priceMatch = true;
    if (filterPrice) {
      const [min, max] = filterPrice.split('-').map(Number);
      const adultPrice = pkg.price?.adult;
      if (adultPrice) {
        priceMatch = adultPrice >= min && adultPrice <= max;
      } else {
        priceMatch = false; // No adult price, doesn't match price filter
      }
    }
    return nameMatch && durationMatch && priceMatch && pkg.status !== 'Hidden';
  });

  if (!appSettings.packagesModuleEnabled) {
    return (
      <>
        <Header />
        <div className="container mx-auto px-4 py-20 text-center">
          <Briefcase className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <h1 className="text-3xl font-bold text-gray-700 mb-2">Tour Packages Not Available</h1>
          <p className="text-gray-600">This feature is currently disabled. Please check back later or contact us for more information.</p>
          <Button asChild className="mt-6">
            <Link to="/">Go to Homepage</Link>
          </Button>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      <section className="relative py-20 md:py-32 bg-gradient-to-br from-blue-600 via-sky-500 to-cyan-400 text-white">
        <div className="absolute inset-0 bg-black/30"></div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Briefcase className="h-16 w-16 mx-auto mb-6 text-white" />
            <h1 className="text-4xl md:text-6xl font-extrabold mb-4">Tour Packages</h1>
            <p className="text-lg md:text-xl text-blue-100 max-w-2xl mx-auto">
              Explore curated multi-day adventures. Unforgettable experiences, hassle-free.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          {/* Filters Section */}
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-12 p-6 bg-white rounded-xl shadow-lg"
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
              <div>
                <label htmlFor="search-package" className="block text-sm font-medium text-gray-700 mb-1">Search by Name</label>
                <div className="relative">
                  <Input 
                    type="text" 
                    id="search-package"
                    placeholder="e.g., Dubai Extravaganza" 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>
              <div>
                <label htmlFor="filter-duration" className="block text-sm font-medium text-gray-700 mb-1">Filter by Duration</label>
                <select 
                  id="filter-duration"
                  value={filterDuration} 
                  onChange={(e) => setFilterDuration(e.target.value)}
                  className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">All Durations</option>
                  {uniqueDurations.map(dur => <option key={dur} value={dur}>{dur}</option>)}
                </select>
              </div>
              <div>
                <label htmlFor="filter-price" className="block text-sm font-medium text-gray-700 mb-1">Filter by Price (Adult)</label>
                <select 
                  id="filter-price"
                  value={filterPrice} 
                  onChange={(e) => setFilterPrice(e.target.value)}
                  className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">All Prices</option>
                  <option value="0-25000">₹0 - ₹25,000</option>
                  <option value="25001-50000">₹25,001 - ₹50,000</option>
                  <option value="50001-100000">₹50,001 - ₹100,000</option>
                  <option value="100001-9999999">Over ₹100,000</option>
                </select>
              </div>
            </div>
          </motion.div>

          {filteredPackages.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredPackages.map((pkg, index) => (
                <PackageCard key={pkg.id} pkg={pkg} index={index} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Filter className="h-16 w-16 mx-auto text-gray-400 mb-4" />
              <h2 className="text-2xl font-semibold text-gray-700 mb-2">No Packages Found</h2>
              <p className="text-gray-600 mb-6">Try adjusting your search or filters, or explore all our amazing packages.</p>
              <Button onClick={() => { setSearchTerm(''); setFilterDuration(''); setFilterPrice(''); }}>
                Clear Filters & View All
              </Button>
            </div>
          )}
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default PackagesPage;