import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Clock, Users, Star, Calendar, Shield, 
  ArrowLeft, Heart, Share2, Check, ChevronLeft, ChevronRight 
} from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useTours } from '@/contexts/TourContext';
import { useToast } from '@/components/ui/use-toast';

const TourDetailPage = () => {
  const { id } = useParams();
  const { getTourById, testimonials } = useTours();
  const { toast } = useToast();
  const tour = getTourById(id);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isWishlisted, setIsWishlisted] = useState(false);

  useEffect(() => {
    if (tour) {
        document.title = `${tour.title} - Abu Dhabi Layover Tours`;
    }
  }, [tour]);

  if (!tour) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Tour not found</h2>
          <Link to="/tours">
            <Button>Back to Tours</Button>
          </Link>
        </div>
      </div>
    );
  }

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % tour.images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + tour.images.length) % tour.images.length);
  };

  const handleWishlist = () => {
    setIsWishlisted(!isWishlisted);
    toast({
      title: isWishlisted ? "Removed from wishlist" : "Added to wishlist",
      description: isWishlisted ? "Tour removed from your wishlist" : "Tour saved to your wishlist"
    });
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: tour.title,
        text: tour.description,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied!",
        description: "Tour link copied to clipboard"
      });
    }
  };

  const tourTestimonials = testimonials.filter(t => t.tour === tour.title);

  return (
    <div className="min-h-screen">
      <Header />
      
      <div className="bg-gray-50 py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Link to="/" className="hover:text-purple-600">Home</Link>
            <span>/</span>
            <Link to="/tours" className="hover:text-purple-600">Tours</Link>
            <span>/</span>
            <span className="text-gray-900">{tour.title}</span>
          </div>
        </div>
      </div>

      <section className="py-8 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-8">
            <div className="lg:w-2/3">
              <div className="relative">
                <div className="aspect-video rounded-lg overflow-hidden bg-gray-200">
                  <img  
                    className="w-full h-full object-cover"
                    alt={`${tour.title} - Image ${currentImageIndex + 1}`}
                   src="https://images.unsplash.com/photo-1588058364847-daf069865918" />
                </div>
                
                {tour.images.length > 1 && (
                  <>
                    <button
                      onClick={prevImage}
                      className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white rounded-full p-2 shadow-lg transition-all"
                    >
                      <ChevronLeft className="h-5 w-5" />
                    </button>
                    <button
                      onClick={nextImage}
                      className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white rounded-full p-2 shadow-lg transition-all"
                    >
                      <ChevronRight className="h-5 w-5" />
                    </button>
                  </>
                )}

                {tour.images.length > 1 && (
                  <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                    {tour.images.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentImageIndex(index)}
                        className={`w-3 h-3 rounded-full transition-all ${
                          index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                        }`}
                      />
                    ))}
                  </div>
                )}
              </div>

              {tour.images.length > 1 && (
                <div className="grid grid-cols-4 gap-2 mt-4">
                  {tour.images.map((image, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`aspect-video rounded-lg overflow-hidden border-2 transition-all ${
                        index === currentImageIndex ? 'border-purple-600' : 'border-transparent'
                      }`}
                    >
                      <img  
                        className="w-full h-full object-cover"
                        alt={`${tour.title} thumbnail ${index + 1}`}
                       src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="lg:w-1/3">
              <div className="sticky top-24">
                <Card className="border-0 shadow-lg">
                  <CardHeader>
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <span className="bg-purple-100 text-purple-600 px-3 py-1 rounded-full text-sm font-medium">
                          {tour.category.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        </span>
                        {tour.featured && (
                          <span className="bg-yellow-100 text-yellow-600 px-3 py-1 rounded-full text-sm font-medium ml-2">
                            ⭐ Featured
                          </span>
                        )}
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={handleWishlist}
                          className={isWishlisted ? 'text-red-500 border-red-500' : ''}
                        >
                          <Heart className={`h-4 w-4 ${isWishlisted ? 'fill-current' : ''}`} />
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleShare}>
                          <Share2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <CardTitle className="text-2xl font-bold text-gray-900 mb-4">
                      {tour.title}
                    </CardTitle>

                    <div className="flex items-center space-x-4 text-sm text-gray-600 mb-6">
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4" />
                        <span>{tour.duration}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Users className="h-4 w-4" />
                        <span>Group Tour</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span>4.9 (127 reviews)</span>
                      </div>
                    </div>

                    <div className="text-center mb-6">
                      <div className="text-3xl font-bold text-purple-600">₹{tour.price.toLocaleString('en-IN')}</div>
                      <div className="text-sm text-gray-600">{tour.priceType}</div>
                    </div>
                  </CardHeader>

                  <CardContent>
                    <div className="space-y-4">
                      <Button 
                        asChild 
                        className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-lg py-6"
                      >
                        <Link to={`/booking/${tour.id}`}>
                          Book This Tour
                        </Link>
                      </Button>

                      <Button variant="outline" className="w-full" onClick={() => toast({ title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀" })}>
                        Contact for Custom Quote
                      </Button>

                      <div className="text-center text-sm text-gray-600">
                        <div className="flex items-center justify-center space-x-1 mb-2">
                          <Shield className="h-4 w-4 text-green-500" />
                          <span>Free cancellation up to 24 hours</span>
                        </div>
                        <div className="flex items-center justify-center space-x-1">
                          <Calendar className="h-4 w-4 text-blue-500" />
                          <span>Instant confirmation</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <Card>
                <CardHeader>
                  <CardTitle>About This Tour</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">{tour.description}</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Tour Highlights</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {tour.highlights.map((highlight, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                        <span className="text-gray-700">{highlight}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>What's Included</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {tour.included.map((item, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                        <span className="text-gray-700">{item}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {tourTestimonials.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Customer Reviews</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {tourTestimonials.map((testimonial) => (
                        <div key={testimonial.id} className="border-b border-gray-200 pb-6 last:border-b-0">
                          <div className="flex items-center space-x-4 mb-3">
                            <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full flex items-center justify-center">
                              <span className="text-white font-semibold">
                                {testimonial.name.split(' ').map(n => n[0]).join('')}
                              </span>
                            </div>
                            <div>
                              <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                              <div className="flex items-center space-x-2">
                                <div className="flex">
                                  {[...Array(testimonial.rating)].map((_, i) => (
                                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                                  ))}
                                </div>
                                <span className="text-sm text-gray-500">{testimonial.country}</span>
                              </div>
                            </div>
                          </div>
                          <p className="text-gray-600 italic">"{testimonial.comment}"</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Quick Info</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Duration:</span>
                    <span className="font-medium">{tour.duration}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Group Size:</span>
                    <span className="font-medium">Max 15 people</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Language:</span>
                    <span className="font-medium">English, Arabic</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Pickup:</span>
                    <span className="font-medium">Hotel/Airport</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Availability:</span>
                    <span className="font-medium text-green-600">Daily</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Need Help?</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <p className="text-sm text-gray-600">
                      Have questions about this tour? Our team is here to help!
                    </p>
                    <Button variant="outline" className="w-full" onClick={() => toast({ title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀" })}>
                      WhatsApp Chat
                    </Button>
                    <Button variant="outline" className="w-full" onClick={() => toast({ title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀" })}>
                      Call +971 50 123 4567
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default TourDetailPage;