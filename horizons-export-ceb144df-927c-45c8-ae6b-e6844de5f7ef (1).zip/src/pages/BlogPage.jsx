import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, User, ArrowRight, Search, Tag } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';

const BlogPage = () => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const blogPosts = [
    {
      id: '1',
      title: 'Ultimate Guide to Abu Dhabi Layover Tours',
      excerpt: 'Make the most of your layover with our comprehensive guide to Abu Dhabi\'s must-see attractions and experiences.',
      content: 'Abu Dhabi offers incredible opportunities for layover travelers...',
      category: 'Travel Tips',
      author: 'Sarah Johnson',
      date: '2024-01-15',
      readTime: '5 min read',
      image: 'Abu Dhabi layover guide with airport and city views',
      featured: true
    },
    {
      id: '2',
      title: 'Sheikh Zayed Grand Mosque: A Architectural Marvel',
      excerpt: 'Discover the stunning beauty and cultural significance of one of the world\'s most magnificent mosques.',
      content: 'The Sheikh Zayed Grand Mosque stands as a testament to Islamic architecture...',
      category: 'Culture',
      author: 'Ahmed Al-Rashid',
      date: '2024-01-10',
      readTime: '7 min read',
      image: 'Sheikh Zayed Grand Mosque architectural details',
      featured: false
    },
    {
      id: '3',
      title: 'Desert Safari Adventures: What to Expect',
      excerpt: 'Everything you need to know about experiencing the magic of Abu Dhabi\'s desert landscape.',
      content: 'The golden dunes of Abu Dhabi offer an unforgettable adventure...',
      category: 'Adventure',
      author: 'Maria Rodriguez',
      date: '2024-01-05',
      readTime: '6 min read',
      image: 'Desert safari adventure with dune bashing',
      featured: true
    },
    {
      id: '4',
      title: 'Best Time to Visit Abu Dhabi: Weather Guide',
      excerpt: 'Plan your perfect trip with our comprehensive weather guide and seasonal recommendations.',
      content: 'Abu Dhabi\'s climate varies throughout the year...',
      category: 'Travel Tips',
      author: 'David Chen',
      date: '2024-01-01',
      readTime: '4 min read',
      image: 'Abu Dhabi weather and seasonal attractions',
      featured: false
    },
    {
      id: '5',
      title: 'Emirates Palace: Luxury Redefined',
      excerpt: 'Explore the opulent world of Emirates Palace and discover why it\'s considered one of the world\'s most luxurious hotels.',
      content: 'Emirates Palace represents the pinnacle of luxury hospitality...',
      category: 'Luxury',
      author: 'Isabella Thompson',
      date: '2023-12-28',
      readTime: '5 min read',
      image: 'Emirates Palace luxury hotel exterior and interiors',
      featured: false
    },
    {
      id: '6',
      title: 'Local Cuisine: Flavors of Abu Dhabi',
      excerpt: 'Embark on a culinary journey through Abu Dhabi\'s diverse food scene and traditional Emirati dishes.',
      content: 'Abu Dhabi\'s culinary landscape reflects its multicultural heritage...',
      category: 'Food',
      author: 'Omar Hassan',
      date: '2023-12-25',
      readTime: '8 min read',
      image: 'Traditional Emirati cuisine and local food markets',
      featured: false
    }
  ];

  const categories = [
    'all',
    'Travel Tips',
    'Culture',
    'Adventure',
    'Luxury',
    'Food'
  ];

  const filteredPosts = blogPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const featuredPosts = blogPosts.filter(post => post.featured);

  const handleReadMore = (postId) => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-br from-purple-600 to-blue-600 text-white">
        <div className="absolute inset-0 opacity-20">
          <img  
            className="w-full h-full object-cover"
            alt="Abu Dhabi travel blog and guides"
           src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4" />
        </div>
        
        <div className="relative z-10 container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Travel <span className="text-yellow-400">Blog</span>
            </h1>
            <p className="text-xl text-purple-100 max-w-2xl mx-auto">
              Discover insider tips, cultural insights, and travel guides to make your Abu Dhabi experience extraordinary
            </p>
          </motion.div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="py-8 bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-6 items-center">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search articles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? 'default' : 'outline'}
                  onClick={() => setSelectedCategory(category)}
                  className={selectedCategory === category ? 'bg-purple-600 hover:bg-purple-700' : ''}
                >
                  {category === 'all' ? 'All Posts' : category}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Posts */}
      {selectedCategory === 'all' && (
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Featured <span className="gradient-text">Articles</span>
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Our most popular and insightful articles about Abu Dhabi travel
              </p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {featuredPosts.map((post, index) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="h-full overflow-hidden hover:shadow-xl transition-shadow duration-300 border-0 bg-white">
                    <div className="relative h-64">
                      <img  
                        className="w-full h-full object-cover"
                        alt={post.image}
                       src="https://images.unsplash.com/photo-1578662996442-48f60103fc96" />
                      <div className="absolute top-4 left-4">
                        <span className="bg-purple-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                          Featured
                        </span>
                      </div>
                      <div className="absolute top-4 right-4">
                        <span className="bg-white/90 backdrop-blur-sm text-gray-900 px-3 py-1 rounded-full text-sm font-medium">
                          {post.category}
                        </span>
                      </div>
                    </div>
                    
                    <CardContent className="p-6">
                      <h3 className="text-xl font-bold text-gray-900 mb-3 hover:text-purple-600 transition-colors cursor-pointer">
                        {post.title}
                      </h3>
                      
                      <p className="text-gray-600 mb-4 line-clamp-3">
                        {post.excerpt}
                      </p>

                      <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-1">
                            <User className="h-4 w-4" />
                            <span>{post.author}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-4 w-4" />
                            <span>{new Date(post.date).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <span>{post.readTime}</span>
                      </div>

                      <Button 
                        variant="outline" 
                        className="w-full group"
                        onClick={() => handleReadMore(post.id)}
                      >
                        Read More 
                        <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* All Posts */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              {selectedCategory === 'all' ? 'Latest Articles' : `${selectedCategory} Articles`}
            </h2>
            <p className="text-lg text-gray-600">
              {filteredPosts.length} article{filteredPosts.length !== 1 ? 's' : ''} found
            </p>
          </motion.div>

          {filteredPosts.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-16"
            >
              <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="h-12 w-12 text-gray-400" />
              </div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-4">No articles found</h3>
              <p className="text-gray-600 mb-6">
                Try adjusting your search criteria or browse all articles
              </p>
              <Button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedCategory('all');
                }}
                className="bg-purple-600 hover:bg-purple-700"
              >
                Clear Filters
              </Button>
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredPosts.map((post, index) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="h-full overflow-hidden hover:shadow-lg transition-shadow duration-300 border-0 bg-gradient-to-br from-white to-gray-50">
                    <div className="relative h-48">
                      <img  
                        className="w-full h-full object-cover"
                        alt={post.image}
                       src="https://images.unsplash.com/photo-1578662996442-48f60103fc96" />
                      <div className="absolute top-4 right-4">
                        <span className="bg-white/90 backdrop-blur-sm text-gray-900 px-2 py-1 rounded-full text-xs font-medium">
                          {post.category}
                        </span>
                      </div>
                    </div>
                    
                    <CardContent className="p-6">
                      <h3 className="text-lg font-bold text-gray-900 mb-3 hover:text-purple-600 transition-colors cursor-pointer line-clamp-2">
                        {post.title}
                      </h3>
                      
                      <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                        {post.excerpt}
                      </p>

                      <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                        <div className="flex items-center space-x-1">
                          <User className="h-3 w-3" />
                          <span>{post.author}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-3 w-3" />
                            <span>{new Date(post.date).toLocaleDateString()}</span>
                          </div>
                          <span>•</span>
                          <span>{post.readTime}</span>
                        </div>
                      </div>

                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full group"
                        onClick={() => handleReadMore(post.id)}
                      >
                        Read More 
                        <ArrowRight className="ml-2 h-3 w-3 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-16 bg-gradient-to-r from-purple-600 to-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-2xl mx-auto"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Stay Updated
            </h2>
            <p className="text-xl text-purple-100 mb-8">
              Subscribe to our newsletter for the latest travel tips, tour updates, and exclusive offers
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Input
                placeholder="Enter your email"
                className="flex-1 bg-white/10 border-white/20 text-white placeholder:text-white/70"
              />
              <Button 
                className="bg-white text-purple-600 hover:bg-gray-100"
                onClick={() => toast({
                  title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
                })}
              >
                Subscribe
              </Button>
            </div>
            
            <p className="text-sm text-purple-200 mt-4">
              No spam, unsubscribe at any time
            </p>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default BlogPage;