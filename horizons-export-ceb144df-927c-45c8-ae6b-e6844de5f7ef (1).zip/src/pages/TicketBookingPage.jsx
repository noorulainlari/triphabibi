import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Ticket as TicketIconLucide, Calendar, Users, CreditCard, ArrowLeft, AlertCircle, CheckCircle, Info, MapPin } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { useTickets } from '@/contexts/TicketContext';
import { useAppContext } from '@/contexts/AppContext';
import { useToast } from "@/components/ui/use-toast";
import RazorpayPayment from '@/components/booking/RazorpayPayment';
import { usePaymentGateways } from '@/contexts/PaymentGatewayContext';


const TicketBookingPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { getTicketOptionById, addTicketBooking } = useTickets();
  const { uiTexts, appSettings } = useAppContext();
  const { getActiveGateways, gatewaySettings } = usePaymentGateways();
  const { toast } = useToast();
  
  const ticket = getTicketOptionById(id);

  const [formData, setFormData] = useState({
    name: '',
    emailOrMobile: '',
    visitDate: '',
    selectedSlot: '',
    adults: 1,
    children: 0,
    infants: 0,
  });
  const [totalPrice, setTotalPrice] = useState(0);
  const [showPayment, setShowPayment] = useState(false);
  const [bookingDetails, setBookingDetails] = useState(null);

  useEffect(() => {
    if (ticket) {
      const adultCost = (formData.adults || 0) * (ticket.price?.adult || 0);
      const childCost = (formData.children || 0) * (ticket.price?.child || 0);
      const infantCost = (formData.infants || 0) * (ticket.price?.infant || 0);
      setTotalPrice(adultCost + childCost + infantCost);
    }
  }, [formData, ticket]);

  if (!appSettings.ticketsModuleEnabled) {
     return (
      <>
        <Header />
        <div className="container mx-auto px-4 py-20 text-center">
          <TicketIconLucide className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <h1 className="text-3xl font-bold text-gray-700 mb-2">Ticket Booking Not Available</h1>
          <p className="text-gray-600">This feature is currently disabled.</p>
          <Button asChild className="mt-6">
            <Link to="/">Go to Homepage</Link>
          </Button>
        </div>
        <Footer />
      </>
    );
  }

  if (!ticket || ticket.status === 'Hidden') {
    return (
      <>
        <Header />
        <div className="container mx-auto px-4 py-20 text-center">
          <AlertCircle className="h-16 w-16 mx-auto text-red-500 mb-4" />
          <h1 className="text-3xl font-bold text-gray-700 mb-2">Ticket Not Found</h1>
          <p className="text-gray-600">The ticket you are trying to book is unavailable or does not exist.</p>
          <Button asChild className="mt-6">
            <Link to="/tickets">View All Tickets</Link>
          </Button>
        </div>
        <Footer />
      </>
    );
  }

  const handleInputChange = (e) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseInt(value, 10) : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.emailOrMobile) {
      toast({ title: "Missing Information", description: "Please fill in your name and email/mobile.", variant: "destructive" });
      return;
    }
    if (!ticket.visitDateOptional && !formData.visitDate) {
      toast({ title: "Missing Date", description: "Please select a visit date.", variant: "destructive" });
      return;
    }
    if (ticket.slotSystem && ticket.slots && ticket.slots.length > 0 && !formData.selectedSlot) {
      toast({ title: "Missing Slot", description: "Please select a time slot.", variant: "destructive" });
      return;
    }
    if (formData.adults < 1 && formData.children < 1) {
        toast({ title: "No Passengers", description: "Please add at least one adult or child.", variant: "destructive" });
        return;
    }

    const currentBookingDetails = {
      ticketId: ticket.id,
      ticketName: ticket.name,
      ...formData,
      totalPrice,
      currency: 'INR',
    };
    setBookingDetails(currentBookingDetails);
    setShowPayment(true);
  };

  const handlePaymentSuccess = (response) => {
    const finalBooking = addTicketBooking({
      ...bookingDetails,
      paymentId: response.razorpay_payment_id,
      paymentStatus: 'Paid',
      bookingDate: new Date().toISOString(),
    });
    
    toast({
      title: "Booking Confirmed!",
      description: `Your payment was successful. Booking ID: ${finalBooking.bookingId}`,
      className: "bg-green-500 text-white",
      duration: 8000,
    });

    if (ticket.autoTicketSend && ticket.pdfTicketsUrl) {
        toast({
            title: "Ticket Sent (Simulated)",
            description: "Your ticket PDF has been sent to your email (simulated).",
            duration: 5000,
        });
    } else if (!ticket.autoTicketSend) {
         toast({
            title: "Confirmation Sent",
            description: "You'll receive your tickets manually from our team shortly.",
            duration: 5000,
        });
    }
    
    setTimeout(() => navigate('/'), 5000); 
  };

  const handlePaymentError = (error) => {
    toast({
      title: "Payment Failed",
      description: error.description || "An error occurred during payment. Please try again.",
      variant: "destructive",
    });
    setShowPayment(false); 
  };
  
  const activeGateways = getActiveGateways();
  const razorpayActive = activeGateways.find(gw => gw.id === 'razorpay');


  if (showPayment && bookingDetails) {
    if (razorpayActive && gatewaySettings.razorpay.keyId) {
      return (
        <RazorpayPayment
          amount={bookingDetails.totalPrice * 100} 
          currency={bookingDetails.currency}
          receiptId={`RCPT_TKT_${Date.now()}`}
          bookingDetails={bookingDetails}
          onSuccess={handlePaymentSuccess}
          onError={handlePaymentError}
          description={`Payment for ${ticket.name}`}
        />
      );
    } else {
        return (
             <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
                <Card className="w-full max-w-md shadow-xl">
                    <CardHeader className="bg-red-500 text-white">
                        <CardTitle className="flex items-center"><AlertCircle className="mr-2"/> Payment Gateway Error</CardTitle>
                    </CardHeader>
                    <CardContent className="pt-6 text-center">
                        <p className="text-lg text-gray-700 mb-4">
                            Online payment is currently unavailable. Razorpay is not configured or enabled.
                        </p>
                        <p className="text-sm text-gray-500 mb-6">
                            Please contact support or try again later.
                        </p>
                        <Button onClick={() => setShowPayment(false)} variant="outline">
                            <ArrowLeft className="mr-2 h-4 w-4"/> Go Back to Booking
                        </Button>
                    </CardContent>
                </Card>
            </div>
        );
    }
  }


  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Button variant="outline" onClick={() => navigate(-1)} className="mb-8 group">
            <ArrowLeft className="h-4 w-4 mr-2 group-hover:-translate-x-1 transition-transform" /> Back to Tickets
          </Button>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <section className="lg:col-span-1 space-y-6">
              <Card className="shadow-lg border-0 rounded-lg overflow-hidden">
                <img-replace 
                    src={ticket.images && ticket.images.length > 0 ? ticket.images[0].url : "https://images.unsplash.com/photo-1540450942234-c39800909901"} 
                    alt={ticket.name} 
                    className="w-full h-48 object-cover"
                />
                <CardContent className="p-6">
                  <h2 className="text-2xl font-bold text-gray-800 mb-2">{ticket.name}</h2>
                  <p className="text-gray-600 text-sm mb-1 flex items-center"><MapPin className="h-4 w-4 mr-1.5 text-gray-500"/>{ticket.location}</p>
                  {ticket.instantConfirmation && 
                    <p className="text-sm text-green-600 font-medium flex items-center"><CheckCircle className="h-4 w-4 mr-1.5"/>Instant Confirmation</p>
                  }
                  <p className="text-gray-700 mt-3">{ticket.shortDescription}</p>
                </CardContent>
              </Card>
              <Card className="shadow-lg border-0 rounded-lg">
                <CardHeader><CardTitle className="text-xl">Pricing</CardTitle></CardHeader>
                <CardContent className="space-y-1 text-gray-700">
                    <p>Adult: ₹{ticket.price.adult?.toLocaleString('en-IN') || 'N/A'}</p>
                    <p>Child (2-11 yrs): ₹{ticket.price.child?.toLocaleString('en-IN') || 'N/A'}</p>
                    <p>Infant (0-2 yrs): ₹{ticket.price.infant?.toLocaleString('en-IN') || 'Free'}</p>
                </CardContent>
              </Card>
            </section>

            <section className="lg:col-span-2">
              <Card className="shadow-xl border-0 rounded-lg">
                <CardHeader className="bg-gradient-to-r from-green-600 to-emerald-500 text-white p-6 rounded-t-lg">
                  <CardTitle className="text-3xl font-bold flex items-center"><TicketIconLucide className="h-7 w-7 mr-3"/>Book Your Tickets</CardTitle>
                </CardHeader>
                <form onSubmit={handleSubmit}>
                  <CardContent className="p-6 space-y-6">
                    <div>
                      <Label htmlFor="name" className="font-semibold">Full Name*</Label>
                      <Input id="name" name="name" value={formData.name} onChange={handleInputChange} required />
                    </div>
                    <div>
                      <Label htmlFor="emailOrMobile" className="font-semibold">Email or Mobile Number*</Label>
                      <Input id="emailOrMobile" name="emailOrMobile" type="text" value={formData.emailOrMobile} onChange={handleInputChange} required />
                    </div>
                    
                    {!ticket.visitDateOptional && (
                        <div>
                            <Label htmlFor="visitDate" className="font-semibold">Visit Date*</Label>
                            <Input id="visitDate" name="visitDate" type="date" value={formData.visitDate} onChange={handleInputChange} min={new Date().toISOString().split('T')[0]} required />
                        </div>
                    )}

                    {ticket.slotSystem && ticket.slots && ticket.slots.length > 0 && (
                        <div>
                            <Label htmlFor="selectedSlot" className="font-semibold">Select Time Slot*</Label>
                            <select 
                                id="selectedSlot" 
                                name="selectedSlot" 
                                value={formData.selectedSlot} 
                                onChange={handleInputChange} 
                                required
                                className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                            >
                                <option value="">-- Select a Slot --</option>
                                {ticket.slots.map(slot => <option key={slot} value={slot}>{slot}</option>)}
                            </select>
                        </div>
                    )}
                    
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div>
                            <Label htmlFor="adults" className="font-semibold">Adults (12+)</Label>
                            <Input id="adults" name="adults" type="number" min="0" value={formData.adults} onChange={handleInputChange} />
                        </div>
                        <div>
                            <Label htmlFor="children" className="font-semibold">Children (2-11)</Label>
                            <Input id="children" name="children" type="number" min="0" value={formData.children} onChange={handleInputChange} />
                        </div>
                        <div>
                            <Label htmlFor="infants" className="font-semibold">Infants (0-2)</Label>
                            <Input id="infants" name="infants" type="number" min="0" value={formData.infants} onChange={handleInputChange} />
                        </div>
                    </div>
                    
                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                        <p className="text-xl font-bold text-green-700">Total Price: ₹{totalPrice.toLocaleString('en-IN')}</p>
                    </div>

                  </CardContent>
                  <CardFooter className="p-6 bg-gray-50 rounded-b-lg">
                    <Button type="submit" size="lg" className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-lg py-3.5">
                      <CreditCard className="h-5 w-5 mr-2" /> {uiTexts.proceedToPaymentButton || "Proceed to Payment"}
                    </Button>
                  </CardFooter>
                </form>
              </Card>
            </section>
          </div>
        </motion.div>
      </main>
      <Footer />
    </div>
  );
};

export default TicketBookingPage;