import React, { useState, useEffect } from 'react';
import { useParams, useLocation, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, CheckCircle, FileText, User, Mail, Phone, CalendarDays, Globe, CreditCard, UploadCloud, Info } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useVisa } from '@/contexts/VisaContext';
import { useToast } from '@/components/ui/use-toast';
import RazorpayPayment from '@/components/booking/RazorpayPayment'; // Reusing for visa payment

const ApplyVisaPage = () => {
  const { countryCode } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { getVisaOptionById, addVisaApplication } = useVisa();
  const { toast } = useToast();

  const queryParams = new URLSearchParams(location.search);
  const visaTypeId = queryParams.get('visaType');
  
  const selectedVisaOption = getVisaOptionById(visaTypeId);

  const [applicationData, setApplicationData] = useState({
    visaOptionId: visaTypeId,
    visaOptionName: selectedVisaOption?.visaType || '',
    countryApplyingFor: selectedVisaOption?.countryName || '',
    countryCode: countryCode,
    fullName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    nationality: '',
    passportNumber: '',
    passportExpiryDate: '',
    travelDate: '',
    specialRequests: '',
    uploadedDocuments: [] // Store names of uploaded files (simulated)
  });
  const [currentStep, setCurrentStep] = useState(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPayment, setShowPayment] = useState(false);

  useEffect(() => {
    if (selectedVisaOption) {
      document.title = `Apply for ${selectedVisaOption.visaType} - ${selectedVisaOption.countryName}`;
      setApplicationData(prev => ({
        ...prev,
        visaOptionName: selectedVisaOption.visaType,
        countryApplyingFor: selectedVisaOption.countryName,
      }));
    } else if(visaTypeId) {
       toast({ title: "Visa Type Not Found", description: "The selected visa type is invalid or no longer available.", variant: "destructive"});
       navigate('/visas');
    }
  }, [selectedVisaOption, visaTypeId, navigate, toast]);

  if (!selectedVisaOption && visaTypeId) { // Handles case where visa option is not found after initial check
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <Header />
        <p className="text-xl text-red-600 p-8">Invalid visa type selected. Redirecting...</p>
        <Footer />
      </div>
    );
  }
  
  if (!selectedVisaOption && !visaTypeId) { // Handles case where no visaType is in URL
     toast({ title: "No Visa Type Selected", description: "Please select a visa type from the visas page.", variant: "destructive"});
     navigate('/visas');
     return null; 
  }


  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setApplicationData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileUpload = (event) => {
    toast({
      title: "🚧 Document Upload Simulated",
      description: "Actual file upload requires backend storage. File names are noted.",
    });
    if (event.target.files && event.target.files.length > 0) {
      const newFiles = Array.from(event.target.files).map(file => file.name);
      setApplicationData(prev => ({
        ...prev,
        uploadedDocuments: [...prev.uploadedDocuments, ...newFiles]
      }));
    }
  };
  
  const removeUploadedDocument = (fileName) => {
    setApplicationData(prev => ({
      ...prev,
      uploadedDocuments: prev.uploadedDocuments.filter(doc => doc !== fileName)
    }));
  };


  const validateStep = () => {
    if (currentStep === 1) {
      return applicationData.fullName && applicationData.email && applicationData.phone && applicationData.dateOfBirth && applicationData.nationality;
    }
    if (currentStep === 2) {
      return applicationData.passportNumber && applicationData.passportExpiryDate && applicationData.travelDate;
    }
    // Step 3 (document upload) validation can be lenient as it's simulated
    return true;
  };

  const nextStep = () => {
    if (validateStep()) {
      setCurrentStep(prev => prev + 1);
    } else {
      toast({ title: "Missing Information", description: "Please fill all required fields for the current step.", variant: "destructive"});
    }
  };

  const prevStep = () => setCurrentStep(prev => prev - 1);

  const handleSubmitApplication = async () => {
    if (!validateStep()) {
       toast({ title: "Missing Information", description: "Please review your application for any missing fields.", variant: "destructive"});
       return;
    }
    setIsProcessing(true);
    // In a real app, you'd submit data, then proceed to payment if successful
    setShowPayment(true);
    setIsProcessing(false);
  };

  const handlePaymentSuccess = (paymentResponse) => {
    const finalApplicationData = {
      ...applicationData,
      paymentId: paymentResponse.razorpay_payment_id,
      totalAmount: selectedVisaOption.price,
      status: 'submitted' 
    };
    addVisaApplication(finalApplicationData);
    toast({
      title: "Application Submitted & Payment Successful!",
      description: `Your visa application for ${selectedVisaOption.visaType} has been submitted. Ref ID: ${finalApplicationData.applicationId.slice(0,10)}...`,
      duration: 7000,
    });
    navigate('/visas', { state: { message: `Visa application for ${selectedVisaOption.visaType} submitted successfully!` }});
  };

  const handlePaymentError = (error) => {
    toast({
      title: "Payment Failed",
      description: error.description || "Something went wrong with the payment. Please try again.",
      variant: "destructive"
    });
    setShowPayment(false); // Allow user to retry or go back
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1: // Personal Information
        return (
          <motion.div initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
            <CardTitle className="text-2xl flex items-center"><User className="mr-3 text-purple-600" /> Personal Information</CardTitle>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div><Label htmlFor="fullName">Full Name (as per passport) *</Label><Input id="fullName" name="fullName" value={applicationData.fullName} onChange={handleInputChange} required /></div>
              <div><Label htmlFor="email">Email Address *</Label><Input id="email" name="email" type="email" value={applicationData.email} onChange={handleInputChange} required /></div>
              <div><Label htmlFor="phone">Phone Number *</Label><Input id="phone" name="phone" type="tel" value={applicationData.phone} onChange={handleInputChange} required /></div>
              <div><Label htmlFor="dateOfBirth">Date of Birth *</Label><Input id="dateOfBirth" name="dateOfBirth" type="date" value={applicationData.dateOfBirth} onChange={handleInputChange} required /></div>
              <div><Label htmlFor="nationality">Nationality *</Label><Input id="nationality" name="nationality" value={applicationData.nationality} onChange={handleInputChange} required /></div>
            </div>
          </motion.div>
        );
      case 2: // Passport & Travel Details
        return (
          <motion.div initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
            <CardTitle className="text-2xl flex items-center"><FileText className="mr-3 text-purple-600" /> Passport & Travel Details</CardTitle>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div><Label htmlFor="passportNumber">Passport Number *</Label><Input id="passportNumber" name="passportNumber" value={applicationData.passportNumber} onChange={handleInputChange} required /></div>
              <div><Label htmlFor="passportExpiryDate">Passport Expiry Date *</Label><Input id="passportExpiryDate" name="passportExpiryDate" type="date" value={applicationData.passportExpiryDate} onChange={handleInputChange} required /></div>
              <div><Label htmlFor="travelDate">Intended Travel Date *</Label><Input id="travelDate" name="travelDate" type="date" value={applicationData.travelDate} onChange={handleInputChange} min={new Date().toISOString().split("T")[0]} required /></div>
            </div>
             <div>
                <Label htmlFor="specialRequests">Additional Information / Special Requests</Label>
                <Textarea id="specialRequests" name="specialRequests" value={applicationData.specialRequests} onChange={handleInputChange} rows={3} placeholder="Any other information relevant to your application..." />
              </div>
          </motion.div>
        );
      case 3: // Document Upload
        return (
          <motion.div initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
            <CardTitle className="text-2xl flex items-center"><UploadCloud className="mr-3 text-purple-600" /> Document Upload</CardTitle>
            <CardDescription>Please upload clear copies of the required documents. Max file size 5MB per file. (Simulated upload)</CardDescription>
            <ul className="list-disc list-inside bg-purple-50 p-4 rounded-md text-purple-700">
              {selectedVisaOption.documentsRequired.map((doc, i) => <li key={i}>{doc}</li>)}
            </ul>
            <Input id="documentUpload" type="file" multiple onChange={handleFileUpload} className="cursor-pointer" />
            {applicationData.uploadedDocuments.length > 0 && (
                <div className="space-y-2 mt-4">
                    <p className="font-medium">Uploaded files (simulated):</p>
                    {applicationData.uploadedDocuments.map(fileName => (
                        <div key={fileName} className="flex items-center justify-between text-sm p-2 bg-gray-100 rounded">
                            <span>{fileName}</span>
                            <Button variant="ghost" size="sm" onClick={() => removeUploadedDocument(fileName)} className="text-red-500 hover:text-red-700">Remove</Button>
                        </div>
                    ))}
                </div>
            )}
          </motion.div>
        );
      case 4: // Review & Confirm
        return (
          <motion.div initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
            <CardTitle className="text-2xl flex items-center"><CheckCircle className="mr-3 text-purple-600" /> Review & Confirm</CardTitle>
            <CardDescription>Please review your application details carefully before proceeding to payment.</CardDescription>
            <div className="space-y-3 p-4 border rounded-lg bg-gray-50">
              <h3 className="font-semibold text-lg text-gray-800">Visa: {selectedVisaOption.visaType} for {selectedVisaOption.countryName}</h3>
              <p><strong>Full Name:</strong> {applicationData.fullName}</p>
              <p><strong>Email:</strong> {applicationData.email}</p>
              <p><strong>Phone:</strong> {applicationData.phone}</p>
              <p><strong>Nationality:</strong> {applicationData.nationality}</p>
              <p><strong>Passport No:</strong> {applicationData.passportNumber}</p>
              <p><strong>Travel Date:</strong> {applicationData.travelDate}</p>
              <p><strong>Total Price:</strong> ₹{selectedVisaOption.price.toLocaleString('en-IN')}</p>
              {applicationData.uploadedDocuments.length > 0 && <p><strong>Documents (Simulated):</strong> {applicationData.uploadedDocuments.join(', ')}</p>}
            </div>
            <div className="flex items-start space-x-2 p-3 bg-yellow-50 border-l-4 border-yellow-400 rounded-md">
                <Info className="h-5 w-5 text-yellow-600 mt-0.5"/>
                <p className="text-sm text-yellow-700">
                    By submitting, you confirm that all information provided is true and accurate. 
                    Incorrect information may lead to application rejection.
                </p>
            </div>
          </motion.div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow bg-gradient-to-br from-gray-100 to-blue-100 py-12">
        <div className="container mx-auto px-4">
          <Button variant="outline" onClick={() => navigate('/visas')} className="mb-6 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-2" /> Back to Visa Options
          </Button>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
            <Card className="lg:col-span-2 shadow-xl border-0">
              <CardHeader className="bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-t-lg p-6">
                <div className="flex items-center space-x-3">
                  <img src={selectedVisaOption.flagIconUrl} alt={`${selectedVisaOption.countryName} flag`} className="w-10 h-auto rounded-md border-2 border-white" />
                  <div>
                    <CardTitle className="text-3xl">Apply for {selectedVisaOption.countryName} Visa</CardTitle>
                    <CardDescription className="text-purple-100 text-lg">{selectedVisaOption.visaType}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6 md:p-8">
                {!showPayment ? (
                  <>
                    <div className="mb-8">
                      <ol className="flex items-center w-full text-sm font-medium text-center text-gray-500">
                        {[1,2,3,4].map(stepNum => (
                           <li key={stepNum} className={`flex md:w-full items-center ${currentStep >= stepNum ? 'text-purple-600' : ''} ${stepNum < 4 ? "sm:after:content-[''] after:w-full after:h-1 after:border-b after:border-gray-200 after:border-1 after:hidden sm:after:inline-block after:mx-6 xl:after:mx-10" : ""} ${currentStep >= stepNum ? 'sm:after:border-purple-500' : ''}`}>
                            <span className={`flex items-center after:content-['/'] sm:after:hidden after:mx-2 after:text-gray-200 ${currentStep >= stepNum ? 'font-semibold' : ''}`}>
                              {currentStep > stepNum ? <CheckCircle className="w-4 h-4 mr-2 sm:w-5 sm:h-5"/> : <span className="mr-2">{stepNum}</span>}
                              {stepNum === 1 && "Personal"}
                              {stepNum === 2 && "Travel"}
                              {stepNum === 3 && "Docs"}
                              {stepNum === 4 && "Review"}
                            </span>
                          </li>
                        ))}
                      </ol>
                    </div>
                    {renderStepContent()}
                  </>
                ) : (
                  <RazorpayPayment
                    amount={selectedVisaOption.price}
                    bookingData={{ // Adapt bookingData structure for visa
                      firstName: applicationData.fullName.split(' ')[0],
                      lastName: applicationData.fullName.split(' ').slice(1).join(' ') || applicationData.fullName.split(' ')[0],
                      email: applicationData.email,
                      phone: applicationData.phone,
                      tourId: selectedVisaOption.id, // Using visa ID here
                    }}
                    onSuccess={handlePaymentSuccess}
                    onError={handlePaymentError}
                    tourTitle={`${selectedVisaOption.visaType} - ${selectedVisaOption.countryName}`} // Use visa type as title
                  />
                )}
              </CardContent>
              {!showPayment && (
                <CardFooter className="p-6 md:p-8 border-t flex justify-between">
                  <Button variant="outline" onClick={prevStep} disabled={currentStep === 1 || isProcessing}>Previous</Button>
                  {currentStep < 4 ? (
                    <Button onClick={nextStep} disabled={isProcessing} className="bg-purple-600 hover:bg-purple-700">Next</Button>
                  ) : (
                    <Button onClick={handleSubmitApplication} disabled={isProcessing} className="bg-green-600 hover:bg-green-700">
                      <CreditCard className="mr-2 h-5 w-5" /> Proceed to Payment (₹{selectedVisaOption.price.toLocaleString('en-IN')})
                    </Button>
                  )}
                </CardFooter>
              )}
            </Card>

            <div className="sticky top-24 space-y-6">
              <Card className="shadow-lg border-0">
                <CardHeader className="bg-gray-100">
                  <CardTitle className="text-xl flex items-center"><Info className="mr-2 text-purple-600"/>Visa Details</CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-3 text-sm">
                  <p><strong>Country:</strong> {selectedVisaOption.countryName}</p>
                  <p><strong>Visa Type:</strong> {selectedVisaOption.visaType}</p>
                  <p><strong>Processing Time:</strong> {selectedVisaOption.processingTime}</p>
                  <p><strong>Price:</strong> <span className="font-bold text-lg text-purple-700">₹{selectedVisaOption.price.toLocaleString('en-IN')}</span></p>
                  <h4 className="font-semibold pt-2 border-t mt-3">Documents Required:</h4>
                  <ul className="list-disc list-inside text-gray-600">
                    {selectedVisaOption.documentsRequired.map((doc, i) => <li key={i}>{doc}</li>)}
                  </ul>
                </CardContent>
              </Card>
               <Card className="shadow-lg border-0 bg-purple-50">
                <CardHeader>
                    <CardTitle className="text-xl flex items-center text-purple-700"><Phone className="mr-2"/>Need Help?</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-purple-600 space-y-3">
                    <p>If you have any questions or need assistance with your visa application, please don't hesitate to contact us.</p>
                    <Button variant="outline" className="w-full border-purple-500 text-purple-600 hover:bg-purple-100" onClick={() => toast({ title: "🚧 Feature Not Implemented" })}>
                        Contact Support
                    </Button>
                </CardContent>
               </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ApplyVisaPage;