
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from '@/App';
import '@/index.css';
import { Helmet, HelmetProvider } from 'react-helmet-async';


ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <HelmetProvider>
      <Helmet>
        <script src="https://checkout.razorpay.com/v1/checkout.js" async></script>
        <script src="https://js.stripe.com/v3/" async></script>
        <script src="https://www.paypal.com/sdk/js?client-id=YOUR_PAYPAL_CLIENT_ID&currency=INR" async></script>
      </Helmet>
      <App />
    </HelmetProvider>
  </React.StrictMode>
);
